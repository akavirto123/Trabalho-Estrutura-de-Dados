/**
 * Implementação de Bloom Filter - Estrutura Adicional Fora da Ementa
 * 
 * O Bloom Filter é uma estrutura de dados probabilística eficiente em termos de espaço
 * que permite testar rapidamente se um elemento pertence a um conjunto.
 * Pode produzir falsos positivos, mas nunca falsos negativos.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "estruturas/bloom_filter.h"

// Funções de hash
unsigned int hash1(const char *str, int tamanho) {
    unsigned long hash = 5381;
    int c;
    while ((c = *str++))
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    return hash % tamanho;
}

unsigned int hash2(const char *str, int tamanho) {
    unsigned long hash = 0;
    int c;
    while ((c = *str++))
        hash = c + (hash << 6) + (hash << 16) - hash;
    return hash % tamanho;
}

unsigned int hash3(const char *str, int tamanho) {
    unsigned long hash = 0;
    int c, i = 0;
    while ((c = *str++)) {
        hash += c * pow(31, i);
        i++;
    }
    return hash % tamanho;
}

unsigned int hash4(const char *str, int tamanho) {
    unsigned long hash = 0;
    int c;
    while ((c = *str++))
        hash = ((hash << 4) ^ (hash >> 28) ^ c);
    return hash % tamanho;
}

// Cria um novo filtro de Bloom
BloomFilter *bloom_criar(int tamanho, int k_hashes) {
    BloomFilter *bf = (BloomFilter*)malloc(sizeof(BloomFilter));
    if (!bf) return NULL;
    
    // Aloca o array de bits (1 bit por posição)
    // Representado como um array de caracteres (8 bits por char)
    int array_size = (tamanho + 7) / 8; // arredonda para cima
    bf->array = (char*)calloc(array_size, sizeof(char));
    if (!bf->array) {
        free(bf);
        return NULL;
    }
    
    bf->tamanho = tamanho;
    bf->k_hashes = k_hashes > 4 ? 4 : k_hashes; // limita a 4 funções hash
    
    return bf;
}

// Libera a memória do filtro de Bloom
void bloom_destruir(BloomFilter *bf) {
    if (bf) {
        if (bf->array) {
            free(bf->array);
        }
        free(bf);
    }
}

// Define um bit no array
static void setBit(char *array, int bit) {
    int byte_pos = bit / 8;
    int bit_pos = bit % 8;
    array[byte_pos] |= (1 << bit_pos);
}

// Verifica se um bit está definido
static int testBit(char *array, int bit) {
    int byte_pos = bit / 8;
    int bit_pos = bit % 8;
    return (array[byte_pos] & (1 << bit_pos)) != 0;
}

// Adiciona um elemento ao filtro de Bloom
void bloom_adicionar(BloomFilter *bf, const char *elemento) {
    if (!bf || !elemento) return;
    
    // Calcular posições usando diferentes funções hash
    unsigned int posicoes[4];
    posicoes[0] = hash1(elemento, bf->tamanho);
    posicoes[1] = hash2(elemento, bf->tamanho);
    posicoes[2] = hash3(elemento, bf->tamanho);
    posicoes[3] = hash4(elemento, bf->tamanho);
    
    // Definir bits nas posições calculadas
    for (int i = 0; i < bf->k_hashes; i++) {
        setBit(bf->array, posicoes[i]);
    }
}

// Verifica se um elemento pode estar no filtro
int bloom_verificar(BloomFilter *bf, const char *elemento) {
    if (!bf || !elemento) return 0;
    
    // Calcular posições usando diferentes funções hash
    unsigned int posicoes[4];
    posicoes[0] = hash1(elemento, bf->tamanho);
    posicoes[1] = hash2(elemento, bf->tamanho);
    posicoes[2] = hash3(elemento, bf->tamanho);
    posicoes[3] = hash4(elemento, bf->tamanho);
    
    // Verificar se todos os bits estão definidos
    for (int i = 0; i < bf->k_hashes; i++) {
        if (!testBit(bf->array, posicoes[i])) {
            return 0; // Elemento definitivamente não está no conjunto
        }
    }
    
    return 1; // Elemento pode estar no conjunto (possível falso positivo)
}

// Calcula a taxa de falsos positivos estimada
float bloom_falso_positivo(BloomFilter *bf, int n_elementos) {
    if (!bf) return 1.0;
    
    // Fórmula: (1 - e^(-k*n/m))^k
    // k = número de funções hash
    // n = número de elementos inseridos
    // m = tamanho do filtro em bits
    
    float k = (float)bf->k_hashes;
    float n = (float)n_elementos;
    float m = (float)bf->tamanho;
    
    float expoente = -k * n / m;
    float probabilidade = pow((1 - exp(expoente)), k);
    
    return probabilidade;
}

// Estima o número de elementos no filtro (aproximação)
int bloom_estimar_elementos(BloomFilter *bf) {
    if (!bf) return 0;
    
    int array_size = (bf->tamanho + 7) / 8;
    int count = 0;
    
    // Conta o número de bits definidos
    for (int byte = 0; byte < array_size; byte++) {
        char current = bf->array[byte];
        for (int bit = 0; bit < 8 && (byte * 8 + bit < bf->tamanho); bit++) {
            if (current & (1 << bit)) {
                count++;
            }
        }
    }
    
    // Estimativa baseada na fórmula: n ≈ -m/k * ln(1 - X/m)
    // m = tamanho do filtro
    // k = número de funções hash
    // X = número de bits definidos como 1
    
    float m = (float)bf->tamanho;
    float k = (float)bf->k_hashes;
    float X = (float)count;
    
    if (X == 0 || X == m) {
        return X == 0 ? 0 : INT_MAX;
    }
    
    float estimativa = -m / k * log(1 - X / m);
    return (int)estimativa;
}

// Limpa o filtro (redefine todos os bits para 0)
void bloom_limpar(BloomFilter *bf) {
    if (!bf || !bf->array) return;
    
    int array_size = (bf->tamanho + 7) / 8;
    memset(bf->array, 0, array_size);
}

// Combina dois filtros de Bloom (operação OR)
BloomFilter *bloom_combinar(BloomFilter *bf1, BloomFilter *bf2) {
    if (!bf1 || !bf2 || bf1->tamanho != bf2->tamanho || bf1->k_hashes != bf2->k_hashes) {
        return NULL;
    }
    
    BloomFilter *resultado = bloom_criar(bf1->tamanho, bf1->k_hashes);
    if (!resultado) return NULL;
    
    int array_size = (bf1->tamanho + 7) / 8;
    for (int i = 0; i < array_size; i++) {
        resultado->array[i] = bf1->array[i] | bf2->array[i];
    }
    
    return resultado;
}

// Verifica intersecção entre filtros (aproximação)
float bloom_interseccao(BloomFilter *bf1, BloomFilter *bf2) {
    if (!bf1 || !bf2 || bf1->tamanho != bf2->tamanho) {
        return 0.0;
    }
    
    int array_size = (bf1->tamanho + 7) / 8;
    int bits_intersection = 0;
    int bits_union = 0;
    
    for (int byte = 0; byte < array_size; byte++) {
        char intersection = bf1->array[byte] & bf2->array[byte];
        char union_bits = bf1->array[byte] | bf2->array[byte];
        
        // Conta bits em intersection e union
        for (int bit = 0; bit < 8 && (byte * 8 + bit < bf1->tamanho); bit++) {
            if (intersection & (1 << bit)) {
                bits_intersection++;
            }
            if (union_bits & (1 << bit)) {
                bits_union++;
            }
        }
    }
    
    return bits_union > 0 ? (float)bits_intersection / (float)bits_union : 0.0;
}

// Otimiza o tamanho do filtro para n elementos e taxa de falsos positivos p
BloomFilter *bloom_otimizado(int n_elementos, float p) {
    if (n_elementos <= 0 || p <= 0 || p >= 1) {
        return NULL;
    }
    
    // Cálculos para tamanho ótimo:
    // m = -n*ln(p) / (ln(2)^2)
    // k = m/n * ln(2)
    
    float ln2_squared = pow(log(2), 2);
    int m = (int)ceil(-n_elementos * log(p) / ln2_squared);
    int k = (int)round((float)m / n_elementos * log(2));
    
    // Limites práticos
    if (k < 1) k = 1;
    if (k > 4) k = 4; // limitado às funções hash implementadas
    
    return bloom_criar(m, k);
}