/**
 * memoria.h
 * 
 * Funções para gerenciamento e monitoramento de memória.
 */

#ifndef MEMORIA_H
#define MEMORIA_H

#include <stdlib.h>

/**
 * Aloca memória e registra estatísticas.
 * 
 * @param tamanho Quantidade de bytes a alocar
 * @return Ponteiro para a memória alocada ou NULL em caso de falha
 */
void* alocar_memoria(size_t tamanho);

/**
 * Libera memória e registra estatísticas.
 * 
 * @param ptr Ponteiro para a memória a ser liberada
 * @param tamanho Quantidade de bytes que foi alocada
 */
void liberar_memoria(void* ptr, size_t tamanho);

/**
 * Imprime estatísticas de uso de memória.
 */
void imprimir_estatisticas_memoria();

/**
 * Reseta as estatísticas de memória.
 */
void resetar_estatisticas_memoria();

/**
 * Obtém a quantidade aproximada de memória disponível no sistema.
 * 
 * @return Quantidade estimada de bytes disponíveis
 */
size_t obter_memoria_disponivel();

/**
 * Verifica e reporta possíveis vazamentos de memória.
 */
void verificar_vazamentos_memoria();

#endif /* MEMORIA_H */