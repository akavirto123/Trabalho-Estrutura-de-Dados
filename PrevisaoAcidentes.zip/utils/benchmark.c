/**
 * benchmark.c
 * 
 * Implementação de funções para benchmark e análise de desempenho das diferentes 
 * estruturas de dados.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "benchmark.h"
#include "memoria.h"
#include "../estruturas/lista_encadeada.h"
#include "../estruturas/arvore_avl.h"
#include "../estruturas/tabela_hash.h"
#include "../estruturas/skiplist.h"
#include "../estruturas/trie.h"

// Estrutura interna para armazenar resultados de benchmark
typedef struct {
    double tempo_insercao;
    double tempo_busca;
    double tempo_remocao;
    double fator_escalabilidade;
    size_t uso_memoria;
    double tempo_medio_acesso;
    double latencia_media;
    int colisoes;
} ResultadoInternoDosBenchmarks;

// Array para armazenar resultados de benchmark para cada estrutura
static ResultadoInternoDosBenchmarks resultados[5];  // Uma para cada tipo de estrutura

// Nomes das estruturas para exibição
const char* nomes_estruturas[] = {
    "Lista Encadeada",
    "Árvore AVL",
    "Tabela Hash",
    "SkipList",
    "Trie"
};

void benchmark_estrutura(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    if (tipo < 0 || tipo >= 5) {
        printf("Erro: Tipo de estrutura inválido para benchmark.\n");
        return;
    }
    
    // Inicializar semente aleatória com o tempo atual para garantir
    // que cada execução selecione dados diferentes
    srand(time(NULL));
    
    printf("Executando benchmark para %s...\n", nomes_estruturas[tipo]);
    
    // Número de operações para os testes
    int n_buscas = n_acidentes / 2;  // 50% do total
    int n_remocoes = n_acidentes / 4;  // 25% do total
    int n_acessos = 1000;  // Número fixo para testes de acesso
    
    // Executar testes
    resultados[tipo].tempo_insercao = testar_insercao(tipo, acidentes, n_acidentes);
    resultados[tipo].tempo_busca = testar_busca(tipo, acidentes, n_acidentes, n_buscas);
    resultados[tipo].tempo_remocao = testar_remocao(tipo, acidentes, n_acidentes, n_remocoes);
    resultados[tipo].fator_escalabilidade = testar_escalabilidade(tipo, acidentes, n_acidentes);
    resultados[tipo].uso_memoria = medir_uso_memoria(tipo, acidentes, n_acidentes);
    resultados[tipo].tempo_medio_acesso = medir_tempo_medio_acesso(tipo, acidentes, n_acidentes, n_acessos);
    resultados[tipo].latencia_media = medir_latencia_media(tipo, acidentes, n_acidentes);
    
    // Contar colisões apenas para tabela hash
    if (tipo == TABELA_HASH) {
        resultados[tipo].colisoes = contar_colisoes(tipo, acidentes, n_acidentes);
    } else {
        resultados[tipo].colisoes = 0;
    }
    
    // Exibir resultados para esta estrutura
    printf("\nResultados para %s:\n", nomes_estruturas[tipo]);
    printf("- Tempo de inserção: %.6f segundos\n", resultados[tipo].tempo_insercao);
    printf("- Tempo de busca: %.6f segundos\n", resultados[tipo].tempo_busca);
    printf("- Tempo de remoção: %.6f segundos\n", resultados[tipo].tempo_remocao);
    printf("- Fator de escalabilidade: %.2f\n", resultados[tipo].fator_escalabilidade);
    printf("- Uso de memória: %zu bytes (%.2f MB)\n", 
           resultados[tipo].uso_memoria, 
           resultados[tipo].uso_memoria / (1024.0 * 1024.0));
    printf("- Tempo médio de acesso: %.2f microssegundos\n", resultados[tipo].tempo_medio_acesso);
    printf("- Latência média: %.2f microssegundos\n", resultados[tipo].latencia_media);
    
    if (tipo == TABELA_HASH) {
        printf("- Colisões de hash: %d\n", resultados[tipo].colisoes);
    }
}

void imprimir_resultados_benchmark() {
    printf("\n=== COMPARAÇÃO DE RESULTADOS ===\n\n");
    
    // Cabeçalho da tabela
    printf("%-16s | %-12s | %-12s | %-12s | %-10s | %-15s | %-15s\n",
           "Estrutura", "Inserção (s)", "Busca (s)", "Remoção (s)", "Escala", "Memória (MB)", "Acesso (µs)");
    printf("----------------+---------------+---------------+---------------+------------+-----------------+-----------------\n");
    
    // Dados de cada estrutura
    for (int i = 0; i < 5; i++) {
        printf("%-16s | %-12.6f | %-12.6f | %-12.6f | %-10.2f | %-15.2f | %-15.2f\n",
               nomes_estruturas[i],
               resultados[i].tempo_insercao,
               resultados[i].tempo_busca,
               resultados[i].tempo_remocao,
               resultados[i].fator_escalabilidade,
               resultados[i].uso_memoria / (1024.0 * 1024.0),
               resultados[i].tempo_medio_acesso);
    }
    
    printf("\n");
    
    // Encontrar a melhor estrutura para cada categoria
    int melhor_insercao = 0;
    int melhor_busca = 0;
    int melhor_remocao = 0;
    int melhor_escala = 0;
    int melhor_memoria = 0;
    int melhor_acesso = 0;
    
    for (int i = 1; i < 5; i++) {
        if (resultados[i].tempo_insercao < resultados[melhor_insercao].tempo_insercao) {
            melhor_insercao = i;
        }
        if (resultados[i].tempo_busca < resultados[melhor_busca].tempo_busca) {
            melhor_busca = i;
        }
        if (resultados[i].tempo_remocao < resultados[melhor_remocao].tempo_remocao) {
            melhor_remocao = i;
        }
        if (resultados[i].fator_escalabilidade < resultados[melhor_escala].fator_escalabilidade) {
            melhor_escala = i;
        }
        if (resultados[i].uso_memoria < resultados[melhor_memoria].uso_memoria) {
            melhor_memoria = i;
        }
        if (resultados[i].tempo_medio_acesso < resultados[melhor_acesso].tempo_medio_acesso) {
            melhor_acesso = i;
        }
    }
    
    // Exibir destaques
    printf("=== DESTAQUES ===\n");
    printf("Melhor em inserção: %s (%.6f segundos)\n", 
           nomes_estruturas[melhor_insercao], resultados[melhor_insercao].tempo_insercao);
    printf("Melhor em busca: %s (%.6f segundos)\n", 
           nomes_estruturas[melhor_busca], resultados[melhor_busca].tempo_busca);
    printf("Melhor em remoção: %s (%.6f segundos)\n", 
           nomes_estruturas[melhor_remocao], resultados[melhor_remocao].tempo_remocao);
    printf("Melhor em escalabilidade: %s (fator %.2f)\n", 
           nomes_estruturas[melhor_escala], resultados[melhor_escala].fator_escalabilidade);
    printf("Melhor em economia de memória: %s (%.2f MB)\n", 
           nomes_estruturas[melhor_memoria], resultados[melhor_memoria].uso_memoria / (1024.0 * 1024.0));
    printf("Melhor em tempo de acesso: %s (%.2f µs)\n", 
           nomes_estruturas[melhor_acesso], resultados[melhor_acesso].tempo_medio_acesso);
    
    // Identificar a melhor estrutura geral
    // Aqui usamos um sistema simples de pontos: a melhor em cada categoria ganha 5 pontos, a segunda 4, etc.
    int pontos[5] = {0};
    
    // Classificar desempenho de inserção
    int ordem[5];
    for (int i = 0; i < 5; i++) ordem[i] = i;
    
    // Ordenar por tempo de inserção
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (resultados[ordem[j]].tempo_insercao < resultados[ordem[i]].tempo_insercao) {
                int temp = ordem[i];
                ordem[i] = ordem[j];
                ordem[j] = temp;
            }
        }
    }
    
    // Atribuir pontos para inserção
    for (int i = 0; i < 5; i++) {
        pontos[ordem[i]] += 5 - i;
    }
    
    // Repetir para os outros critérios
    // Busca
    for (int i = 0; i < 5; i++) ordem[i] = i;
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (resultados[ordem[j]].tempo_busca < resultados[ordem[i]].tempo_busca) {
                int temp = ordem[i];
                ordem[i] = ordem[j];
                ordem[j] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        pontos[ordem[i]] += 5 - i;
    }
    
    // Remoção
    for (int i = 0; i < 5; i++) ordem[i] = i;
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (resultados[ordem[j]].tempo_remocao < resultados[ordem[i]].tempo_remocao) {
                int temp = ordem[i];
                ordem[i] = ordem[j];
                ordem[j] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        pontos[ordem[i]] += 5 - i;
    }
    
    // Escalabilidade
    for (int i = 0; i < 5; i++) ordem[i] = i;
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (resultados[ordem[j]].fator_escalabilidade < resultados[ordem[i]].fator_escalabilidade) {
                int temp = ordem[i];
                ordem[i] = ordem[j];
                ordem[j] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        pontos[ordem[i]] += 5 - i;
    }
    
    // Memória
    for (int i = 0; i < 5; i++) ordem[i] = i;
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (resultados[ordem[j]].uso_memoria < resultados[ordem[i]].uso_memoria) {
                int temp = ordem[i];
                ordem[i] = ordem[j];
                ordem[j] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        pontos[ordem[i]] += 5 - i;
    }
    
    // Tempo de acesso
    for (int i = 0; i < 5; i++) ordem[i] = i;
    for (int i = 0; i < 4; i++) {
        for (int j = i + 1; j < 5; j++) {
            if (resultados[ordem[j]].tempo_medio_acesso < resultados[ordem[i]].tempo_medio_acesso) {
                int temp = ordem[i];
                ordem[i] = ordem[j];
                ordem[j] = temp;
            }
        }
    }
    for (int i = 0; i < 5; i++) {
        pontos[ordem[i]] += 5 - i;
    }
    
    // Encontrar a estrutura com mais pontos
    int melhor_geral = 0;
    for (int i = 1; i < 5; i++) {
        if (pontos[i] > pontos[melhor_geral]) {
            melhor_geral = i;
        }
    }
    
    printf("\n=== PONTUAÇÃO GERAL ===\n");
    for (int i = 0; i < 5; i++) {
        printf("%s: %d pontos\n", nomes_estruturas[i], pontos[i]);
    }
    
    printf("\nMelhor estrutura geral: %s com %d pontos\n", 
           nomes_estruturas[melhor_geral], pontos[melhor_geral]);
    
    // Recomendações
    printf("\n=== RECOMENDAÇÕES ===\n");
    printf("Para operações com muitas inserções: %s\n", nomes_estruturas[melhor_insercao]);
    printf("Para operações com muitas buscas: %s\n", nomes_estruturas[melhor_busca]);
    printf("Para ambientes com memória limitada: %s\n", nomes_estruturas[melhor_memoria]);
    printf("Para grandes volumes de dados: %s\n", nomes_estruturas[melhor_escala]);
}

double testar_insercao(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    printf("Testando inserção de %d elementos...\n", n_acidentes);
    
    // Inicializar estrutura vazia
    void *estrutura = NULL;
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_acidentes);
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        default:
            printf("Erro: Tipo de estrutura inválido.\n");
            return -1.0;
    }
    
    if (!estrutura) {
        printf("Erro: Falha ao criar estrutura.\n");
        return -1.0;
    }
    
    // Medir tempo de inserção
    clock_t inicio = clock();
    
    for (int i = 0; i < n_acidentes; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, &acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, &acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, &acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, &acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, &acidentes[i]);
                break;
        }
    }
    
    clock_t fim = clock();
    double tempo = (double)(fim - inicio) / CLOCKS_PER_SEC;
    
    // Liberar estrutura
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
    }
    
    return tempo;
}

double testar_busca(EstruturaDados tipo, Acidente *acidentes, int n_acidentes, int n_buscas) {
    printf("Testando busca de %d elementos...\n", n_buscas);
    
    // Inicializar estrutura e inserir acidentes
    void *estrutura = NULL;
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_acidentes);
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        default:
            printf("Erro: Tipo de estrutura inválido.\n");
            return -1.0;
    }
    
    if (!estrutura) {
        printf("Erro: Falha ao criar estrutura.\n");
        return -1.0;
    }
    
    // Inserir todos os acidentes
    for (int i = 0; i < n_acidentes; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, &acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, &acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, &acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, &acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, &acidentes[i]);
                break;
        }
    }
    
    // Preparar chaves para busca (IDs aleatórios dos acidentes)
    int *indices = (int*)malloc(n_buscas * sizeof(int));
    for (int i = 0; i < n_buscas; i++) {
        indices[i] = rand() % n_acidentes;
    }
    
    // Medir tempo de busca
    clock_t inicio = clock();
    
    for (int i = 0; i < n_buscas; i++) {
        int idx = indices[i];
        Acidente *resultado = NULL;
        
        switch (tipo) {
            case LISTA_ENCADEADA:
                resultado = lista_buscar(estrutura, acidentes[idx].id);
                break;
            case ARVORE_AVL:
                resultado = avl_buscar(estrutura, acidentes[idx].id);
                break;
            case TABELA_HASH:
                resultado = hash_buscar(estrutura, acidentes[idx].id);
                break;
            case SKIPLIST:
                resultado = skiplist_buscar(estrutura, acidentes[idx].id);
                break;
            case TRIE:
                resultado = trie_buscar(estrutura, acidentes[idx].id);
                break;
        }
    }
    
    clock_t fim = clock();
    double tempo = (double)(fim - inicio) / CLOCKS_PER_SEC;
    
    // Liberar estrutura e índices
    free(indices);
    
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
    }
    
    return tempo;
}

double testar_remocao(EstruturaDados tipo, Acidente *acidentes, int n_acidentes, int n_remocoes) {
    printf("Testando remoção de %d elementos...\n", n_remocoes);
    
    // Inicializar estrutura e inserir acidentes
    void *estrutura = NULL;
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_acidentes);
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        default:
            printf("Erro: Tipo de estrutura inválido.\n");
            return -1.0;
    }
    
    if (!estrutura) {
        printf("Erro: Falha ao criar estrutura.\n");
        return -1.0;
    }
    
    // Inserir todos os acidentes
    for (int i = 0; i < n_acidentes; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, &acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, &acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, &acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, &acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, &acidentes[i]);
                break;
        }
    }
    
    // Preparar IDs para remoção (aleatórios dos acidentes)
    int *indices = (int*)malloc(n_remocoes * sizeof(int));
    for (int i = 0; i < n_remocoes; i++) {
        indices[i] = rand() % n_acidentes;
    }
    
    // Medir tempo de remoção
    clock_t inicio = clock();
    
    for (int i = 0; i < n_remocoes; i++) {
        int idx = indices[i];
        
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_remover(estrutura, acidentes[idx].id);
                break;
            case ARVORE_AVL:
                avl_remover(estrutura, acidentes[idx].id);
                break;
            case TABELA_HASH:
                hash_remover(estrutura, acidentes[idx].id);
                break;
            case SKIPLIST:
                skiplist_remover(estrutura, acidentes[idx].id);
                break;
            case TRIE:
                trie_remover(estrutura, acidentes[idx].id);
                break;
        }
    }
    
    clock_t fim = clock();
    double tempo = (double)(fim - inicio) / CLOCKS_PER_SEC;
    
    // Liberar estrutura e índices
    free(indices);
    
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
    }
    
    return tempo;
}

double testar_escalabilidade(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    printf("Testando escalabilidade...\n");
    
    // Testar com diferentes tamanhos de conjunto de dados
    // Medimos o tempo para n/4, n/2 e n elementos, e calculamos a taxa de crescimento
    
    int tamanhos[3] = {n_acidentes / 4, n_acidentes / 2, n_acidentes};
    double tempos[3];
    
    for (int i = 0; i < 3; i++) {
        int n = tamanhos[i];
        
        // Testar inserção
        void *estrutura = NULL;
        switch (tipo) {
            case LISTA_ENCADEADA:
                estrutura = lista_criar();
                break;
            case ARVORE_AVL:
                estrutura = avl_criar();
                break;
            case TABELA_HASH:
                estrutura = hash_criar(n);
                break;
            case SKIPLIST:
                estrutura = skiplist_criar();
                break;
            case TRIE:
                estrutura = trie_criar();
                break;
            default:
                printf("Erro: Tipo de estrutura inválido.\n");
                return -1.0;
        }
        
        if (!estrutura) {
            printf("Erro: Falha ao criar estrutura.\n");
            return -1.0;
        }
        
        // Medir tempo
        clock_t inicio = clock();
        
        for (int j = 0; j < n; j++) {
            switch (tipo) {
                case LISTA_ENCADEADA:
                    lista_inserir(estrutura, &acidentes[j]);
                    break;
                case ARVORE_AVL:
                    avl_inserir(estrutura, &acidentes[j]);
                    break;
                case TABELA_HASH:
                    hash_inserir(estrutura, &acidentes[j]);
                    break;
                case SKIPLIST:
                    skiplist_inserir(estrutura, &acidentes[j]);
                    break;
                case TRIE:
                    trie_inserir(estrutura, &acidentes[j]);
                    break;
            }
        }
        
        clock_t fim = clock();
        tempos[i] = (double)(fim - inicio) / CLOCKS_PER_SEC;
        
        // Liberar estrutura
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_destruir(estrutura);
                break;
            case ARVORE_AVL:
                avl_destruir(estrutura);
                break;
            case TABELA_HASH:
                hash_destruir(estrutura);
                break;
            case SKIPLIST:
                skiplist_destruir(estrutura);
                break;
            case TRIE:
                trie_destruir(estrutura);
                break;
        }
    }
    
    // Calcular fator de escalabilidade (quanto menor, melhor)
    // Usamos a razão entre o tempo para n elementos e o tempo para n/4 elementos
    // ajustado pelo fator de crescimento (4x)
    
    double fator = (tempos[2] / tempos[0]) / 4.0;
    return fator;
}

size_t medir_uso_memoria(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    printf("Medindo uso de memória...\n");
    
    // Resetar estatísticas de memória
    resetar_estatisticas_memoria();
    
    // Criar estrutura
    void *estrutura = NULL;
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_acidentes);
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        default:
            printf("Erro: Tipo de estrutura inválido.\n");
            return 0;
    }
    
    if (!estrutura) {
        printf("Erro: Falha ao criar estrutura.\n");
        return 0;
    }
    
    // Inserir elementos (aqui assumimos que as funções de inserção usam alocar_memoria internamente)
    for (int i = 0; i < n_acidentes; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, &acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, &acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, &acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, &acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, &acidentes[i]);
                break;
        }
    }
    
    // Obter estatísticas
    size_t memoria_usada = 0;
    
    // Para simplificação, estimamos o uso de memória com base no tipo de estrutura e número de elementos
    switch (tipo) {
        case LISTA_ENCADEADA:
            // Cada nó usa aproximadamente sizeof(Acidente*) + sizeof(ponteiro para próximo)
            memoria_usada = n_acidentes * (sizeof(Acidente*) + sizeof(void*));
            break;
        case ARVORE_AVL:
            // Cada nó usa aproximadamente sizeof(Acidente*) + 2*sizeof(ponteiro para filhos) + sizeof(altura)
            memoria_usada = n_acidentes * (sizeof(Acidente*) + 2 * sizeof(void*) + sizeof(int));
            break;
        case TABELA_HASH:
            // Tabela base + nós de lista de colisão
            memoria_usada = n_acidentes * sizeof(void*) +  // Tabela base
                           n_acidentes * (sizeof(Acidente*) + sizeof(void*));  // Nós de colisão
            break;
        case SKIPLIST:
            // Estimativa grosseira: cada nó usa em média 2.5 ponteiros devido aos níveis
            memoria_usada = n_acidentes * (sizeof(Acidente*) + 2.5 * sizeof(void*));
            break;
        case TRIE:
            // Estimativa muito grosseira: cada caractere do ID gera um nó com 36 ponteiros (a-z, 0-9)
            // Assumindo IDs com média de 8 caracteres
            memoria_usada = n_acidentes * 8 * (sizeof(char) + 36 * sizeof(void*));
            break;
    }
    
    // Liberar estrutura
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
    }
    
    return memoria_usada;
}

double medir_tempo_medio_acesso(EstruturaDados tipo, Acidente *acidentes, int n_acidentes, int n_acessos) {
    printf("Medindo tempo médio de acesso...\n");
    
    // Criar e preencher estrutura
    void *estrutura = NULL;
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_acidentes);
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        default:
            printf("Erro: Tipo de estrutura inválido.\n");
            return -1.0;
    }
    
    if (!estrutura) {
        printf("Erro: Falha ao criar estrutura.\n");
        return -1.0;
    }
    
    // Inserir todos os acidentes
    for (int i = 0; i < n_acidentes; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, &acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, &acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, &acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, &acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, &acidentes[i]);
                break;
        }
    }
    
    // Gerar índices aleatórios para acesso
    int *indices = (int*)malloc(n_acessos * sizeof(int));
    for (int i = 0; i < n_acessos; i++) {
        indices[i] = rand() % n_acidentes;
    }
    
    // Medir tempo de acesso
    clock_t inicio = clock();
    
    for (int i = 0; i < n_acessos; i++) {
        int idx = indices[i];
        Acidente *resultado = NULL;
        
        switch (tipo) {
            case LISTA_ENCADEADA:
                resultado = lista_buscar(estrutura, acidentes[idx].id);
                break;
            case ARVORE_AVL:
                resultado = avl_buscar(estrutura, acidentes[idx].id);
                break;
            case TABELA_HASH:
                resultado = hash_buscar(estrutura, acidentes[idx].id);
                break;
            case SKIPLIST:
                resultado = skiplist_buscar(estrutura, acidentes[idx].id);
                break;
            case TRIE:
                resultado = trie_buscar(estrutura, acidentes[idx].id);
                break;
        }
    }
    
    clock_t fim = clock();
    double tempo_total = (double)(fim - inicio) / CLOCKS_PER_SEC;
    double tempo_medio_us = (tempo_total * 1000000.0) / n_acessos;  // Convertido para microssegundos
    
    // Liberar recursos
    free(indices);
    
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
    }
    
    return tempo_medio_us;
}

double medir_latencia_media(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    printf("Medindo latência média...\n");
    
    // Para este teste, medimos o tempo para um conjunto de operações mistas:
    // inserções, buscas e remoções
    
    // Criar estrutura
    void *estrutura = NULL;
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_acidentes);
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        default:
            printf("Erro: Tipo de estrutura inválido.\n");
            return -1.0;
    }
    
    if (!estrutura) {
        printf("Erro: Falha ao criar estrutura.\n");
        return -1.0;
    }
    
    // Número de operações para o teste
    int n_ops = n_acidentes < 1000 ? n_acidentes : 1000;
    
    // Gerar sequência aleatória de operações
    // 0 = inserir, 1 = buscar, 2 = remover
    int *operacoes = (int*)malloc(n_ops * sizeof(int));
    int *indices = (int*)malloc(n_ops * sizeof(int));
    
    for (int i = 0; i < n_ops; i++) {
        operacoes[i] = rand() % 3;
        indices[i] = rand() % n_acidentes;
    }
    
    // Inserir alguns elementos iniciais para permitir buscas e remoções
    for (int i = 0; i < n_acidentes / 4; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, &acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, &acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, &acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, &acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, &acidentes[i]);
                break;
        }
    }
    
    // Medir tempo para a sequência de operações
    clock_t inicio = clock();
    
    for (int i = 0; i < n_ops; i++) {
        int idx = indices[i];
        
        switch (operacoes[i]) {
            case 0:  // Inserir
                switch (tipo) {
                    case LISTA_ENCADEADA:
                        lista_inserir(estrutura, &acidentes[idx]);
                        break;
                    case ARVORE_AVL:
                        avl_inserir(estrutura, &acidentes[idx]);
                        break;
                    case TABELA_HASH:
                        hash_inserir(estrutura, &acidentes[idx]);
                        break;
                    case SKIPLIST:
                        skiplist_inserir(estrutura, &acidentes[idx]);
                        break;
                    case TRIE:
                        trie_inserir(estrutura, &acidentes[idx]);
                        break;
                }
                break;
                
            case 1:  // Buscar
                switch (tipo) {
                    case LISTA_ENCADEADA:
                        lista_buscar(estrutura, acidentes[idx].id);
                        break;
                    case ARVORE_AVL:
                        avl_buscar(estrutura, acidentes[idx].id);
                        break;
                    case TABELA_HASH:
                        hash_buscar(estrutura, acidentes[idx].id);
                        break;
                    case SKIPLIST:
                        skiplist_buscar(estrutura, acidentes[idx].id);
                        break;
                    case TRIE:
                        trie_buscar(estrutura, acidentes[idx].id);
                        break;
                }
                break;
                
            case 2:  // Remover
                switch (tipo) {
                    case LISTA_ENCADEADA:
                        lista_remover(estrutura, acidentes[idx].id);
                        break;
                    case ARVORE_AVL:
                        avl_remover(estrutura, acidentes[idx].id);
                        break;
                    case TABELA_HASH:
                        hash_remover(estrutura, acidentes[idx].id);
                        break;
                    case SKIPLIST:
                        skiplist_remover(estrutura, acidentes[idx].id);
                        break;
                    case TRIE:
                        trie_remover(estrutura, acidentes[idx].id);
                        break;
                }
                break;
        }
    }
    
    clock_t fim = clock();
    double tempo_total = (double)(fim - inicio) / CLOCKS_PER_SEC;
    double latencia_media_us = (tempo_total * 1000000.0) / n_ops;  // Convertido para microssegundos
    
    // Liberar recursos
    free(operacoes);
    free(indices);
    
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
    }
    
    return latencia_media_us;
}

int contar_colisoes(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    if (tipo != TABELA_HASH) {
        return 0;  // Só faz sentido para tabela hash
    }
    
    printf("Contando colisões de hash...\n");
    
    // Esta função é uma simulação, pois não temos acesso direto às colisões internas
    // Em uma implementação real, a função de hash seria modificada para contar colisões
    
    // Simularemos contando colisões com nossa própria tabela
    int tamanho_tabela = n_acidentes;
    int *contagem = (int*)calloc(tamanho_tabela, sizeof(int));
    int colisoes = 0;
    
    for (int i = 0; i < n_acidentes; i++) {
        // Hash simples baseado no ID
        const char *id = acidentes[i].id;
        unsigned long hash = 5381;
        int c;
        
        while ((c = *id++)) {
            hash = ((hash << 5) + hash) + c;  // hash * 33 + c
        }
        
        int indice = hash % tamanho_tabela;
        
        // Contar colisão se já houver elemento neste índice
        if (contagem[indice] > 0) {
            colisoes++;
        }
        
        contagem[indice]++;
    }
    
    free(contagem);
    return colisoes;
}