/**
 * memoria.c
 * 
 * Funções para gerenciamento e monitoramento de memória.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "memoria.h"

// Estatísticas de memória
static struct {
    size_t total_alocado;
    size_t total_liberado;
    int num_alocacoes;
    int num_liberacoes;
    size_t pico_memoria;
} estatisticas_memoria = {0};

void* alocar_memoria(size_t tamanho) {
    void* ptr = malloc(tamanho);
    
    if (ptr) {
        estatisticas_memoria.total_alocado += tamanho;
        estatisticas_memoria.num_alocacoes++;
        
        size_t atual = estatisticas_memoria.total_alocado - estatisticas_memoria.total_liberado;
        if (atual > estatisticas_memoria.pico_memoria) {
            estatisticas_memoria.pico_memoria = atual;
        }
    }
    
    return ptr;
}

void liberar_memoria(void* ptr, size_t tamanho) {
    if (ptr) {
        free(ptr);
        estatisticas_memoria.total_liberado += tamanho;
        estatisticas_memoria.num_liberacoes++;
    }
}

void imprimir_estatisticas_memoria() {
    printf("\n=== Estatísticas de Uso de Memória ===\n");
    printf("Total alocado: %zu bytes (%.2f MB)\n", 
           estatisticas_memoria.total_alocado, 
           estatisticas_memoria.total_alocado / (1024.0 * 1024.0));
    printf("Total liberado: %zu bytes (%.2f MB)\n", 
           estatisticas_memoria.total_liberado,
           estatisticas_memoria.total_liberado / (1024.0 * 1024.0));
    printf("Uso atual: %zu bytes (%.2f MB)\n", 
           estatisticas_memoria.total_alocado - estatisticas_memoria.total_liberado,
           (estatisticas_memoria.total_alocado - estatisticas_memoria.total_liberado) / (1024.0 * 1024.0));
    printf("Pico de memória: %zu bytes (%.2f MB)\n", 
           estatisticas_memoria.pico_memoria,
           estatisticas_memoria.pico_memoria / (1024.0 * 1024.0));
    printf("Número de alocações: %d\n", estatisticas_memoria.num_alocacoes);
    printf("Número de liberações: %d\n", estatisticas_memoria.num_liberacoes);
    printf("Possível vazamento: %zu bytes (%.2f MB)\n", 
           estatisticas_memoria.total_alocado - estatisticas_memoria.total_liberado,
           (estatisticas_memoria.total_alocado - estatisticas_memoria.total_liberado) / (1024.0 * 1024.0));
}

void resetar_estatisticas_memoria() {
    memset(&estatisticas_memoria, 0, sizeof(estatisticas_memoria));
}

size_t obter_memoria_disponivel() {
    // Esta função é apenas uma aproximação e varia por sistema operacional
    // Em um sistema real, usaríamos chamadas específicas do SO
    
    // Valor fictício para simulação: 4GB
    return 4UL * 1024 * 1024 * 1024;
}

void verificar_vazamentos_memoria() {
    size_t potencial_vazamento = estatisticas_memoria.total_alocado - estatisticas_memoria.total_liberado;
    
    if (potencial_vazamento > 0) {
        printf("\n=== ALERTA: Potencial Vazamento de Memória Detectado ===\n");
        printf("Total não liberado: %zu bytes (%.2f MB)\n", 
               potencial_vazamento, potencial_vazamento / (1024.0 * 1024.0));
        printf("Número de alocações: %d\n", estatisticas_memoria.num_alocacoes);
        printf("Número de liberações: %d\n", estatisticas_memoria.num_liberacoes);
        printf("Diferença: %d operações\n", 
               estatisticas_memoria.num_alocacoes - estatisticas_memoria.num_liberacoes);
    } else {
        printf("\n=== Sem vazamentos de memória detectados ===\n");
        printf("Todas as alocações foram liberadas corretamente.\n");
    }
}