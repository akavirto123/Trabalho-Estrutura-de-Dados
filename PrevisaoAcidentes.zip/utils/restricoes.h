/**
 * restricoes.h
 * 
 * Funções para aplicar restrições aos testes de estruturas de dados,
 * simulando diferentes cenários de limitação de recursos.
 */

#ifndef RESTRICOES_H
#define RESTRICOES_H

#include "tipos.h"

/**
 * Aplica uma restrição de memória.
 * 
 * @param tipo Tipo de restrição de memória
 * @return 1 se aplicado com sucesso, 0 caso contrário
 */
int aplicar_restricao_memoria(RestricaoMemoria tipo);

/**
 * Aplica uma restrição de processamento.
 * 
 * @param tipo Tipo de restrição de processamento
 * @return 1 se aplicado com sucesso, 0 caso contrário
 */
int aplicar_restricao_processamento(RestricaoProcessamento tipo);

/**
 * Aplica uma restrição de latência.
 * 
 * @param tipo Tipo de restrição de latência
 * @return 1 se aplicado com sucesso, 0 caso contrário
 */
int aplicar_restricao_latencia(RestricaoLatencia tipo);

/**
 * Aplica uma restrição de dados.
 * 
 * @param tipo Tipo de restrição de dados
 * @return 1 se aplicado com sucesso, 0 caso contrário
 */
int aplicar_restricao_dados(RestricaoDados tipo);

/**
 * Aplica uma restrição algorítmica.
 * 
 * @param tipo Tipo de restrição algorítmica
 * @return 1 se aplicado com sucesso, 0 caso contrário
 */
int aplicar_restricao_algoritmica(RestricaoAlgoritmica tipo);

/**
 * Remove todas as restrições aplicadas.
 * 
 * @return 1 se sucesso, 0 caso contrário
 */
int remover_todas_restricoes();

/**
 * Executa um benchmark com uma restrição específica aplicada.
 * 
 * @param estrutura Tipo de estrutura de dados
 * @param restricao_tipo Tipo de restrição
 * @param restricao_valor Valor específico da restrição
 * @param acidentes Array de acidentes para teste
 * @param n_acidentes Número de acidentes
 */
void executar_benchmark_com_restricao(
    EstruturaDados estrutura, 
    int restricao_tipo, 
    int restricao_valor,
    Acidente *acidentes, 
    int n_acidentes
);

/**
 * Obtém uma descrição textual de uma restrição.
 * 
 * @param tipo_restricao Tipo geral da restrição (0-4)
 * @param valor_restricao Valor específico da restrição
 * @param buffer Buffer para armazenar a descrição
 * @param tamanho Tamanho do buffer
 */
void obter_descricao_restricao(int tipo_restricao, int valor_restricao, 
                              char *buffer, size_t tamanho);

#endif /* RESTRICOES_H */
