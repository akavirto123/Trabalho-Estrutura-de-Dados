/**
 * impressao.c
 * 
 * Implementação de funções para impressão de dados.
 */

#include <stdio.h>
#include "tipos.h"

// Implementação da função para imprimir os dados de um acidente
void imprimir_acidente(const Acidente *acidente) {
    printf("ID: %d\n", acidente->id);
    printf("Data: %02d/%02d/%04d - %02d:%02d\n", 
           acidente->data.dia, acidente->data.mes, acidente->data.ano,
           acidente->horario.hora, acidente->horario.minuto);
    printf("Local: BR-%s km %.1f, %s-%s (Lat: %.6f, Long: %.6f)\n",
           acidente->local.br, acidente->local.km,
           acidente->local.municipio, acidente->local.uf,
           acidente->local.latitude, acidente->local.longitude);
    printf("Classificação: %s | Causa: %s\n",
           acidente->condicoes.classificacao, acidente->condicoes.causa);
    printf("Envolvidos: %d pessoas (%d feridos, %d mortos), %d veículos\n",
           acidente->condicoes.pessoas_envolvidas, acidente->condicoes.feridos,
           acidente->condicoes.mortos, acidente->condicoes.veiculos);
    printf("---------------------------------------------------\n");
}