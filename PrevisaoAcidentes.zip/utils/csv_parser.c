/**
 * csv_parser.c
 * 
 * Implementação das funções para análise e carregamento de 
 * arquivos CSV contendo dados de acidentes de trânsito.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "csv_parser.h"

// Tamanho máximo de uma linha no arquivo CSV
#define MAX_LINHA 1024
#define MAX_CAMPO 256

/**
 * Função para dividir uma linha CSV em campos individuais
 * 
 * @param linha Linha a ser dividida
 * @param campos Vetor para armazenar os campos extraídos
 * @param max_campos Número máximo de campos a serem extraídos
 * @return Número de campos extraídos
 */
static int dividir_csv(char *linha, char **campos, int max_campos) {
    int campo_atual = 0;
    int pos = 0;
    int dentro_aspas = 0;
    char *inicio_campo = linha;
    
    while (linha[pos] != '\0' && campo_atual < max_campos) {
        // Verifica se é uma aspas
        if (linha[pos] == '"') {
            dentro_aspas = !dentro_aspas;
        }
        // Se encontrar um delimitador e não estiver dentro de aspas, processa o campo
        else if (linha[pos] == ';' && !dentro_aspas) {
            linha[pos] = '\0';  // Substitui o ponto-e-vírgula por terminador
            campos[campo_atual++] = inicio_campo;
            inicio_campo = &linha[pos + 1];
        }
        pos++;
    }
    
    // Adiciona o último campo se existir texto após o último delimitador
    if (*inicio_campo != '\0' && campo_atual < max_campos) {
        campos[campo_atual++] = inicio_campo;
    }
    
    return campo_atual;
}

/**
 * Remove aspas e espaços extras de uma string
 * 
 * @param str String a ser limpa
 */
static void limpar_campo(char *str) {
    int len = strlen(str);
    
    // Remove espaços iniciais
    int inicio = 0;
    while (isspace((unsigned char)str[inicio])) {
        inicio++;
    }
    
    // Remove aspas iniciais
    if (str[inicio] == '"') {
        inicio++;
    }
    
    // Remove espaços finais e aspas
    int fim = len - 1;
    while (fim >= 0 && (isspace((unsigned char)str[fim]) || str[fim] == '"')) {
        fim--;
    }
    
    // Ajusta o terminador
    str[fim + 1] = '\0';
    
    // Move caracteres se necessário
    if (inicio > 0) {
        memmove(str, str + inicio, fim - inicio + 2);
    }
}

// Implementação das funções declaradas no header

Acidente* carregar_csv(const char *caminho_arquivo, int *n_acidentes, int max_acidentes) {
    FILE *arquivo = fopen(caminho_arquivo, "r");
    if (!arquivo) {
        perror("Erro ao abrir arquivo CSV");
        *n_acidentes = 0;
        return NULL;
    }
    
    // Aloca memória para armazenar os acidentes
    Acidente *acidentes = (Acidente*) malloc(max_acidentes * sizeof(Acidente));
    if (!acidentes) {
        perror("Erro ao alocar memória para acidentes");
        fclose(arquivo);
        *n_acidentes = 0;
        return NULL;
    }
    
    char linha[MAX_LINHA];
    char *campos[50];  // Suporta até 50 campos por linha
    int count = 0;
    
    // Lê a primeira linha (cabeçalho) e descarta
    if (fgets(linha, sizeof(linha), arquivo) == NULL) {
        fprintf(stderr, "Arquivo CSV vazio ou inválido\n");
        free(acidentes);
        fclose(arquivo);
        *n_acidentes = 0;
        return NULL;
    }
    
    // Processa as linhas de dados
    while (fgets(linha, sizeof(linha), arquivo) && count < max_acidentes) {
        // Remove o caractere de nova linha, se presente
        size_t len = strlen(linha);
        if (len > 0 && (linha[len-1] == '\n' || linha[len-1] == '\r')) {
            linha[--len] = '\0';
        }
        if (len > 0 && (linha[len-1] == '\n' || linha[len-1] == '\r')) {
            linha[--len] = '\0';
        }
        
        // Divide a linha em campos
        int num_campos = dividir_csv(linha, campos, 50);
        
        // Verifica se há campos suficientes
        if (num_campos < 20) {
            fprintf(stderr, "Aviso: Linha com número insuficiente de campos: %d\n", num_campos);
            continue;
        }
        
        // Limpa e processa cada campo
        for (int i = 0; i < num_campos; i++) {
            limpar_campo(campos[i]);
        }
        
        // Preenche a estrutura de Acidente
        Acidente acidente;
        memset(&acidente, 0, sizeof(Acidente));
        
        // Mapeamento baseado no cabeçalho do arquivo
        // Convertemos o ID para string em vez de inteiro
        strncpy(acidente.id, campos[0], sizeof(acidente.id) - 1);

        // Data (formato YYYY-MM-DD)
        acidente.data = parsear_data(campos[1]);
        
        // Horário (formato HH:MM:SS)
        acidente.horario = parsear_horario(campos[3]);
        
        // Localização
        strncpy(acidente.local.uf, campos[4], sizeof(acidente.local.uf) - 1);
        strncpy(acidente.local.br, campos[5], sizeof(acidente.local.br) - 1);
        acidente.local.km = str_para_double(campos[6], 0.0);
        strncpy(acidente.local.municipio, campos[7], sizeof(acidente.local.municipio) - 1);
        
        // Condições do acidente
        strncpy(acidente.condicoes.causa, campos[8], sizeof(acidente.condicoes.causa) - 1);
        strncpy(acidente.condicoes.classificacao, campos[9], sizeof(acidente.condicoes.classificacao) - 1);
        strncpy(acidente.condicoes.fase_dia, campos[11], sizeof(acidente.condicoes.fase_dia) - 1);
        strncpy(acidente.condicoes.condicao_meteo, campos[13], sizeof(acidente.condicoes.condicao_meteo) - 1);
        strncpy(acidente.condicoes.tipo_pista, campos[14], sizeof(acidente.condicoes.tipo_pista) - 1);
        
        // Dados numéricos
        acidente.condicoes.pessoas_envolvidas = str_para_int(campos[17], 0);
        acidente.condicoes.mortos = str_para_int(campos[18], 0);
        
        // Feridos (soma de feridos leves e graves)
        int feridos_leves = str_para_int(campos[19], 0);
        int feridos_graves = str_para_int(campos[20], 0);
        acidente.condicoes.feridos = feridos_leves + feridos_graves;
        
        // Número de veículos
        acidente.condicoes.veiculos = str_para_int(campos[24], 0);
        
        // Coordenadas geográficas
        if (num_campos > 25) acidente.local.latitude = str_para_double(campos[25], 0.0);
        if (num_campos > 26) acidente.local.longitude = str_para_double(campos[26], 0.0);
        
        // Adiciona o acidente ao vetor
        acidentes[count++] = acidente;
    }
    
    fclose(arquivo);
    *n_acidentes = count;
    
    // Se não carregou nenhum acidente, libera a memória e retorna NULL
    if (count == 0) {
        free(acidentes);
        return NULL;
    }
    
    return acidentes;
}

Data parsear_data(const char *data_str) {
    Data data = {0, 0, 0};
    
    if (!data_str || strlen(data_str) < 8) {
        return data;
    }
    
    // Formatos possíveis: DD/MM/AAAA ou AAAA-MM-DD
    int dia, mes, ano;
    
    if (strchr(data_str, '/')) {
        // Formato DD/MM/AAAA
        sscanf(data_str, "%d/%d/%d", &dia, &mes, &ano);
    } else if (strchr(data_str, '-')) {
        // Formato AAAA-MM-DD
        sscanf(data_str, "%d-%d-%d", &ano, &mes, &dia);
    } else {
        return data;  // Formato não reconhecido
    }
    
    // Validação simples
    if (dia >= 1 && dia <= 31 && mes >= 1 && mes <= 12) {
        data.dia = dia;
        data.mes = mes;
        data.ano = ano;
    }
    
    return data;
}

Horario parsear_horario(const char *hora_str) {
    Horario horario = {0, 0};
    
    if (!hora_str || strlen(hora_str) < 3) {
        return horario;
    }
    
    // Formato esperado: HH:MM
    int hora, minuto;
    
    if (sscanf(hora_str, "%d:%d", &hora, &minuto) == 2) {
        if (hora >= 0 && hora <= 23 && minuto >= 0 && minuto <= 59) {
            horario.hora = hora;
            horario.minuto = minuto;
        }
    }
    
    return horario;
}

int eh_numero(const char *str) {
    if (!str || *str == '\0') {
        return 0;
    }
    
    // Permite números negativos
    if (*str == '-') {
        str++;
    }
    
    // Verifica se todos os caracteres são dígitos
    while (*str) {
        if (!isdigit((unsigned char)*str) && *str != '.') {
            return 0;
        }
        str++;
    }
    
    return 1;
}

int str_para_int(const char *str, int padrao) {
    if (!str || !eh_numero(str)) {
        return padrao;
    }
    
    return atoi(str);
}

double str_para_double(const char *str, double padrao) {
    if (!str || strlen(str) == 0) {
        return padrao;
    }
    
    // Substitui vírgula por ponto (para compatibilidade com padrão brasileiro)
    char *temp = strdup(str);
    if (!temp) {
        return padrao;
    }
    
    for (char *p = temp; *p; p++) {
        if (*p == ',') {
            *p = '.';
        }
    }
    
    double resultado = atof(temp);
    free(temp);
    
    return resultado;
}
