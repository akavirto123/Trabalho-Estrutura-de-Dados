/**
 * restricoes.c
 * 
 * Implementação de funções para aplicar restrições aos testes,
 * simulando diferentes cenários de limitação de recursos.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "restricoes.h"

// Estado atual das restrições aplicadas
static struct {
    int memoria_ativa;
    int processamento_ativo;
    int latencia_ativa;
    int dados_ativos;
    int algoritmica_ativa;
    
    RestricaoMemoria tipo_memoria;
    RestricaoProcessamento tipo_processamento;
    RestricaoLatencia tipo_latencia;
    RestricaoDados tipo_dados;
    RestricaoAlgoritmica tipo_algoritmica;
} estado_restricoes = {0};

// Funções para simular restrições de memória
void simular_limite_ram(int mb) {
    printf("Simulando limite de RAM: %d MB\n", mb);
    printf("Alocando memória temporária para simular pressão na RAM...\n");
    
    const int MB = 1024 * 1024;
    
    // Alocamos metade da memória disponível para simular pressão
    int blocos = mb / 2;
    void **ponteiros = (void**)malloc(blocos * sizeof(void*));
    
    if (!ponteiros) {
        printf("Erro ao alocar array de ponteiros.\n");
        return;
    }
    
    // Inicializa com NULL para segurança
    for (int i = 0; i < blocos; i++) {
        ponteiros[i] = NULL;
    }
    
    // Tenta alocar blocos de 1MB
    int alocados = 0;
    for (int i = 0; i < blocos; i++) {
        ponteiros[i] = malloc(MB);
        if (ponteiros[i]) {
            // Escreve alguns dados para garantir que a memória seja realmente alocada
            memset(ponteiros[i], 1, MB);
            alocados++;
        } else {
            break;
        }
    }
    
    printf("Alocados %d MB de %d MB solicitados.\n", alocados, blocos);
    printf("Memória disponível limitada a aproximadamente %d MB.\n", mb - alocados);
    
    // Libera alguns blocos aleatoriamente para criar fragmentação
    int liberados = alocados / 3;
    for (int i = 0; i < liberados; i++) {
        int idx = rand() % blocos;
        if (ponteiros[idx]) {
            free(ponteiros[idx]);
            ponteiros[idx] = NULL;
        }
    }
    
    printf("Fragmentação de memória simulada: %d blocos liberados aleatoriamente.\n", liberados);
    
    // Mantém o restante alocado para simular memória restrita
    printf("Memória restrita simulada com sucesso.\n");
    
    // Não liberamos todos os ponteiros para manter a pressão na memória
    // Em uma aplicação real, isso seria um vazamento de memória
    // Aqui é intencional como parte da simulação
    free(ponteiros);
}

void simular_swap_lento() {
    printf("Simulando swap lento...\n");
    printf("Esta simulação irá tornar operações de memória mais lentas.\n");
    
    // Aloca um grande bloco para forçar swap
    const size_t GB = 1024 * 1024 * 1024;
    void *grande_bloco = malloc(2 * GB);
    
    if (grande_bloco) {
        printf("Alocado bloco grande para forçar uso de swap.\n");
        // Escreve dados no bloco grande para garantir alocação
        for (size_t i = 0; i < 2 * GB; i += 1024 * 1024) {
            ((char*)grande_bloco)[i] = (char)(i & 0xFF);
        }
        // Não liberamos o bloco para manter a pressão no sistema
    } else {
        printf("Não foi possível alocar bloco grande. Simulando swap lento de outra maneira.\n");
        // Simulação alternativa: apenas adiciona atrasos em operações
    }
}

int aplicar_restricao_memoria(RestricaoMemoria tipo) {
    if (estado_restricoes.memoria_ativa) {
        printf("Já existe uma restrição de memória ativa. Remova-a primeiro.\n");
        return 0;
    }
    
    estado_restricoes.memoria_ativa = 1;
    estado_restricoes.tipo_memoria = tipo;
    
    switch (tipo) {
        case R1_LIMITE_RAM:
            printf("Aplicando restrição R1: Limitação de RAM (128MB)\n");
            simular_limite_ram(128);
            break;
        case R2_FRAGMENTACAO:
            printf("Aplicando restrição R2: Fragmentação de memória\n");
            simular_limite_ram(256);  // Causa mais fragmentação
            break;
        case R3_VAZAMENTO:
            printf("Aplicando restrição R3: Vazamento de memória\n");
            printf("Esta restrição simulará um vazamento gradual de memória.\n");
            // Implementação: criar um thread que gradualmente aloca memória
            break;
        case R4_SWAP_LENTO:
            printf("Aplicando restrição R4: Swap lento\n");
            simular_swap_lento();
            break;
        case R5_FALHA_ALOCACAO:
            printf("Aplicando restrição R5: Falhas de alocação\n");
            printf("Esta restrição fará com que alocações ocasionalmente falhem.\n");
            // Implementação: sobrescrever malloc com versão que ocasionalmente falha
            break;
        default:
            printf("Tipo de restrição de memória desconhecido.\n");
            estado_restricoes.memoria_ativa = 0;
            return 0;
    }
    
    return 1;
}

// Funções para simular restrições de processamento
void simular_single_core() {
    printf("Simulando limitação a single-core...\n");
    // Na prática, limitaríamos a afinidade do processo a um único core
    // Aqui, apenas simulamos adicionando atrasos em operações paralelas
}

void simular_cpu_lenta() {
    printf("Simulando CPU lenta...\n");
    // Simulamos adicionando atrasos em operações
}

int aplicar_restricao_processamento(RestricaoProcessamento tipo) {
    if (estado_restricoes.processamento_ativo) {
        printf("Já existe uma restrição de processamento ativa. Remova-a primeiro.\n");
        return 0;
    }
    
    estado_restricoes.processamento_ativo = 1;
    estado_restricoes.tipo_processamento = tipo;
    
    switch (tipo) {
        case R6_SINGLE_CORE:
            printf("Aplicando restrição R6: Limitação a single-core\n");
            simular_single_core();
            break;
        case R7_CPU_LENTA:
            printf("Aplicando restrição R7: CPU lenta\n");
            simular_cpu_lenta();
            break;
        case R8_INTERRUPCOES:
            printf("Aplicando restrição R8: Interrupções frequentes\n");
            printf("Esta restrição simulará interrupções frequentes do sistema.\n");
            break;
        case R9_PRIORIDADE_BAIXA:
            printf("Aplicando restrição R9: Prioridade de processo baixa\n");
            printf("Esta restrição reduzirá a prioridade do processo nas operações de CPU.\n");
            break;
        case R10_CONTENCAO:
            printf("Aplicando restrição R10: Contenção de recursos\n");
            printf("Esta restrição simulará contenção de recursos de CPU com outros processos.\n");
            break;
        default:
            printf("Tipo de restrição de processamento desconhecido.\n");
            estado_restricoes.processamento_ativo = 0;
            return 0;
    }
    
    return 1;
}

// Funções para simular restrições de latência
void simular_rede_baixa() {
    printf("Simulando rede de baixa velocidade...\n");
    // Simulamos adicionando atrasos em operações de E/S
}

int aplicar_restricao_latencia(RestricaoLatencia tipo) {
    if (estado_restricoes.latencia_ativa) {
        printf("Já existe uma restrição de latência ativa. Remova-a primeiro.\n");
        return 0;
    }
    
    estado_restricoes.latencia_ativa = 1;
    estado_restricoes.tipo_latencia = tipo;
    
    switch (tipo) {
        case R11_REDE_BAIXA:
            printf("Aplicando restrição R11: Rede de baixa velocidade\n");
            simular_rede_baixa();
            break;
        case R12_LATENCIA_ALTA:
            printf("Aplicando restrição R12: Latência alta\n");
            printf("Esta restrição simulará alta latência nas operações.\n");
            break;
        case R13_CONEXAO_INSTAVEL:
            printf("Aplicando restrição R13: Conexão instável\n");
            printf("Esta restrição simulará instabilidade na conexão.\n");
            break;
        case R14_TIMEOUT:
            printf("Aplicando restrição R14: Timeouts frequentes\n");
            printf("Esta restrição simulará timeouts frequentes nas operações.\n");
            break;
        case R15_DISCO_LENTO:
            printf("Aplicando restrição R15: Disco lento\n");
            printf("Esta restrição simulará um disco de baixa velocidade.\n");
            break;
        default:
            printf("Tipo de restrição de latência desconhecido.\n");
            estado_restricoes.latencia_ativa = 0;
            return 0;
    }
    
    return 1;
}

// Funções para simular restrições de dados
void simular_dados_corrompidos() {
    printf("Simulando dados corrompidos...\n");
    // Aqui poderíamos modificar alguns dados para simular corrupção
}

int aplicar_restricao_dados(RestricaoDados tipo) {
    if (estado_restricoes.dados_ativos) {
        printf("Já existe uma restrição de dados ativa. Remova-a primeiro.\n");
        return 0;
    }
    
    estado_restricoes.dados_ativos = 1;
    estado_restricoes.tipo_dados = tipo;
    
    switch (tipo) {
        case R16_DADOS_CORROMPIDOS:
            printf("Aplicando restrição R16: Dados corrompidos\n");
            simular_dados_corrompidos();
            break;
        case R17_DADOS_INCOMPLETOS:
            printf("Aplicando restrição R17: Dados incompletos\n");
            printf("Esta restrição simulará dados incompletos nas operações.\n");
            break;
        case R18_DADOS_DUPLICADOS:
            printf("Aplicando restrição R18: Dados duplicados\n");
            printf("Esta restrição simulará dados duplicados nas operações.\n");
            break;
        case R19_DADOS_DESATUALIZADOS:
            printf("Aplicando restrição R19: Dados desatualizados\n");
            printf("Esta restrição simulará dados desatualizados nas operações.\n");
            break;
        case R20_DADOS_GRANDE_VOLUME:
            printf("Aplicando restrição R20: Dados em grande volume\n");
            printf("Esta restrição simulará operações com dados em grande volume.\n");
            break;
        default:
            printf("Tipo de restrição de dados desconhecido.\n");
            estado_restricoes.dados_ativos = 0;
            return 0;
    }
    
    return 1;
}

// Funções para simular restrições algorítmicas
void simular_substituir_estrutura() {
    printf("Simulando substituição de estrutura eficiente por ineficiente...\n");
    // Aqui poderíamos substituir implementações eficientes por ineficientes
}

int aplicar_restricao_algoritmica(RestricaoAlgoritmica tipo) {
    if (estado_restricoes.algoritmica_ativa) {
        printf("Já existe uma restrição algorítmica ativa. Remova-a primeiro.\n");
        return 0;
    }
    
    estado_restricoes.algoritmica_ativa = 1;
    estado_restricoes.tipo_algoritmica = tipo;
    
    switch (tipo) {
        case R21_SUBSTITUIR_ESTRUTURA:
            printf("Aplicando restrição R21: Substituição de estrutura eficiente\n");
            simular_substituir_estrutura();
            break;
        case R22_ALGORITMO_QUADRATICO:
            printf("Aplicando restrição R22: Algoritmo de complexidade quadrática\n");
            printf("Esta restrição substituirá algoritmos eficientes por versões O(n²).\n");
            break;
        case R23_RECURSAO_PROFUNDA:
            printf("Aplicando restrição R23: Recursão profunda\n");
            printf("Esta restrição forçará uso de recursão profunda nas operações.\n");
            break;
        case R24_COLISOES_HASH:
            printf("Aplicando restrição R24: Colisões em hash\n");
            printf("Esta restrição aumentará colisões em operações de hash.\n");
            break;
        case R25_LOCKS_EXCESSIVOS:
            printf("Aplicando restrição R25: Locks excessivos\n");
            printf("Esta restrição adicionará locks excessivos nas operações.\n");
            break;
        default:
            printf("Tipo de restrição algorítmica desconhecido.\n");
            estado_restricoes.algoritmica_ativa = 0;
            return 0;
    }
    
    return 1;
}

int remover_todas_restricoes() {
    printf("Removendo todas as restrições aplicadas...\n");
    
    // Resetar estado
    memset(&estado_restricoes, 0, sizeof(estado_restricoes));
    
    printf("Todas as restrições foram removidas.\n");
    return 1;
}

void executar_benchmark_com_restricao(
    EstruturaDados estrutura, 
    int restricao_tipo, 
    int restricao_valor,
    Acidente *acidentes, 
    int n_acidentes
) {
    char descricao[256];
    obter_descricao_restricao(restricao_tipo, restricao_valor, descricao, sizeof(descricao));
    
    printf("\n=== Benchmark com Restrição: %s ===\n", descricao);
    
    // Aplicar restrição
    int sucesso = 0;
    switch (restricao_tipo) {
        case 0: // Memória
            sucesso = aplicar_restricao_memoria((RestricaoMemoria)restricao_valor);
            break;
        case 1: // Processamento
            sucesso = aplicar_restricao_processamento((RestricaoProcessamento)restricao_valor);
            break;
        case 2: // Latência
            sucesso = aplicar_restricao_latencia((RestricaoLatencia)restricao_valor);
            break;
        case 3: // Dados
            sucesso = aplicar_restricao_dados((RestricaoDados)restricao_valor);
            break;
        case 4: // Algorítmica
            sucesso = aplicar_restricao_algoritmica((RestricaoAlgoritmica)restricao_valor);
            break;
        default:
            printf("Tipo de restrição desconhecido.\n");
            return;
    }
    
    if (!sucesso) {
        printf("Falha ao aplicar restrição. Benchmark cancelado.\n");
        return;
    }
    
    // Executar benchmark para a estrutura especificada
    printf("Executando benchmark sob condições restritas...\n");
    // Aqui chamaria a função adequada para benchmarking
    
    // Remover restrição após o teste
    remover_todas_restricoes();
}

void obter_descricao_restricao(int tipo_restricao, int valor_restricao, 
                              char *buffer, size_t tamanho) {
    const char *tipo_str = "Desconhecida";
    const char *valor_str = "Desconhecida";
    
    switch (tipo_restricao) {
        case 0: // Memória
            tipo_str = "Memória";
            switch (valor_restricao) {
                case R1_LIMITE_RAM: valor_str = "Limite de RAM (128MB)"; break;
                case R2_FRAGMENTACAO: valor_str = "Fragmentação de memória"; break;
                case R3_VAZAMENTO: valor_str = "Vazamento de memória"; break;
                case R4_SWAP_LENTO: valor_str = "Swap lento"; break;
                case R5_FALHA_ALOCACAO: valor_str = "Falhas de alocação"; break;
            }
            break;
        case 1: // Processamento
            tipo_str = "Processamento";
            switch (valor_restricao) {
                case R6_SINGLE_CORE: valor_str = "Single-core"; break;
                case R7_CPU_LENTA: valor_str = "CPU lenta"; break;
                case R8_INTERRUPCOES: valor_str = "Interrupções frequentes"; break;
                case R9_PRIORIDADE_BAIXA: valor_str = "Prioridade baixa"; break;
                case R10_CONTENCAO: valor_str = "Contenção de recursos"; break;
            }
            break;
        case 2: // Latência
            tipo_str = "Latência";
            switch (valor_restricao) {
                case R11_REDE_BAIXA: valor_str = "Rede de baixa velocidade"; break;
                case R12_LATENCIA_ALTA: valor_str = "Latência alta"; break;
                case R13_CONEXAO_INSTAVEL: valor_str = "Conexão instável"; break;
                case R14_TIMEOUT: valor_str = "Timeouts frequentes"; break;
                case R15_DISCO_LENTO: valor_str = "Disco lento"; break;
            }
            break;
        case 3: // Dados
            tipo_str = "Dados";
            switch (valor_restricao) {
                case R16_DADOS_CORROMPIDOS: valor_str = "Dados corrompidos"; break;
                case R17_DADOS_INCOMPLETOS: valor_str = "Dados incompletos"; break;
                case R18_DADOS_DUPLICADOS: valor_str = "Dados duplicados"; break;
                case R19_DADOS_DESATUALIZADOS: valor_str = "Dados desatualizados"; break;
                case R20_DADOS_GRANDE_VOLUME: valor_str = "Grande volume de dados"; break;
            }
            break;
        case 4: // Algorítmica
            tipo_str = "Algorítmica";
            switch (valor_restricao) {
                case R21_SUBSTITUIR_ESTRUTURA: valor_str = "Substituição de estrutura eficiente"; break;
                case R22_ALGORITMO_QUADRATICO: valor_str = "Algoritmo quadrático"; break;
                case R23_RECURSAO_PROFUNDA: valor_str = "Recursão profunda"; break;
                case R24_COLISOES_HASH: valor_str = "Colisões em hash"; break;
                case R25_LOCKS_EXCESSIVOS: valor_str = "Locks excessivos"; break;
            }
            break;
    }
    
    snprintf(buffer, tamanho, "Restrição de %s: %s", tipo_str, valor_str);
}