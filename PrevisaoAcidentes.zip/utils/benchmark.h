/**
 * benchmark.h
 * 
 * Funções para benchmark e análise de desempenho das diferentes 
 * estruturas de dados.
 */

#ifndef BENCHMARK_H
#define BENCHMARK_H

#include "tipos.h"

/**
 * Realiza benchmarks em uma estrutura de dados específica.
 * 
 * @param tipo Tipo da estrutura a ser testada
 * @param acidentes Array de acidentes para os testes
 * @param n_acidentes Número de acidentes no array
 */
void benchmark_estrutura(EstruturaDados tipo, Acidente *acidentes, int n_acidentes);

/**
 * Imprime os resultados comparativos do benchmark.
 */
void imprimir_resultados_benchmark();

/**
 * Realiza teste de inserção em uma estrutura específica.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes para os testes
 * @param n_acidentes Número de acidentes
 * @return Tempo gasto na operação (em segundos)
 */
double testar_insercao(EstruturaDados tipo, Acidente *acidentes, int n_acidentes);

/**
 * Realiza teste de busca em uma estrutura específica.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes para busca
 * @param n_acidentes Número de acidentes
 * @param n_buscas Número de buscas a serem realizadas
 * @return Tempo gasto na operação (em segundos)
 */
double testar_busca(EstruturaDados tipo, Acidente *acidentes, int n_acidentes, int n_buscas);

/**
 * Realiza teste de remoção em uma estrutura específica.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes para remoção
 * @param n_acidentes Número de acidentes
 * @param n_remocoes Número de remoções a serem realizadas
 * @return Tempo gasto na operação (em segundos)
 */
double testar_remocao(EstruturaDados tipo, Acidente *acidentes, int n_acidentes, int n_remocoes);

/**
 * Realiza teste de escalabilidade da estrutura.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes para o teste
 * @param n_acidentes Número de acidentes
 * @return Fator de escalabilidade (quanto menor, melhor)
 */
double testar_escalabilidade(EstruturaDados tipo, Acidente *acidentes, int n_acidentes);

/**
 * Mede o uso de memória de uma estrutura.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes a serem inseridos
 * @param n_acidentes Número de acidentes
 * @return Quantidade de memória utilizada (em bytes)
 */
size_t medir_uso_memoria(EstruturaDados tipo, Acidente *acidentes, int n_acidentes);

/**
 * Mede o tempo médio de acesso a elementos aleatórios.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes
 * @param n_acidentes Número de acidentes
 * @param n_acessos Número de acessos a serem realizados
 * @return Tempo médio de acesso (em microssegundos)
 */
double medir_tempo_medio_acesso(EstruturaDados tipo, Acidente *acidentes, int n_acidentes, int n_acessos);

/**
 * Mede a latência média em operações combinadas.
 * 
 * @param tipo Tipo da estrutura
 * @param acidentes Array de acidentes
 * @param n_acidentes Número de acidentes
 * @return Latência média (em microssegundos)
 */
double medir_latencia_media(EstruturaDados tipo, Acidente *acidentes, int n_acidentes);

/**
 * Conta o número de colisões em estruturas baseadas em hash.
 * 
 * @param tipo Tipo da estrutura (deve ser uma tabela hash)
 * @param acidentes Array de acidentes
 * @param n_acidentes Número de acidentes
 * @return Número de colisões ocorridas
 */
int contar_colisoes(EstruturaDados tipo, Acidente *acidentes, int n_acidentes);

#endif /* BENCHMARK_H */
