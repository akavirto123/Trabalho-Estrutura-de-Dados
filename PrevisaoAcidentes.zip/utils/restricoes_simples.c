/**
 * restricoes_simples.c
 * 
 * Versão simplificada das funções de restrição para demonstração.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "restricoes.h"

int aplicar_restricao_memoria(RestricaoMemoria tipo) {
    printf("Aplicando restrição de memória tipo %d\n", tipo);
    printf("Esta é uma simulação de restrição de memória.\n");
    
    switch (tipo) {
        case R1_LIMITE_RAM:
            printf("Simulando limite de RAM (128MB)\n");
            break;
        case R2_FRAGMENTACAO:
            printf("Simulando fragmentação de memória\n");
            break;
        case R3_VAZAMENTO:
            printf("Simulando vazamento de memória\n");
            break;
        case R4_SWAP_LENTO:
            printf("Simulando swap lento\n");
            break;
        case R5_FALHA_ALOCACAO:
            printf("Simulando falhas aleatórias de alocação\n");
            break;
        default:
            printf("Tipo de restrição de memória desconhecido.\n");
            return 0;
    }
    
    return 1;
}

int aplicar_restricao_processamento(RestricaoProcessamento tipo) {
    printf("Aplicando restrição de processamento tipo %d\n", tipo);
    printf("Esta é uma simulação de restrição de processamento.\n");
    
    switch (tipo) {
        case R6_SINGLE_CORE:
            printf("Simulando execução single-core\n");
            break;
        case R7_CPU_LENTA:
            printf("Simulando CPU lenta\n");
            break;
        case R8_INTERRUPCOES:
            printf("Simulando interrupções frequentes\n");
            break;
        case R9_PRIORIDADE_BAIXA:
            printf("Simulando prioridade baixa de processo\n");
            break;
        case R10_CONTENCAO:
            printf("Simulando contenção de recursos\n");
            break;
        default:
            printf("Tipo de restrição de processamento desconhecido.\n");
            return 0;
    }
    
    return 1;
}

int aplicar_restricao_latencia(RestricaoLatencia tipo) {
    printf("Aplicando restrição de latência tipo %d\n", tipo);
    printf("Esta é uma simulação de restrição de latência.\n");
    
    switch (tipo) {
        case R11_REDE_BAIXA:
            printf("Simulando rede de baixa velocidade\n");
            break;
        case R12_LATENCIA_ALTA:
            printf("Simulando alta latência\n");
            break;
        case R13_CONEXAO_INSTAVEL:
            printf("Simulando conexão instável\n");
            break;
        case R14_TIMEOUT:
            printf("Simulando timeouts frequentes\n");
            break;
        case R15_DISCO_LENTO:
            printf("Simulando disco lento\n");
            break;
        default:
            printf("Tipo de restrição de latência desconhecido.\n");
            return 0;
    }
    
    return 1;
}

int aplicar_restricao_dados(RestricaoDados tipo) {
    printf("Aplicando restrição de dados tipo %d\n", tipo);
    printf("Esta é uma simulação de restrição de dados.\n");
    
    switch (tipo) {
        case R16_DADOS_CORROMPIDOS:
            printf("Simulando dados corrompidos\n");
            break;
        case R17_DADOS_INCOMPLETOS:
            printf("Simulando dados incompletos\n");
            break;
        case R18_DADOS_DUPLICADOS:
            printf("Simulando dados duplicados\n");
            break;
        case R19_DADOS_DESATUALIZADOS:
            printf("Simulando dados desatualizados\n");
            break;
        case R20_DADOS_GRANDE_VOLUME:
            printf("Simulando grande volume de dados\n");
            break;
        default:
            printf("Tipo de restrição de dados desconhecido.\n");
            return 0;
    }
    
    return 1;
}

int aplicar_restricao_algoritmica(RestricaoAlgoritmica tipo) {
    printf("Aplicando restrição algorítmica tipo %d\n", tipo);
    printf("Esta é uma simulação de restrição algorítmica.\n");
    
    switch (tipo) {
        case R21_SUBSTITUIR_ESTRUTURA:
            printf("Simulando substituição de estrutura eficiente\n");
            break;
        case R22_ALGORITMO_QUADRATICO:
            printf("Simulando algoritmo de complexidade quadrática\n");
            break;
        case R23_RECURSAO_PROFUNDA:
            printf("Simulando recursão profunda\n");
            break;
        case R24_COLISOES_HASH:
            printf("Simulando colisões em hash\n");
            break;
        case R25_LOCKS_EXCESSIVOS:
            printf("Simulando locks excessivos\n");
            break;
        default:
            printf("Tipo de restrição algorítmica desconhecido.\n");
            return 0;
    }
    
    return 1;
}

int remover_todas_restricoes() {
    printf("Removendo todas as restrições aplicadas...\n");
    printf("Restrições removidas com sucesso.\n");
    return 1;
}

void executar_benchmark_com_restricao(
    EstruturaDados estrutura, 
    int restricao_tipo, 
    int restricao_valor,
    Acidente *acidentes, 
    int n_acidentes
) {
    printf("\n=== Benchmark com Restrição: Tipo %d, Valor %d ===\n", 
           restricao_tipo, restricao_valor);
    
    // Simulando aplicação de restrição
    printf("Aplicando restrição simulada...\n");
    
    // Simulando benchmark
    printf("Executando benchmark sob condições restritas...\n");
    printf("Benchmark concluído com sucesso.\n");
    
    // Simulando remoção de restrição
    printf("Removendo restrição simulada...\n");
}

void obter_descricao_restricao(int tipo_restricao, int valor_restricao, 
                              char *buffer, size_t tamanho) {
    switch (tipo_restricao) {
        case 0:
            snprintf(buffer, tamanho, "Restrição de Memória: Tipo %d", valor_restricao);
            break;
        case 1:
            snprintf(buffer, tamanho, "Restrição de Processamento: Tipo %d", valor_restricao);
            break;
        case 2:
            snprintf(buffer, tamanho, "Restrição de Latência: Tipo %d", valor_restricao);
            break;
        case 3:
            snprintf(buffer, tamanho, "Restrição de Dados: Tipo %d", valor_restricao);
            break;
        case 4:
            snprintf(buffer, tamanho, "Restrição Algorítmica: Tipo %d", valor_restricao);
            break;
        default:
            snprintf(buffer, tamanho, "Restrição Desconhecida: Tipo %d, Valor %d", 
                    tipo_restricao, valor_restricao);
            break;
    }
}