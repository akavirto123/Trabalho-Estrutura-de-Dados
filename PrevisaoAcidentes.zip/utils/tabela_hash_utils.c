/**
 * tabela_hash_utils.c
 * 
 * Funções utilitárias para a tabela hash
 */

#include <stdio.h>
#include <stdlib.h>
#include "../estruturas/tabela_hash.h"

/* 
 * Esta função será implementada diretamente em tabela_hash.c
 * para evitar problemas de múltipla definição
 */