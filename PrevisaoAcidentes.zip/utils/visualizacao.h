/**
 * visualizacao.h
 * 
 * Funções para visualização de dados e gráficos em modo texto.
 */

#ifndef VISUALIZACAO_H
#define VISUALIZACAO_H

#include "../utils/tipos.h"

/**
 * Desenha um gráfico de barras horizontais em ASCII.
 * 
 * @param titulo Título do gráfico
 * @param rotulos Array de rótulos para as barras
 * @param valores Array de valores para as barras
 * @param n_items Número de itens no gráfico
 * @param largura Largura máxima do gráfico em caracteres
 */
void desenhar_grafico_barras(const char *titulo, const char **rotulos, const double *valores, 
                             int n_items, int largura);

/**
 * Desenha um gráfico de linha em ASCII mostrando tendências temporais.
 * 
 * @param titulo Título do gráfico
 * @param rotulos Array de rótulos para os pontos (geralmente períodos de tempo)
 * @param valores Array de valores para os pontos
 * @param n_items Número de itens no gráfico
 * @param altura Altura do gráfico em caracteres
 * @param largura Largura do gráfico em caracteres
 */
void desenhar_grafico_linha(const char *titulo, const char **rotulos, const double *valores, 
                           int n_items, int altura, int largura);

/**
 * Desenha um dashboard completo com múltiplos gráficos.
 * 
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void exibir_dashboard(Acidente *acidentes, int n_acidentes);

/**
 * Desenha um mapa de calor simplificado em ASCII para visualizar clusters geográficos.
 * 
 * @param titulo Título do mapa
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 * @param largura Largura do mapa em caracteres
 * @param altura Altura do mapa em caracteres
 */
void desenhar_mapa_calor(const char *titulo, Acidente *acidentes, int n_acidentes, 
                         int largura, int altura);

/**
 * Desenha um gráfico comparativo de múltiplos cenários.
 * 
 * @param titulo Título do gráfico
 * @param rotulos Array de rótulos para os períodos (meses)
 * @param cenarios Array de nomes dos cenários
 * @param valores Matriz de valores [cenario][periodo]
 * @param n_cenarios Número de cenários
 * @param n_periodos Número de períodos
 * @param largura Largura do gráfico em caracteres
 */
void desenhar_grafico_comparativo(const char *titulo, const char **rotulos, const char **cenarios,
                                 double **valores, int n_cenarios, int n_periodos, int largura);

#endif /* VISUALIZACAO_H */