/**
 * visualizacao.c
 * 
 * Implementação de funções para visualização de dados e gráficos em modo texto.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "visualizacao.h"

// Constantes para caracteres especiais usados nos gráficos
#define CHAR_BARRA '#'
#define CHAR_LINHA_H '-'
#define CHAR_LINHA_V '|'
#define CHAR_CANTO_ES '+'
#define CHAR_CANTO_EI '+'
#define CHAR_CANTO_DS '+'
#define CHAR_CANTO_DI '+'
#define CHAR_CRUZ '+'
#define CHAR_T_CIMA '+'
#define CHAR_T_BAIXO '+'
#define CHAR_T_ESQ '+'
#define CHAR_T_DIR '+'
#define CHAR_PONTO '*'
#define CHAR_ESPACO ' '

// Caracteres para diferentes intensidades no mapa de calor
const char *INTENSIDADE_CHARS[] = {" ", ".", ":", "■", "█"};

void desenhar_grafico_barras(const char *titulo, const char **rotulos, const double *valores, 
                            int n_items, int largura) {
    if (n_items <= 0 || largura < 20) {
        printf("Erro: Parâmetros inválidos para desenhar_grafico_barras\n");
        return;
    }
    
    // Encontrar o valor máximo para dimensionar o gráfico
    double max_valor = 0.0;
    for (int i = 0; i < n_items; i++) {
        if (valores[i] > max_valor) {
            max_valor = valores[i];
        }
    }
    
    // Determinar o comprimento máximo dos rótulos
    int max_rotulo = 0;
    for (int i = 0; i < n_items; i++) {
        int len = strlen(rotulos[i]);
        if (len > max_rotulo) {
            max_rotulo = len;
        }
    }
    
    // Limitar o tamanho do rótulo para não ultrapassar a largura
    max_rotulo = max_rotulo > 20 ? 20 : max_rotulo;
    
    // Calcular a largura disponível para as barras
    int largura_barras = largura - max_rotulo - 15;
    if (largura_barras < 10) {
        largura_barras = 10;
    }
    
    // Desenhar o título do gráfico
    printf("\n%s\n", titulo);
    for (int i = 0; i < strlen(titulo); i++) {
        printf("=");
    }
    printf("\n\n");
    
    // Desenhar cada barra
    for (int i = 0; i < n_items; i++) {
        // Imprimir o rótulo alinhado à direita
        printf("%-*s │ ", max_rotulo, rotulos[i]);
        
        // Calcular o tamanho da barra
        int tamanho_barra = (int)(valores[i] / max_valor * largura_barras);
        
        // Desenhar a barra
        for (int j = 0; j < tamanho_barra; j++) {
            printf("%c", CHAR_BARRA);
        }
        
        // Imprimir o valor ao lado da barra
        printf(" %.2f\n", valores[i]);
    }
    
    // Desenhar linha horizontal inferior
    printf("%-*s └", max_rotulo, "");
    for (int i = 0; i < largura_barras + 2; i++) {
        printf("─");
    }
    printf("\n");
}

void desenhar_grafico_linha(const char *titulo, const char **rotulos, const double *valores, 
                           int n_items, int altura, int largura) {
    if (n_items <= 0 || altura < 5 || largura < 20) {
        printf("Erro: Parâmetros inválidos para desenhar_grafico_linha\n");
        return;
    }
    
    // Encontrar valores mínimo e máximo
    double min_valor = valores[0];
    double max_valor = valores[0];
    for (int i = 1; i < n_items; i++) {
        if (valores[i] < min_valor) min_valor = valores[i];
        if (valores[i] > max_valor) max_valor = valores[i];
    }
    
    // Adicionar margem ao mínimo e máximo
    double margem = (max_valor - min_valor) * 0.1;
    if (margem < 0.1) margem = 0.1;
    min_valor -= margem;
    max_valor += margem;
    
    // Determinar intervalo de valores
    double intervalo = max_valor - min_valor;
    
    // Determinar o comprimento máximo dos rótulos
    int max_rotulo = 0;
    for (int i = 0; i < n_items; i++) {
        int len = strlen(rotulos[i]);
        if (len > max_rotulo) {
            max_rotulo = len;
        }
    }
    
    // Limitar o tamanho do rótulo
    int espaco_rotulo = max_rotulo > 8 ? 8 : max_rotulo;
    
    // Calcular o espaço disponível para os valores à esquerda
    char buffer[20];
    snprintf(buffer, sizeof(buffer), "%.2f", max_valor);
    int espaco_valor = strlen(buffer);
    
    // Desenhar o título do gráfico
    printf("\n%s\n", titulo);
    for (int i = 0; i < strlen(titulo); i++) {
        printf("=");
    }
    printf("\n\n");
    
    // Calcular largura útil para o gráfico
    int largura_grafico = largura - espaco_valor - 5;
    
    // Calcular posições X de cada ponto (dividir o espaço igualmente)
    int posicoes_x[n_items];
    for (int i = 0; i < n_items; i++) {
        posicoes_x[i] = (i * (largura_grafico - 1)) / (n_items - 1);
    }
    
    // Para cada linha do gráfico (de cima para baixo)
    for (int y = 0; y < altura; y++) {
        // Valor correspondente a esta linha
        double valor_linha = max_valor - y * (intervalo / (altura - 1));
        
        // Formatar e imprimir o valor da escala
        if (y == 0 || y == altura - 1 || y == altura / 2) {
            printf("%*.2f │", espaco_valor, valor_linha);
        } else {
            printf("%*s │", espaco_valor, "");
        }
        
        // Para cada posição X
        for (int x = 0; x < largura_grafico; x++) {
            int ponto_impresso = 0;
            
            // Verificar se há um ponto do gráfico nesta posição
            for (int i = 0; i < n_items; i++) {
                if (posicoes_x[i] == x) {
                    // Calcular posição Y do valor
                    double valor_normalizado = (valores[i] - min_valor) / intervalo;
                    int pos_y = altura - 1 - (int)(valor_normalizado * (altura - 1));
                    
                    // Se estamos na linha correspondente ao valor, imprimir o ponto
                    if (y == pos_y) {
                        printf("%c", CHAR_PONTO);
                        ponto_impresso = 1;
                        break;
                    }
                }
                
                // Se estamos entre dois pontos, verificar se precisa desenhar uma linha conectora
                if (i < n_items - 1 && x > posicoes_x[i] && x < posicoes_x[i + 1]) {
                    // Calcular posições Y dos dois pontos
                    double valor_norm1 = (valores[i] - min_valor) / intervalo;
                    double valor_norm2 = (valores[i + 1] - min_valor) / intervalo;
                    int pos_y1 = altura - 1 - (int)(valor_norm1 * (altura - 1));
                    int pos_y2 = altura - 1 - (int)(valor_norm2 * (altura - 1));
                    
                    // Calcular posição Y interpolada para esta posição X
                    double fator = (double)(x - posicoes_x[i]) / (posicoes_x[i + 1] - posicoes_x[i]);
                    int pos_y_interp = (int)((1.0 - fator) * pos_y1 + fator * pos_y2);
                    
                    // Se estamos na linha interpolada, imprimir uma linha conectora
                    if (y == pos_y_interp) {
                        printf("-");
                        ponto_impresso = 1;
                        break;
                    }
                }
            }
            
            // Se não imprimimos nenhum ponto/linha, imprimir espaço
            if (!ponto_impresso) {
                printf(" ");
            }
        }
        printf("\n");
    }
    
    // Desenhar linha horizontal inferior
    printf("%*s └", espaco_valor, "");
    for (int i = 0; i < largura_grafico; i++) {
        printf("─");
    }
    printf("\n");
    
    // Imprimir rótulos
    printf("%*s  ", espaco_valor, "");
    int espaco_entre_rotulos = largura_grafico / n_items;
    for (int i = 0; i < n_items; i++) {
        int pos = i * espaco_entre_rotulos;
        printf("%*s", (i == 0 ? 0 : espaco_entre_rotulos - (int)strlen(rotulos[i])/2), "");
        printf("%.*s", espaco_rotulo, rotulos[i]);
    }
    printf("\n");
}

void desenhar_mapa_calor(const char *titulo, Acidente *acidentes, int n_acidentes, 
                        int largura, int altura) {
    if (n_acidentes <= 0 || largura < 10 || altura < 5) {
        printf("Erro: Parâmetros inválidos para desenhar_mapa_calor\n");
        return;
    }
    
    // Encontrar limites de latitude e longitude
    double min_lat = acidentes[0].local.latitude;
    double max_lat = acidentes[0].local.latitude;
    double min_lon = acidentes[0].local.longitude;
    double max_lon = acidentes[0].local.longitude;
    
    for (int i = 1; i < n_acidentes; i++) {
        double lat = acidentes[i].local.latitude;
        double lon = acidentes[i].local.longitude;
        
        // Ignorar coordenadas inválidas (0,0)
        if (lat == 0.0 && lon == 0.0) continue;
        
        if (lat < min_lat) min_lat = lat;
        if (lat > max_lat) max_lat = lat;
        if (lon < min_lon) min_lon = lon;
        if (lon > max_lon) max_lon = lon;
    }
    
    // Adicionar margem
    double margem_lat = (max_lat - min_lat) * 0.05;
    double margem_lon = (max_lon - min_lon) * 0.05;
    min_lat -= margem_lat;
    max_lat += margem_lat;
    min_lon -= margem_lon;
    max_lon += margem_lon;
    
    // Inicializar matriz de contagem
    int **contagem = (int**)malloc(altura * sizeof(int*));
    for (int i = 0; i < altura; i++) {
        contagem[i] = (int*)calloc(largura, sizeof(int));
    }
    
    // Contar acidentes em cada célula
    for (int i = 0; i < n_acidentes; i++) {
        double lat = acidentes[i].local.latitude;
        double lon = acidentes[i].local.longitude;
        
        // Ignorar coordenadas inválidas
        if (lat == 0.0 && lon == 0.0) continue;
        
        // Converter coordenadas para índices na matriz
        int y = (int)((max_lat - lat) / (max_lat - min_lat) * (altura - 1));
        int x = (int)((lon - min_lon) / (max_lon - min_lon) * (largura - 1));
        
        // Garantir que os índices estão dentro dos limites
        if (x >= 0 && x < largura && y >= 0 && y < altura) {
            contagem[y][x]++;
        }
    }
    
    // Encontrar o valor máximo na matriz
    int max_contagem = 0;
    for (int y = 0; y < altura; y++) {
        for (int x = 0; x < largura; x++) {
            if (contagem[y][x] > max_contagem) {
                max_contagem = contagem[y][x];
            }
        }
    }
    
    // Desenhar o título do mapa
    printf("\n%s\n", titulo);
    for (int i = 0; i < strlen(titulo); i++) {
        printf("=");
    }
    printf("\n\n");
    
    // Desenhar borda superior
    printf(" ");
    for (int x = 0; x < largura + 2; x++) {
        printf("─");
    }
    printf("\n");
    
    // Desenhar mapa de calor
    for (int y = 0; y < altura; y++) {
        printf("│");
        for (int x = 0; x < largura; x++) {
            // Calcular intensidade (0-4) para esta célula
            int intensidade = 0;
            if (max_contagem > 0) {
                intensidade = (int)((contagem[y][x] * 4.0) / max_contagem);
                if (intensidade > 4) intensidade = 4;
            }
            
            // Imprimir caractere correspondente à intensidade
            printf("%s", INTENSIDADE_CHARS[intensidade]);
        }
        printf("│\n");
    }
    
    // Desenhar borda inferior
    printf(" ");
    for (int x = 0; x < largura + 2; x++) {
        printf("─");
    }
    printf("\n");
    
    // Mostrar legenda
    printf("\nLegenda: ");
    for (int i = 0; i < 5; i++) {
        printf("%s ", INTENSIDADE_CHARS[i]);
    }
    printf(" (Menor para Maior densidade)\n");
    
    // Mostrar informações sobre a região
    printf("\nRegião Mapeada: Lat %.2f a %.2f, Lon %.2f a %.2f\n", 
           min_lat, max_lat, min_lon, max_lon);
    printf("Total de Acidentes Mapeados: %d\n", n_acidentes);
    
    // Liberar memória
    for (int i = 0; i < altura; i++) {
        free(contagem[i]);
    }
    free(contagem);
}

void desenhar_grafico_comparativo(const char *titulo, const char **rotulos, const char **cenarios,
                                 double **valores, int n_cenarios, int n_periodos, int largura) {
    if (n_cenarios <= 0 || n_periodos <= 0 || largura < 40) {
        printf("Erro: Parâmetros inválidos para desenhar_grafico_comparativo\n");
        return;
    }
    
    // Encontrar valores mínimo e máximo considerando todos os cenários
    double min_valor = valores[0][0];
    double max_valor = valores[0][0];
    
    for (int i = 0; i < n_cenarios; i++) {
        for (int j = 0; j < n_periodos; j++) {
            if (valores[i][j] < min_valor) min_valor = valores[i][j];
            if (valores[i][j] > max_valor) max_valor = valores[i][j];
        }
    }
    
    // Adicionar margem ao mínimo e máximo
    double margem = (max_valor - min_valor) * 0.1;
    if (margem < 0.1) margem = 0.1;
    min_valor -= margem;
    max_valor += margem;
    
    // Determinar intervalo de valores
    double intervalo = max_valor - min_valor;
    
    // Determinar o comprimento máximo dos rótulos de período
    int max_rotulo = 0;
    for (int i = 0; i < n_periodos; i++) {
        int len = strlen(rotulos[i]);
        if (len > max_rotulo) {
            max_rotulo = len;
        }
    }
    max_rotulo = max_rotulo > 10 ? 10 : max_rotulo;
    
    // Determinar o comprimento máximo dos nomes de cenário
    int max_cenario = 0;
    for (int i = 0; i < n_cenarios; i++) {
        int len = strlen(cenarios[i]);
        if (len > max_cenario) {
            max_cenario = len;
        }
    }
    max_cenario = max_cenario > 20 ? 20 : max_cenario;
    
    // Caracteres para cada cenário
    const char simbolos_cenario[] = {'*', '+', 'o', 'x', '#', '@', '&', '%', '$', '='};
    
    // Desenhar o título do gráfico
    printf("\n%s\n", titulo);
    for (int i = 0; i < strlen(titulo); i++) {
        printf("=");
    }
    printf("\n\n");
    
    // Desenhar legenda dos cenários
    printf("Legenda:\n");
    for (int i = 0; i < n_cenarios; i++) {
        printf("  %c - %s\n", simbolos_cenario[i % 10], cenarios[i]);
    }
    printf("\n");
    
    // Calcular altura do gráfico
    int altura = 20;  // Altura fixa para o gráfico
    
    // Calcular largura útil para o gráfico
    int largura_grafico = largura - max_rotulo - 10;
    
    // Calcular largura de cada coluna (período)
    int largura_coluna = largura_grafico / n_periodos;
    
    // Para cada linha do gráfico (de cima para baixo)
    for (int y = 0; y < altura; y++) {
        // Valor correspondente a esta linha
        double valor_linha = max_valor - y * (intervalo / (altura - 1));
        
        // Formatar e imprimir o valor da escala
        if (y == 0 || y == altura - 1 || y == altura / 2) {
            printf("%8.2f │", valor_linha);
        } else {
            printf("        │");
        }
        
        // Para cada período
        for (int p = 0; p < n_periodos; p++) {
            // Calcular posição inicial para este período
            int pos_x = p * largura_coluna;
            
            // Imprimir espaço para esta coluna
            for (int x = 0; x < largura_coluna; x++) {
                char c = ' ';
                
                // Verificar se algum cenário tem um ponto nesta posição
                for (int c_idx = 0; c_idx < n_cenarios; c_idx++) {
                    double valor = valores[c_idx][p];
                    double valor_norm = (valor - min_valor) / intervalo;
                    int pos_y = altura - 1 - (int)(valor_norm * (altura - 1));
                    
                    // Se o valor deste cenário cai nesta linha
                    if (y == pos_y && x == largura_coluna / 2) {
                        c = simbolos_cenario[c_idx % 10];
                        break;
                    }
                }
                
                printf("%c", c);
            }
        }
        printf("\n");
    }
    
    // Desenhar linha horizontal inferior
    printf("        └");
    for (int i = 0; i < largura_grafico; i++) {
        printf("─");
    }
    printf("\n");
    
    // Imprimir rótulos de período
    printf("         ");
    for (int p = 0; p < n_periodos; p++) {
        // Calcular posição central para este período
        int pos = p * largura_coluna + largura_coluna / 2 - strlen(rotulos[p]) / 2;
        
        // Ajustar para não ultrapassar largura
        if (pos + strlen(rotulos[p]) > largura_grafico) {
            pos = largura_grafico - strlen(rotulos[p]);
        }
        
        // Imprimir espaços até a posição
        for (int i = (p == 0 ? 0 : p * largura_coluna); i < pos; i++) {
            printf(" ");
        }
        
        // Imprimir rótulo
        printf("%s", rotulos[p]);
    }
    printf("\n");
}

void exibir_dashboard(Acidente *acidentes, int n_acidentes) {
    if (n_acidentes <= 0) {
        printf("Erro: Sem dados para exibir no dashboard\n");
        return;
    }
    
    printf("\n======================================================\n");
    printf("                 DASHBOARD DE ACIDENTES                 ");
    printf("\n======================================================\n");
    
    // Calcular estatísticas por UF
    typedef struct {
        char uf[3];
        int count;
        int feridos;
        int mortos;
    } EstUF;
    
    EstUF ufs[27];  // Brasil tem 27 UFs
    int n_ufs = 0;
    
    for (int i = 0; i < n_acidentes; i++) {
        // Procurar a UF no array
        int idx = -1;
        for (int j = 0; j < n_ufs; j++) {
            if (strcmp(ufs[j].uf, acidentes[i].local.uf) == 0) {
                idx = j;
                break;
            }
        }
        
        // Se não encontrou, adicionar nova UF
        if (idx == -1) {
            idx = n_ufs++;
            strcpy(ufs[idx].uf, acidentes[i].local.uf);
            ufs[idx].count = 0;
            ufs[idx].feridos = 0;
            ufs[idx].mortos = 0;
        }
        
        // Incrementar contadores
        ufs[idx].count++;
        ufs[idx].feridos += acidentes[i].condicoes.feridos;
        ufs[idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Ordenar UFs por número de acidentes (decrescente)
    for (int i = 0; i < n_ufs - 1; i++) {
        for (int j = i + 1; j < n_ufs; j++) {
            if (ufs[j].count > ufs[i].count) {
                EstUF temp = ufs[i];
                ufs[i] = ufs[j];
                ufs[j] = temp;
            }
        }
    }
    
    // Limitar para as 10 UFs com mais acidentes
    int top_ufs = n_ufs > 10 ? 10 : n_ufs;
    
    // Preparar dados para o gráfico de barras de acidentes por UF
    const char *rotulos_uf[top_ufs];
    double valores_uf[top_ufs];
    
    for (int i = 0; i < top_ufs; i++) {
        rotulos_uf[i] = ufs[i].uf;
        valores_uf[i] = (double)ufs[i].count;
    }
    
    // Desenhar gráfico de barras de acidentes por UF
    desenhar_grafico_barras("Acidentes por UF (Top 10)", rotulos_uf, valores_uf, top_ufs, 80);
    
    // Calcular estatísticas por mês
    typedef struct {
        int mes;
        int count;
        int feridos;
        int mortos;
    } EstMes;
    
    EstMes meses[12];
    
    // Inicializar array de meses
    for (int i = 0; i < 12; i++) {
        meses[i].mes = i + 1;
        meses[i].count = 0;
        meses[i].feridos = 0;
        meses[i].mortos = 0;
    }
    
    // Contar acidentes por mês
    for (int i = 0; i < n_acidentes; i++) {
        int mes = acidentes[i].data.mes;
        if (mes >= 1 && mes <= 12) {
            meses[mes - 1].count++;
            meses[mes - 1].feridos += acidentes[i].condicoes.feridos;
            meses[mes - 1].mortos += acidentes[i].condicoes.mortos;
        }
    }
    
    // Preparar dados para o gráfico de linha por mês
    const char *nomes_meses[] = {
        "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
        "Jul", "Ago", "Set", "Out", "Nov", "Dez"
    };
    
    const char *rotulos_mes[12];
    double valores_mes[12];
    
    for (int i = 0; i < 12; i++) {
        rotulos_mes[i] = nomes_meses[i];
        valores_mes[i] = (double)meses[i].count;
    }
    
    // Desenhar gráfico de linha de acidentes por mês
    desenhar_grafico_linha("Tendência de Acidentes por Mês", rotulos_mes, valores_mes, 12, 15, 80);
    
    // Desenhar mapa de calor dos acidentes
    desenhar_mapa_calor("Mapa de Calor de Acidentes", acidentes, n_acidentes, 60, 20);
    
    // Comparação entre acidentes, feridos e mortos por mês
    printf("\nComparação de Estatísticas por Mês:\n");
    printf("%-5s | %-10s | %-10s | %-10s | %-15s\n",
           "Mês", "Acidentes", "Feridos", "Mortos", "Índice Gravidade");
    printf("------+------------+------------+------------+----------------\n");
    
    for (int i = 0; i < 12; i++) {
        double indice_gravidade = 0.0;
        if (meses[i].count > 0) {
            indice_gravidade = (meses[i].feridos + 5.0 * meses[i].mortos) / meses[i].count;
        }
        
        printf("%-5s | %-10d | %-10d | %-10d | %-15.2f\n",
               nomes_meses[i], meses[i].count, meses[i].feridos, meses[i].mortos, indice_gravidade);
    }
    
    // Estatísticas gerais
    printf("\nEstatísticas Gerais:\n");
    printf("Total de Acidentes: %d\n", n_acidentes);
    
    int total_feridos = 0, total_mortos = 0;
    for (int i = 0; i < n_acidentes; i++) {
        total_feridos += acidentes[i].condicoes.feridos;
        total_mortos += acidentes[i].condicoes.mortos;
    }
    
    printf("Total de Feridos: %d (%.2f por acidente)\n", 
           total_feridos, (double)total_feridos / n_acidentes);
    printf("Total de Mortos: %d (%.2f por acidente)\n", 
           total_mortos, (double)total_mortos / n_acidentes);
    
    double indice_geral = (total_feridos + 5.0 * total_mortos) / n_acidentes;
    printf("Índice de Gravidade Geral: %.2f\n", indice_geral);
}