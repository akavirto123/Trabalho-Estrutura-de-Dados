/**
 * csv_parser.h
 * 
 * Funções para análise e carregamento de arquivos CSV contendo
 * dados de acidentes de trânsito.
 */

#ifndef CSV_PARSER_H
#define CSV_PARSER_H

#include "tipos.h"

/**
 * Carrega dados de acidentes a partir de um arquivo CSV.
 * 
 * @param caminho_arquivo Caminho para o arquivo CSV
 * @param n_acidentes Ponteiro para armazenar o número de acidentes carregados
 * @param max_acidentes Número máximo de acidentes a serem carregados
 * @return Vetor de acidentes carregados
 */
Acidente* carregar_csv(const char *caminho_arquivo, int *n_acidentes, int max_acidentes);

/**
 * Parseia uma string de data no formato "DD/MM/AAAA" para a estrutura Data.
 * 
 * @param data_str String contendo a data
 * @return Estrutura Data preenchida
 */
Data parsear_data(const char *data_str);

/**
 * Parseia uma string de hora no formato "HH:MM" para a estrutura Horario.
 * 
 * @param hora_str String contendo o horário
 * @return Estrutura Horario preenchida
 */
Horario parsear_horario(const char *hora_str);

/**
 * Verifica se uma string contém apenas caracteres numéricos.
 * 
 * @param str String a ser verificada
 * @return 1 se contém apenas números, 0 caso contrário
 */
int eh_numero(const char *str);

/**
 * Converte uma string para um número inteiro de forma segura.
 * 
 * @param str String a ser convertida
 * @param padrao Valor padrão caso a conversão falhe
 * @return Número inteiro ou valor padrão
 */
int str_para_int(const char *str, int padrao);

/**
 * Converte uma string para um número double de forma segura.
 * 
 * @param str String a ser convertida
 * @param padrao Valor padrão caso a conversão falhe
 * @return Número double ou valor padrão
 */
double str_para_double(const char *str, double padrao);

#endif /* CSV_PARSER_H */
