/**
 * tipos.h
 * 
 * Definição de tipos e estruturas comuns utilizadas em todo o sistema.
 */

#ifndef TIPOS_H
#define TIPOS_H

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

// Enumeração para identificar as estruturas de dados
typedef enum {
    LISTA_ENCADEADA = 0,
    ARVORE_AVL = 1,
    TABELA_HASH = 2,
    SKIPLIST = 3,
    TRIE = 4,
    TODAS = 5  // Usado para operações em todas as estruturas
} EstruturaDados;

// Enumeração para as restrições de memória
typedef enum {
    R1_LIMITE_RAM = 0,
    R2_FRAGMENTACAO = 1,
    R3_VAZAMENTO = 2,
    R4_SWAP_LENTO = 3,
    R5_FALHA_ALOCACAO = 4
} RestricaoMemoria;

// Enumeração para as restrições de processamento
typedef enum {
    R6_SINGLE_CORE = 0,
    R7_CPU_LENTA = 1,
    R8_INTERRUPCOES = 2,
    R9_PRIORIDADE_BAIXA = 3,
    R10_CONTENCAO = 4
} RestricaoProcessamento;

// Enumeração para as restrições de latência
typedef enum {
    R11_REDE_BAIXA = 0,
    R12_LATENCIA_ALTA = 1,
    R13_CONEXAO_INSTAVEL = 2,
    R14_TIMEOUT = 3,
    R15_DISCO_LENTO = 4
} RestricaoLatencia;

// Enumeração para as restrições de dados
typedef enum {
    R16_DADOS_CORROMPIDOS = 0,
    R17_DADOS_INCOMPLETOS = 1,
    R18_DADOS_DUPLICADOS = 2,
    R19_DADOS_DESATUALIZADOS = 3,
    R20_DADOS_GRANDE_VOLUME = 4
} RestricaoDados;

// Enumeração para as restrições algorítmicas
typedef enum {
    R21_SUBSTITUIR_ESTRUTURA = 0,
    R22_ALGORITMO_QUADRATICO = 1,
    R23_RECURSAO_PROFUNDA = 2,
    R24_COLISOES_HASH = 3,
    R25_LOCKS_EXCESSIVOS = 4
} RestricaoAlgoritmica;

// Estrutura para representar data
typedef struct {
    int dia;
    int mes;
    int ano;
} Data;

// Estrutura para representar horário
typedef struct {
    int hora;
    int minuto;
} Horario;

// Estrutura para representar localização
typedef struct {
    double latitude;
    double longitude;
    char uf[3];              // Sigla do estado (UF)
    char municipio[100];     // Nome do município
    char br[10];             // Identificação da rodovia (BR-XXX)
    double km;               // Quilômetro da rodovia
} Localizacao;

// Estrutura para representar condições do acidente
typedef struct {
    char classificacao[50];  // Tipo de acidente (colisão, atropelamento, etc.)
    char causa[100];         // Causa provável do acidente
    char tipo_pista[50];     // Tipo de pista (simples, dupla, etc.)
    char condicao_meteo[50]; // Condição meteorológica (chuva, sol, etc.)
    char fase_dia[20];       // Fase do dia (dia, noite, amanhecer, etc.)
    int pessoas_envolvidas;  // Número total de pessoas envolvidas
    int feridos;             // Número de feridos
    int mortos;              // Número de mortos
    int veiculos;            // Número de veículos envolvidos
} CondicoesAcidente;

// Estrutura principal para armazenar dados de um acidente
typedef struct {
    char id[20];            // Identificador único do acidente (como string)
    Data data;               // Data do acidente
    Horario horario;         // Horário do acidente
    Localizacao local;       // Localização do acidente
    CondicoesAcidente condicoes; // Condições do acidente
} Acidente;

// Estrutura para armazenar resultados de benchmark
typedef struct {
    EstruturaDados tipo;
    double tempo_insercao;
    double tempo_busca;
    double tempo_remocao;
    size_t memoria_utilizada;
    int num_colisoes;     // Relevante para tabelas hash
    double tempo_medio_acesso;
    double fator_escalabilidade;
    double latencia_media;
} ResultadoBenchmark;

// Função auxiliar para imprimir os dados de um acidente
void imprimir_acidente(const Acidente *acidente);

#endif /* TIPOS_H */
