/**
 * tabela_hash.h
 * 
 * Definição da estrutura de dados Tabela Hash para o sistema de análise de acidentes.
 */

#ifndef TABELA_HASH_H
#define TABELA_HASH_H

#include "../utils/tipos.h"

/**
 * Cria uma nova tabela hash.
 * 
 * @return Ponteiro para a tabela hash criada, ou NULL em caso de erro.
 */
void* hash_criar();

/**
 * Insere um acidente na tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @param acidente Acidente a ser inserido
 * @return 1 se a inserção foi bem-sucedida, 0 caso contrário
 */
int hash_inserir(void *tabela, Acidente *acidente);

/**
 * Busca um acidente na tabela hash pelo ID.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @param id ID do acidente a ser buscado
 * @return Ponteiro para o acidente encontrado, ou NULL se não for encontrado
 */
Acidente* hash_buscar(void *tabela, const char* id);

/**
 * Remove um acidente da tabela hash pelo ID.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @param id ID do acidente a ser removido
 * @return 1 se a remoção foi bem-sucedida, 0 caso contrário
 */
int hash_remover(void *tabela, const char* id);

/**
 * Destroi a tabela hash, liberando a memória alocada.
 * 
 * @param tabela Ponteiro para a tabela hash a ser destruída
 */
void hash_destruir(void *tabela);

/**
 * Retorna o número de elementos na tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @return Número de elementos na tabela
 */
int hash_tamanho(void *tabela);

/**
 * Itera sobre todos os elementos da tabela hash, aplicando a função fornecida.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @param func Função a ser aplicada em cada elemento
 * @param contexto Contexto adicional para a função
 */
void hash_iterar(void *tabela, void (*func)(Acidente*, void*), void *contexto);

/**
 * Filtra elementos da tabela hash com base em um critério.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @param criterio Função que define o critério de filtragem
 * @param contexto Contexto adicional para a função
 * @return Nova tabela hash com os elementos filtrados
 */
void* hash_filtrar(void *tabela, int (*criterio)(Acidente*, void*), void *contexto);

/**
 * Obtém estatísticas da tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @param tamanho Ponteiro para armazenar o tamanho da tabela
 * @param elementos Ponteiro para armazenar o número de elementos
 * @param colisoes Ponteiro para armazenar o número de colisões
 * @param maior_lista Ponteiro para armazenar o tamanho da maior lista de colisão
 */
void hash_estatisticas(void *tabela, int *tamanho, int *elementos, int *colisoes, int *maior_lista);

/**
 * Obtém o número de colisões na tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash
 * @return Número de colisões na tabela
 */
int hash_obter_colisoes(void *tabela);

#endif /* TABELA_HASH_H */