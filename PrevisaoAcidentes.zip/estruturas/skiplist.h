/**
 * skiplist.h
 * 
 * Implementação de Skip List para armazenamento e manipulação
 * de dados de acidentes de trânsito com busca eficiente.
 */

#ifndef SKIPLIST_H
#define SKIPLIST_H

#include "../utils/tipos.h"

/**
 * Cria uma nova skip list vazia.
 * 
 * @return Ponteiro para a nova skip list ou NULL em caso de falha
 */
void* skiplist_criar();

/**
 * Insere um acidente na skip list.
 * 
 * @param lista Ponteiro para a skip list
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int skiplist_inserir(void *lista, Acidente *acidente);

/**
 * Busca um acidente pelo ID na skip list.
 * 
 * @param lista Ponteiro para a skip list
 * @param id ID do acidente a ser buscado
 * @return Ponteiro para o acidente encontrado ou NULL se não existir
 */
Acidente* skiplist_buscar(void *lista, const char* id);

/**
 * Remove um acidente da skip list pelo ID.
 * 
 * @param lista Ponteiro para a skip list
 * @param id ID do acidente a ser removido
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int skiplist_remover(void *lista, const char* id);

/**
 * Destrói a skip list e libera toda a memória alocada.
 * 
 * @param lista Ponteiro para a skip list a ser destruída
 */
void skiplist_destruir(void *lista);

/**
 * Retorna o número de elementos na skip list.
 * 
 * @param lista Ponteiro para a skip list
 * @return Número de elementos
 */
int skiplist_tamanho(void *lista);

/**
 * Retorna a altura atual da skip list.
 * 
 * @param lista Ponteiro para a skip list
 * @return Altura da skip list
 */
int skiplist_altura(void *lista);

/**
 * Exibe uma representação visual da skip list (para debug).
 * 
 * @param lista Ponteiro para a skip list
 */
void skiplist_mostrar(void *lista);

/**
 * Itera sobre todos os elementos da skip list em ordem e aplica uma função a cada um.
 * 
 * @param lista Ponteiro para a skip list
 * @param func Função a ser aplicada a cada elemento
 * @param contexto Contexto adicional a ser passado para a função
 */
void skiplist_iterar(void *lista, void (*func)(Acidente*, void*), void *contexto);

/**
 * Obtém uma lista dos acidentes na skip list dentro de um intervalo de IDs.
 * 
 * @param lista Ponteiro para a skip list
 * @param id_min ID mínimo (inclusive)
 * @param id_max ID máximo (inclusive)
 * @param resultado Vetor para armazenar os ponteiros para os acidentes encontrados
 * @param max_tam Tamanho máximo do vetor de resultado
 * @return Número de acidentes encontrados
 */
int skiplist_buscar_intervalo(void *lista, int id_min, int id_max, 
                            Acidente **resultado, int max_tam);

/**
 * Versão otimizada da skip list com armazenamento contíguo.
 * 
 * @return Ponteiro para a nova skip list otimizada ou NULL em caso de falha
 */
void* skiplist_criar_otimizada();

/**
 * Insere um acidente na skip list otimizada.
 * 
 * @param lista Ponteiro para a skip list otimizada
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int skiplist_inserir_otimizada(void *lista, Acidente *acidente);

/**
 * Busca um acidente pelo ID na skip list otimizada.
 * 
 * @param lista Ponteiro para a skip list otimizada
 * @param id ID do acidente a ser buscado
 * @return Ponteiro para o acidente encontrado ou NULL se não existir
 */
Acidente* skiplist_buscar_otimizada(void *lista, int id);

/**
 * Remove um acidente da skip list otimizada pelo ID.
 * 
 * @param lista Ponteiro para a skip list otimizada
 * @param id ID do acidente a ser removido
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int skiplist_remover_otimizada(void *lista, int id);

/**
 * Destrói a skip list otimizada e libera toda a memória alocada.
 * 
 * @param lista Ponteiro para a skip list otimizada a ser destruída
 */
void skiplist_destruir_otimizada(void *lista);

#endif /* SKIPLIST_H */
