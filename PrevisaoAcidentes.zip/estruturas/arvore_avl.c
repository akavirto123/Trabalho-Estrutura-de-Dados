/**
 * arvore_avl.c
 * 
 * Implementação de Árvore AVL para armazenamento e manipulação
 * de dados de acidentes de trânsito com balanceamento automático.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arvore_avl.h"
#include "../utils/memoria.h"

// Definição de macro para obter o máximo entre dois valores
#define MAX(a, b) ((a) > (b) ? (a) : (b))

// Estrutura de um nó da árvore AVL
typedef struct NoAVL {
    Acidente acidente;
    struct NoAVL *esquerda;
    struct NoAVL *direita;
    int altura;  // Altura do nó (para balanceamento)
} NoAVL;

// Estrutura da árvore AVL
typedef struct {
    NoAVL *raiz;
    int tamanho;
} ArvoreAVL;

// Estrutura de um nó comprimido da árvore AVL otimizada
typedef struct {
    Acidente acidente;
    unsigned int esquerda : 24;  // Índice do filho esquerdo (24 bits = até 16 milhões de nós)
    unsigned int direita : 24;   // Índice do filho direito
    signed int balanco : 8;      // Fator de balanceamento (-127 a 127)
} NoAVLComprimido;

// Estrutura da árvore AVL otimizada
typedef struct {
    NoAVLComprimido *nos;  // Array de nós
    int capacidade;        // Capacidade total do array
    int tamanho;           // Número de nós atualmente na árvore
    int raiz;              // Índice do nó raiz
    int *livres;           // Pilha de índices livres
    int n_livres;          // Número de índices livres
} ArvoreAVLOtimizada;

// Funções Auxiliares para a Árvore AVL padrão

// Obtém a altura de um nó (0 se for NULL)
static int altura_no(NoAVL *no) {
    if (!no) return 0;
    return no->altura;
}

// Calcula o fator de balanceamento de um nó
static int fator_balanceamento(NoAVL *no) {
    if (!no) return 0;
    return altura_no(no->esquerda) - altura_no(no->direita);
}

// Atualiza a altura de um nó com base nas alturas dos filhos
static void atualizar_altura(NoAVL *no) {
    if (!no) return;
    no->altura = 1 + MAX(altura_no(no->esquerda), altura_no(no->direita));
}

// Rotação simples à direita
static NoAVL* rotacao_direita(NoAVL *y) {
    NoAVL *x = y->esquerda;
    NoAVL *T2 = x->direita;
    
    // Realiza a rotação
    x->direita = y;
    y->esquerda = T2;
    
    // Atualiza alturas
    atualizar_altura(y);
    atualizar_altura(x);
    
    // Retorna nova raiz
    return x;
}

// Rotação simples à esquerda
static NoAVL* rotacao_esquerda(NoAVL *x) {
    NoAVL *y = x->direita;
    NoAVL *T2 = y->esquerda;
    
    // Realiza a rotação
    y->esquerda = x;
    x->direita = T2;
    
    // Atualiza alturas
    atualizar_altura(x);
    atualizar_altura(y);
    
    // Retorna nova raiz
    return y;
}

// Balanceia um nó e retorna a nova raiz da subárvore
static NoAVL* balancear(NoAVL *no) {
    if (!no) return NULL;
    
    // Atualiza a altura do nó atual
    atualizar_altura(no);
    
    // Obtém o fator de balanceamento
    int fb = fator_balanceamento(no);
    
    // Casos de desbalanceamento:
    
    // Caso Esquerda-Esquerda
    if (fb > 1 && fator_balanceamento(no->esquerda) >= 0)
        return rotacao_direita(no);
    
    // Caso Direita-Direita
    if (fb < -1 && fator_balanceamento(no->direita) <= 0)
        return rotacao_esquerda(no);
    
    // Caso Esquerda-Direita
    if (fb > 1 && fator_balanceamento(no->esquerda) < 0) {
        no->esquerda = rotacao_esquerda(no->esquerda);
        return rotacao_direita(no);
    }
    
    // Caso Direita-Esquerda
    if (fb < -1 && fator_balanceamento(no->direita) > 0) {
        no->direita = rotacao_direita(no->direita);
        return rotacao_esquerda(no);
    }
    
    // Nó já está balanceado
    return no;
}

// Encontra o nó com o valor mínimo em uma subárvore
static NoAVL* encontrar_minimo(NoAVL *no) {
    NoAVL *atual = no;
    
    // Navega para o filho mais à esquerda
    while (atual && atual->esquerda)
        atual = atual->esquerda;
    
    return atual;
}

// Insere um nó recursivamente e mantém a árvore balanceada
static NoAVL* inserir_no(NoAVL *no, Acidente *acidente, int *sucesso) {
    // 1. Realiza inserção BST normal
    if (!no) {
        NoAVL *novo = (NoAVL*)malloc(sizeof(NoAVL));
        if (!novo) {
            *sucesso = 0;
            return NULL;
        }
        
        memcpy(&novo->acidente, acidente, sizeof(Acidente));
        novo->esquerda = NULL;
        novo->direita = NULL;
        novo->altura = 1;  // Novo nó é uma folha
        
        *sucesso = 1;
        return novo;
    }
    
    // Decide em qual subárvore inserir com base no ID
    if (acidente->id < no->acidente.id)
        no->esquerda = inserir_no(no->esquerda, acidente, sucesso);
    else if (acidente->id > no->acidente.id)
        no->direita = inserir_no(no->direita, acidente, sucesso);
    else {
        // ID já existe, substitui os dados
        memcpy(&no->acidente, acidente, sizeof(Acidente));
        *sucesso = 1;
        return no;
    }
    
    // 2. Atualiza a altura do nó ancestral
    atualizar_altura(no);
    
    // 3. Balanceia a árvore
    return balancear(no);
}

// Remove um nó recursivamente e mantém a árvore balanceada
static NoAVL* remover_no(NoAVL *no, int id, int *sucesso) {
    // 1. Realiza remoção BST normal
    if (!no) {
        *sucesso = 0;
        return NULL;
    }
    
    // Busca o nó a ser removido
    if (id < no->acidente.id)
        no->esquerda = remover_no(no->esquerda, id, sucesso);
    else if (id > no->acidente.id)
        no->direita = remover_no(no->direita, id, sucesso);
    else {
        // Encontrou o nó a ser removido
        
        // Nó com nenhum ou apenas um filho
        if (!no->esquerda || !no->direita) {
            NoAVL *temp = no->esquerda ? no->esquerda : no->direita;
            
            // Nenhum filho
            if (!temp) {
                temp = no;
                no = NULL;
            } else {
                // Um filho
                *no = *temp;  // Copia o conteúdo do filho
            }
            
            free(temp);
            *sucesso = 1;
        } else {
            // Nó com dois filhos
            
            // Encontra o sucessor in-order (menor nó na subárvore direita)
            NoAVL *temp = encontrar_minimo(no->direita);
            
            // Copia os dados do sucessor para este nó
            memcpy(&no->acidente, &temp->acidente, sizeof(Acidente));
            
            // Remove o sucessor
            no->direita = remover_no(no->direita, temp->acidente.id, sucesso);
        }
    }
    
    // Se a árvore tinha apenas um nó, retorna
    if (!no)
        return NULL;
    
    // 2. Atualiza a altura do nó atual
    atualizar_altura(no);
    
    // 3. Balanceia a árvore
    return balancear(no);
}

// Busca um nó recursivamente
static NoAVL* buscar_no(NoAVL *no, int id) {
    if (!no)
        return NULL;
    
    if (id == no->acidente.id)
        return no;
    
    if (id < no->acidente.id)
        return buscar_no(no->esquerda, id);
    else
        return buscar_no(no->direita, id);
}

// Função auxiliar para iterar sobre a árvore em ordem
static void iterar_em_ordem_recursivo(NoAVL *no, void (*func)(Acidente*, void*), void *contexto) {
    if (!no)
        return;
    
    // Visita subárvore esquerda
    iterar_em_ordem_recursivo(no->esquerda, func, contexto);
    
    // Processa o nó atual
    func(&no->acidente, contexto);
    
    // Visita subárvore direita
    iterar_em_ordem_recursivo(no->direita, func, contexto);
}

// Função auxiliar para destruir recursivamente todos os nós
static void destruir_recursivo(NoAVL *no) {
    if (!no)
        return;
    
    // Destrói subárvores
    destruir_recursivo(no->esquerda);
    destruir_recursivo(no->direita);
    
    // Libera o nó atual
    free(no);
}

// Função auxiliar recursiva para buscar acidentes em um intervalo de IDs
static int buscar_intervalo_recursivo(NoAVL *no, int id_min, int id_max, 
                                    Acidente **resultado, int max_tam, int pos) {
    if (!no || pos >= max_tam)
        return pos;
    
    // Se o nó atual está dentro do intervalo, processa a subárvore esquerda
    if (id_min < no->acidente.id)
        pos = buscar_intervalo_recursivo(no->esquerda, id_min, id_max, resultado, max_tam, pos);
    
    // Verifica se o ID do nó atual está no intervalo
    if (no->acidente.id >= id_min && no->acidente.id <= id_max && pos < max_tam)
        resultado[pos++] = &no->acidente;
    
    // Se o nó atual está dentro do intervalo, processa a subárvore direita
    if (id_max > no->acidente.id)
        pos = buscar_intervalo_recursivo(no->direita, id_min, id_max, resultado, max_tam, pos);
    
    return pos;
}

// Função auxiliar para comparar datas
static int comparar_datas(Data a, Data b) {
    if (a.ano != b.ano)
        return a.ano - b.ano;
    if (a.mes != b.mes)
        return a.mes - b.mes;
    return a.dia - b.dia;
}

// Função auxiliar recursiva para buscar acidentes em um intervalo de datas
static int buscar_por_data_recursivo(NoAVL *no, Data data_min, Data data_max, 
                                    Acidente **resultado, int max_tam, int pos) {
    if (!no || pos >= max_tam)
        return pos;
    
    // Como a árvore está organizada por ID, precisamos percorrer toda a árvore
    // Primeiro, processa a subárvore esquerda
    pos = buscar_por_data_recursivo(no->esquerda, data_min, data_max, resultado, max_tam, pos);
    
    // Verifica se a data do nó atual está no intervalo
    if (comparar_datas(no->acidente.data, data_min) >= 0 && 
        comparar_datas(no->acidente.data, data_max) <= 0 && pos < max_tam) {
        resultado[pos++] = &no->acidente;
    }
    
    // Processa a subárvore direita
    pos = buscar_por_data_recursivo(no->direita, data_min, data_max, resultado, max_tam, pos);
    
    return pos;
}

// Implementação das funções públicas da árvore AVL

void* avl_criar() {
    ArvoreAVL *arvore = (ArvoreAVL*)malloc(sizeof(ArvoreAVL));
    if (!arvore)
        return NULL;
    
    arvore->raiz = NULL;
    arvore->tamanho = 0;
    
    return arvore;
}

int avl_inserir(void *_arvore, Acidente *acidente) {
    if (!_arvore || !acidente)
        return 0;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    int sucesso = 0;
    
    arvore->raiz = inserir_no(arvore->raiz, acidente, &sucesso);
    
    if (sucesso)
        arvore->tamanho++;
    
    return sucesso;
}

Acidente* avl_buscar(void *_arvore, int id) {
    if (!_arvore)
        return NULL;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    NoAVL *no = buscar_no(arvore->raiz, id);
    
    return no ? &no->acidente : NULL;
}

int avl_remover(void *_arvore, int id) {
    if (!_arvore)
        return 0;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    int sucesso = 0;
    
    arvore->raiz = remover_no(arvore->raiz, id, &sucesso);
    
    if (sucesso)
        arvore->tamanho--;
    
    return sucesso;
}

void avl_destruir(void *_arvore) {
    if (!_arvore)
        return;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    
    // Destrói todos os nós recursivamente
    destruir_recursivo(arvore->raiz);
    
    // Libera a estrutura da árvore
    free(arvore);
}

int avl_tamanho(void *_arvore) {
    if (!_arvore)
        return 0;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    return arvore->tamanho;
}

int avl_altura(void *_arvore) {
    if (!_arvore)
        return 0;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    return altura_no(arvore->raiz);
}

void avl_iterar_em_ordem(void *_arvore, void (*func)(Acidente*, void*), void *contexto) {
    if (!_arvore || !func)
        return;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    iterar_em_ordem_recursivo(arvore->raiz, func, contexto);
}

int avl_buscar_intervalo(void *_arvore, int id_min, int id_max, Acidente **resultado, int max_tam) {
    if (!_arvore || !resultado || max_tam <= 0)
        return 0;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    return buscar_intervalo_recursivo(arvore->raiz, id_min, id_max, resultado, max_tam, 0);
}

int avl_buscar_por_data(void *_arvore, Data data_min, Data data_max, Acidente **resultado, int max_tam) {
    if (!_arvore || !resultado || max_tam <= 0)
        return 0;
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    return buscar_por_data_recursivo(arvore->raiz, data_min, data_max, resultado, max_tam, 0);
}

int avl_esta_balanceada(void *_arvore) {
    if (!_arvore)
        return 1;  // Árvore vazia é considerada balanceada
    
    ArvoreAVL *arvore = (ArvoreAVL*)_arvore;
    
    // Função interna para verificar o balanceamento recursivamente
    int verificar_balanceamento(NoAVL *no) {
        if (!no)
            return 1;
        
        int fb = fator_balanceamento(no);
        
        // Se o fator de balanceamento está fora do intervalo [-1,1]
        if (fb < -1 || fb > 1)
            return 0;
        
        // Verifica recursivamente as subárvores
        return verificar_balanceamento(no->esquerda) && verificar_balanceamento(no->direita);
    }
    
    return verificar_balanceamento(arvore->raiz);
}

// Funções para a árvore AVL otimizada com compressão de nós

void* avl_criar_otimizada() {
    // Aloca a estrutura da árvore otimizada
    ArvoreAVLOtimizada *arvore = (ArvoreAVLOtimizada*)malloc(sizeof(ArvoreAVLOtimizada));
    if (!arvore)
        return NULL;
    
    // Capacidade inicial (pode ser ajustada conforme necessário)
    int capacidade_inicial = 1024;
    
    // Aloca o array de nós
    arvore->nos = (NoAVLComprimido*)malloc(capacidade_inicial * sizeof(NoAVLComprimido));
    if (!arvore->nos) {
        free(arvore);
        return NULL;
    }
    
    // Aloca a pilha de índices livres
    arvore->livres = (int*)malloc(capacidade_inicial * sizeof(int));
    if (!arvore->livres) {
        free(arvore->nos);
        free(arvore);
        return NULL;
    }
    
    // Inicializa a árvore
    arvore->capacidade = capacidade_inicial;
    arvore->tamanho = 0;
    arvore->raiz = -1;  // Árvore vazia
    
    // Inicializa a pilha de índices livres
    for (int i = 0; i < capacidade_inicial; i++) {
        arvore->livres[i] = i;
    }
    arvore->n_livres = capacidade_inicial;
    
    return arvore;
}

// Funções auxiliares para a árvore AVL otimizada

// Obtém um índice livre para um novo nó
static int obter_indice_livre(ArvoreAVLOtimizada *arvore) {
    if (arvore->n_livres <= 0) {
        // Não há mais índices livres, precisamos redimensionar o array
        int nova_capacidade = arvore->capacidade * 2;
        
        // Redimensiona o array de nós
        NoAVLComprimido *novos_nos = (NoAVLComprimido*)realloc(arvore->nos, nova_capacidade * sizeof(NoAVLComprimido));
        if (!novos_nos)
            return -1;
        
        arvore->nos = novos_nos;
        
        // Redimensiona a pilha de índices livres
        int *novos_livres = (int*)realloc(arvore->livres, nova_capacidade * sizeof(int));
        if (!novos_livres)
            return -1;
        
        arvore->livres = novos_livres;
        
        // Adiciona os novos índices à pilha
        for (int i = arvore->capacidade; i < nova_capacidade; i++) {
            arvore->livres[arvore->n_livres++] = i;
        }
        
        arvore->capacidade = nova_capacidade;
    }
    
    // Retira um índice da pilha
    return arvore->livres[--arvore->n_livres];
}

// Libera um índice para reutilização
static void liberar_indice(ArvoreAVLOtimizada *arvore, int indice) {
    if (indice >= 0 && indice < arvore->capacidade) {
        arvore->livres[arvore->n_livres++] = indice;
    }
}

// Obtém o fator de balanceamento de um nó
static int fator_balanceamento_otimizado(ArvoreAVLOtimizada *arvore, int indice) {
    if (indice < 0)
        return 0;
    
    return arvore->nos[indice].balanco;
}

// Rotação simples à direita (versão otimizada)
static int rotacao_direita_otimizada(ArvoreAVLOtimizada *arvore, int y_idx) {
    NoAVLComprimido *nos = arvore->nos;
    int x_idx = nos[y_idx].esquerda;
    int T2_idx = nos[x_idx].direita;
    
    // Realiza a rotação
    nos[x_idx].direita = y_idx;
    nos[y_idx].esquerda = T2_idx;
    
    // Atualiza os fatores de balanceamento (aproximação simplificada)
    nos[y_idx].balanco = 0;
    nos[x_idx].balanco = 0;
    
    // Retorna o novo índice raiz
    return x_idx;
}

// Rotação simples à esquerda (versão otimizada)
static int rotacao_esquerda_otimizada(ArvoreAVLOtimizada *arvore, int x_idx) {
    NoAVLComprimido *nos = arvore->nos;
    int y_idx = nos[x_idx].direita;
    int T2_idx = nos[y_idx].esquerda;
    
    // Realiza a rotação
    nos[y_idx].esquerda = x_idx;
    nos[x_idx].direita = T2_idx;
    
    // Atualiza os fatores de balanceamento (aproximação simplificada)
    nos[x_idx].balanco = 0;
    nos[y_idx].balanco = 0;
    
    // Retorna o novo índice raiz
    return y_idx;
}

// Balanceia um nó e retorna o novo índice raiz da subárvore
static int balancear_otimizado(ArvoreAVLOtimizada *arvore, int no_idx) {
    if (no_idx < 0)
        return -1;
    
    NoAVLComprimido *nos = arvore->nos;
    int fb = nos[no_idx].balanco;
    
    // Casos de desbalanceamento:
    
    // Caso Esquerda-Esquerda
    if (fb > 1 && fator_balanceamento_otimizado(arvore, nos[no_idx].esquerda) >= 0)
        return rotacao_direita_otimizada(arvore, no_idx);
    
    // Caso Direita-Direita
    if (fb < -1 && fator_balanceamento_otimizado(arvore, nos[no_idx].direita) <= 0)
        return rotacao_esquerda_otimizada(arvore, no_idx);
    
    // Caso Esquerda-Direita
    if (fb > 1 && fator_balanceamento_otimizado(arvore, nos[no_idx].esquerda) < 0) {
        nos[no_idx].esquerda = rotacao_esquerda_otimizada(arvore, nos[no_idx].esquerda);
        return rotacao_direita_otimizada(arvore, no_idx);
    }
    
    // Caso Direita-Esquerda
    if (fb < -1 && fator_balanceamento_otimizado(arvore, nos[no_idx].direita) > 0) {
        nos[no_idx].direita = rotacao_direita_otimizada(arvore, nos[no_idx].direita);
        return rotacao_esquerda_otimizada(arvore, no_idx);
    }
    
    // Nó já está balanceado
    return no_idx;
}

// Encontra o índice do nó com o menor valor em uma subárvore
static int encontrar_minimo_otimizado(ArvoreAVLOtimizada *arvore, int no_idx) {
    NoAVLComprimido *nos = arvore->nos;
    int atual = no_idx;
    
    // Navega para o filho mais à esquerda
    while (atual >= 0 && nos[atual].esquerda >= 0)
        atual = nos[atual].esquerda;
    
    return atual;
}

// Insere um nó recursivamente e mantém a árvore balanceada
static int inserir_no_otimizado(ArvoreAVLOtimizada *arvore, int no_idx, Acidente *acidente, int *sucesso) {
    NoAVLComprimido *nos = arvore->nos;
    
    // 1. Realiza inserção BST normal
    if (no_idx < 0) {
        // Obtém um índice livre para o novo nó
        int novo_idx = obter_indice_livre(arvore);
        if (novo_idx < 0) {
            *sucesso = 0;
            return -1;
        }
        
        // Inicializa o novo nó
        memcpy(&nos[novo_idx].acidente, acidente, sizeof(Acidente));
        nos[novo_idx].esquerda = -1;
        nos[novo_idx].direita = -1;
        nos[novo_idx].balanco = 0;
        
        *sucesso = 1;
        return novo_idx;
    }
    
    // Decide em qual subárvore inserir com base no ID
    if (acidente->id < nos[no_idx].acidente.id) {
        int novo_esquerda = inserir_no_otimizado(arvore, nos[no_idx].esquerda, acidente, sucesso);
        if (*sucesso) {
            nos[no_idx].esquerda = novo_esquerda;
            nos[no_idx].balanco++;  // Incrementa o fator de balanceamento
        }
    } else if (acidente->id > nos[no_idx].acidente.id) {
        int novo_direita = inserir_no_otimizado(arvore, nos[no_idx].direita, acidente, sucesso);
        if (*sucesso) {
            nos[no_idx].direita = novo_direita;
            nos[no_idx].balanco--;  // Decrementa o fator de balanceamento
        }
    } else {
        // ID já existe, substitui os dados
        memcpy(&nos[no_idx].acidente, acidente, sizeof(Acidente));
        *sucesso = 1;
        return no_idx;
    }
    
    // 2. Balanceia a árvore
    return balancear_otimizado(arvore, no_idx);
}

// Remove um nó recursivamente e mantém a árvore balanceada
static int remover_no_otimizado(ArvoreAVLOtimizada *arvore, int no_idx, int id, int *sucesso) {
    if (no_idx < 0) {
        *sucesso = 0;
        return -1;
    }
    
    NoAVLComprimido *nos = arvore->nos;
    
    // Busca o nó a ser removido
    if (id < nos[no_idx].acidente.id) {
        int novo_esquerda = remover_no_otimizado(arvore, nos[no_idx].esquerda, id, sucesso);
        if (*sucesso) {
            nos[no_idx].esquerda = novo_esquerda;
            nos[no_idx].balanco--;  // Atualiza balanceamento
        }
    } else if (id > nos[no_idx].acidente.id) {
        int novo_direita = remover_no_otimizado(arvore, nos[no_idx].direita, id, sucesso);
        if (*sucesso) {
            nos[no_idx].direita = novo_direita;
            nos[no_idx].balanco++;  // Atualiza balanceamento
        }
    } else {
        // Encontrou o nó a ser removido
        
        // Nó com nenhum ou apenas um filho
        if (nos[no_idx].esquerda < 0 || nos[no_idx].direita < 0) {
            int temp_idx = (nos[no_idx].esquerda >= 0) ? nos[no_idx].esquerda : nos[no_idx].direita;
            
            // Nenhum filho
            if (temp_idx < 0) {
                temp_idx = no_idx;
                no_idx = -1;
            } else {
                // Um filho
                memcpy(&nos[no_idx].acidente, &nos[temp_idx].acidente, sizeof(Acidente));
                nos[no_idx].esquerda = nos[temp_idx].esquerda;
                nos[no_idx].direita = nos[temp_idx].direita;
                nos[no_idx].balanco = nos[temp_idx].balanco;
            }
            
            // Libera o índice para reutilização
            liberar_indice(arvore, temp_idx);
            *sucesso = 1;
        } else {
            // Nó com dois filhos
            
            // Encontra o sucessor in-order (menor nó na subárvore direita)
            int sucessor_idx = encontrar_minimo_otimizado(arvore, nos[no_idx].direita);
            
            // Copia os dados do sucessor para este nó
            memcpy(&nos[no_idx].acidente, &nos[sucessor_idx].acidente, sizeof(Acidente));
            
            // Remove o sucessor
            nos[no_idx].direita = remover_no_otimizado(arvore, nos[no_idx].direita, nos[sucessor_idx].acidente.id, sucesso);
            
            if (*sucesso) {
                nos[no_idx].balanco++;  // Atualiza balanceamento
            }
        }
    }
    
    // Se o nó foi removido, retorna
    if (no_idx < 0)
        return -1;
    
    // Balanceia a árvore
    return balancear_otimizado(arvore, no_idx);
}

// Busca um nó iterativamente
static int buscar_no_otimizado(ArvoreAVLOtimizada *arvore, int id) {
    int atual = arvore->raiz;
    NoAVLComprimido *nos = arvore->nos;
    
    while (atual >= 0) {
        if (id == nos[atual].acidente.id)
            return atual;
        
        if (id < nos[atual].acidente.id)
            atual = nos[atual].esquerda;
        else
            atual = nos[atual].direita;
    }
    
    return -1;  // Não encontrado
}

// Implementação das funções públicas da árvore AVL otimizada

int avl_inserir_otimizada(void *_arvore, Acidente *acidente) {
    if (!_arvore || !acidente)
        return 0;
    
    ArvoreAVLOtimizada *arvore = (ArvoreAVLOtimizada*)_arvore;
    int sucesso = 0;
    
    arvore->raiz = inserir_no_otimizado(arvore, arvore->raiz, acidente, &sucesso);
    
    if (sucesso)
        arvore->tamanho++;
    
    return sucesso;
}

Acidente* avl_buscar_otimizada(void *_arvore, int id) {
    if (!_arvore)
        return NULL;
    
    ArvoreAVLOtimizada *arvore = (ArvoreAVLOtimizada*)_arvore;
    int idx = buscar_no_otimizado(arvore, id);
    
    return (idx >= 0) ? &arvore->nos[idx].acidente : NULL;
}

int avl_remover_otimizada(void *_arvore, int id) {
    if (!_arvore)
        return 0;
    
    ArvoreAVLOtimizada *arvore = (ArvoreAVLOtimizada*)_arvore;
    int sucesso = 0;
    
    arvore->raiz = remover_no_otimizado(arvore, arvore->raiz, id, &sucesso);
    
    if (sucesso)
        arvore->tamanho--;
    
    return sucesso;
}

void avl_destruir_otimizada(void *_arvore) {
    if (!_arvore)
        return;
    
    ArvoreAVLOtimizada *arvore = (ArvoreAVLOtimizada*)_arvore;
    
    // Libera os arrays
    free(arvore->nos);
    free(arvore->livres);
    
    // Libera a estrutura da árvore
    free(arvore);
}
