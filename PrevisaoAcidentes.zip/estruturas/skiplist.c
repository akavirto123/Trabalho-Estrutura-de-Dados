/**
 * skiplist.c
 * 
 * Implementação de Skip List para armazenamento e manipulação
 * de dados de acidentes de trânsito com busca eficiente.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "skiplist.h"
#include "../utils/memoria.h"

// Número máximo de níveis para a skip list
#define MAX_NIVEL 16

// Probabilidade de promoção para o próximo nível (0.5 = 50%)
#define PROB_PROMOCAO 0.5

// Tamanho inicial de blocos para a implementação otimizada
#define BLOCO_INICIAL 1024

// Estrutura de um nó da skip list
typedef struct NoSkip {
    Acidente acidente;
    struct NoSkip **proximo;  // Array de ponteiros para o próximo nó em cada nível
    int nivel;                // Nível do nó (0 a MAX_NIVEL-1)
} NoSkip;

// Estrutura da skip list
typedef struct {
    NoSkip *cabeca;           // Nó cabeça (sentinela)
    int nivel_atual;          // Nível atual da skip list
    int tamanho;              // Número de elementos
} SkipList;

// Estrutura de um nó da skip list otimizada (armazenamento contíguo)
typedef struct {
    Acidente acidente;
    int proximo[MAX_NIVEL];   // Índices para o próximo nó em cada nível
    int nivel;                // Nível do nó
} NoSkipOtimizado;

// Estrutura da skip list otimizada
typedef struct {
    NoSkipOtimizado *nos;     // Array de nós
    int cabeca;               // Índice do nó cabeça
    int nivel_atual;          // Nível atual da skip list
    int tamanho;              // Número de elementos
    int capacidade;           // Capacidade total do array
    int proximo_livre;        // Próximo índice livre
} SkipListOtimizada;

// Função auxiliar para gerar um nível aleatório para um novo nó
static int gerar_nivel_aleatorio() {
    int nivel = 0;
    
    // Enquanto um número aleatório for menor que PROB_PROMOCAO e não atingirmos o máximo
    while (rand() < RAND_MAX * PROB_PROMOCAO && nivel < MAX_NIVEL - 1) {
        nivel++;
    }
    
    return nivel;
}

// Implementação da Skip List padrão

void* skiplist_criar() {
    // Inicializa o gerador de números aleatórios
    srand((unsigned int)time(NULL));
    
    SkipList *lista = (SkipList*)malloc(sizeof(SkipList));
    if (!lista) {
        return NULL;
    }
    
    // Cria o nó cabeça (sentinela)
    NoSkip *cabeca = (NoSkip*)malloc(sizeof(NoSkip));
    if (!cabeca) {
        free(lista);
        return NULL;
    }
    
    // Inicializa o nó cabeça
    cabeca->proximo = (NoSkip**)calloc(MAX_NIVEL, sizeof(NoSkip*));
    if (!cabeca->proximo) {
        free(cabeca);
        free(lista);
        return NULL;
    }
    
    cabeca->nivel = MAX_NIVEL - 1;
    
    // Inicializa a skip list
    lista->cabeca = cabeca;
    lista->nivel_atual = 0;
    lista->tamanho = 0;
    
    return lista;
}

int skiplist_inserir(void *_lista, Acidente *acidente) {
    if (!_lista || !acidente) {
        return 0;
    }
    
    SkipList *lista = (SkipList*)_lista;
    NoSkip *atual = lista->cabeca;
    
    // Array para armazenar os pontos de atualização (onde inserir o novo nó)
    NoSkip *atualizacao[MAX_NIVEL];
    
    // Inicializa o array de atualização
    for (int i = 0; i < MAX_NIVEL; i++) {
        atualizacao[i] = lista->cabeca;
    }
    
    // Busca a posição para inserção em cada nível, de cima para baixo
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (atual->proximo[i] && strcmp(atual->proximo[i]->acidente.id, acidente->id) < 0) {
            atual = atual->proximo[i];
        }
        atualizacao[i] = atual;
    }
    
    // Avança para o próximo nó (potencialmente onde inseriremos)
    atual = atual->proximo[0];
    
    // Se o nó já existe, atualizamos os dados
    if (atual && strcmp(atual->acidente.id, acidente->id) == 0) {
        memcpy(&atual->acidente, acidente, sizeof(Acidente));
        return 1;
    }
    
    // Cria um novo nó com nível aleatório
    int novo_nivel = gerar_nivel_aleatorio();
    NoSkip *novo = (NoSkip*)malloc(sizeof(NoSkip));
    if (!novo) {
        return 0;
    }
    
    novo->proximo = (NoSkip**)calloc(novo_nivel + 1, sizeof(NoSkip*));
    if (!novo->proximo) {
        free(novo);
        return 0;
    }
    
    novo->nivel = novo_nivel;
    memcpy(&novo->acidente, acidente, sizeof(Acidente));
    
    // Atualiza o nível atual da skip list se necessário
    if (novo_nivel > lista->nivel_atual) {
        for (int i = lista->nivel_atual + 1; i <= novo_nivel; i++) {
            atualizacao[i] = lista->cabeca;
        }
        lista->nivel_atual = novo_nivel;
    }
    
    // Insere o novo nó em cada nível
    for (int i = 0; i <= novo_nivel; i++) {
        novo->proximo[i] = atualizacao[i]->proximo[i];
        atualizacao[i]->proximo[i] = novo;
    }
    
    lista->tamanho++;
    return 1;
}

Acidente* skiplist_buscar(void *_lista, const char* id) {
    if (!_lista || !id) {
        return NULL;
    }
    
    SkipList *lista = (SkipList*)_lista;
    NoSkip *atual = lista->cabeca;
    
    // Busca em cada nível, de cima para baixo
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (atual->proximo[i] && strcmp(atual->proximo[i]->acidente.id, id) < 0) {
            atual = atual->proximo[i];
        }
    }
    
    // Avança para o próximo nó no nível 0
    atual = atual->proximo[0];
    
    // Verifica se encontramos o nó com o ID desejado
    if (atual && strcmp(atual->acidente.id, id) == 0) {
        return &atual->acidente;
    }
    
    return NULL;  // Não encontrado
}

int skiplist_remover(void *_lista, const char* id) {
    if (!_lista || !id) {
        return 0;
    }
    
    SkipList *lista = (SkipList*)_lista;
    NoSkip *atual = lista->cabeca;
    
    // Array para armazenar os pontos de atualização
    NoSkip *atualizacao[MAX_NIVEL];
    
    // Busca o nó a ser removido em cada nível
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (atual->proximo[i] && strcmp(atual->proximo[i]->acidente.id, id) < 0) {
            atual = atual->proximo[i];
        }
        atualizacao[i] = atual;
    }
    
    // Avança para o próximo nó no nível 0
    atual = atual->proximo[0];
    
    // Verifica se encontramos o nó com o ID desejado
    if (!atual || strcmp(atual->acidente.id, id) != 0) {
        return 0;  // Não encontrado
    }
    
    // Remove o nó de todos os níveis
    for (int i = 0; i <= lista->nivel_atual; i++) {
        if (atualizacao[i]->proximo[i] != atual) {
            break;
        }
        atualizacao[i]->proximo[i] = atual->proximo[i];
    }
    
    // Libera a memória do nó
    free(atual->proximo);
    free(atual);
    
    // Atualiza o nível atual se necessário
    while (lista->nivel_atual > 0 && lista->cabeca->proximo[lista->nivel_atual] == NULL) {
        lista->nivel_atual--;
    }
    
    lista->tamanho--;
    return 1;
}

void skiplist_destruir(void *_lista) {
    if (!_lista) {
        return;
    }
    
    SkipList *lista = (SkipList*)_lista;
    NoSkip *atual = lista->cabeca;
    NoSkip *proximo;
    
    // Libera todos os nós
    while (atual) {
        proximo = atual->proximo[0];
        free(atual->proximo);
        free(atual);
        atual = proximo;
    }
    
    // Libera a estrutura da skip list
    free(lista);
}

int skiplist_tamanho(void *_lista) {
    if (!_lista) {
        return 0;
    }
    
    SkipList *lista = (SkipList*)_lista;
    return lista->tamanho;
}

int skiplist_altura(void *_lista) {
    if (!_lista) {
        return 0;
    }
    
    SkipList *lista = (SkipList*)_lista;
    return lista->nivel_atual + 1;
}

void skiplist_mostrar(void *_lista) {
    if (!_lista) {
        return;
    }
    
    SkipList *lista = (SkipList*)_lista;
    printf("Skip List (tamanho: %d, altura: %d):\n", lista->tamanho, lista->nivel_atual + 1);
    
    for (int i = lista->nivel_atual; i >= 0; i--) {
        printf("Nível %d: ", i);
        NoSkip *atual = lista->cabeca->proximo[i];
        
        while (atual) {
            printf("%d -> ", atual->acidente.id);
            atual = atual->proximo[i];
        }
        
        printf("NULL\n");
    }
}

void skiplist_iterar(void *_lista, void (*func)(Acidente*, void*), void *contexto) {
    if (!_lista || !func) {
        return;
    }
    
    SkipList *lista = (SkipList*)_lista;
    NoSkip *atual = lista->cabeca->proximo[0];
    
    while (atual) {
        func(&atual->acidente, contexto);
        atual = atual->proximo[0];
    }
}

int skiplist_buscar_intervalo(void *_lista, int id_min, int id_max, 
                            Acidente **resultado, int max_tam) {
    if (!_lista || !resultado || max_tam <= 0) {
        return 0;
    }
    
    SkipList *lista = (SkipList*)_lista;
    int count = 0;
    
    // Encontra o primeiro nó maior ou igual a id_min
    NoSkip *atual = lista->cabeca;
    
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (atual->proximo[i] && atual->proximo[i]->acidente.id < id_min) {
            atual = atual->proximo[i];
        }
    }
    
    // Avança para o próximo nó no nível 0
    atual = atual->proximo[0];
    
    // Coleta todos os nós no intervalo [id_min, id_max]
    while (atual && atual->acidente.id <= id_max && count < max_tam) {
        resultado[count++] = &atual->acidente;
        atual = atual->proximo[0];
    }
    
    return count;
}

// Implementação da Skip List Otimizada

void* skiplist_criar_otimizada() {
    // Inicializa o gerador de números aleatórios
    srand((unsigned int)time(NULL));
    
    SkipListOtimizada *lista = (SkipListOtimizada*)malloc(sizeof(SkipListOtimizada));
    if (!lista) {
        return NULL;
    }
    
    // Aloca o array de nós
    lista->nos = (NoSkipOtimizado*)calloc(BLOCO_INICIAL, sizeof(NoSkipOtimizado));
    if (!lista->nos) {
        free(lista);
        return NULL;
    }
    
    // Inicializa a skip list otimizada
    lista->capacidade = BLOCO_INICIAL;
    lista->tamanho = 0;
    lista->nivel_atual = 0;
    
    // Inicializa o nó cabeça (índice 0)
    lista->cabeca = 0;
    lista->nos[0].nivel = MAX_NIVEL - 1;
    for (int i = 0; i < MAX_NIVEL; i++) {
        lista->nos[0].proximo[i] = -1;  // -1 indica NULL
    }
    
    lista->proximo_livre = 1;  // O próximo índice livre é 1
    
    return lista;
}

// Função auxiliar para obter um novo índice
static int obter_novo_indice(SkipListOtimizada *lista) {
    // Verifica se precisa redimensionar
    if (lista->proximo_livre >= lista->capacidade) {
        int nova_capacidade = lista->capacidade * 2;
        NoSkipOtimizado *novos_nos = (NoSkipOtimizado*)realloc(lista->nos, 
                                                            nova_capacidade * sizeof(NoSkipOtimizado));
        if (!novos_nos) {
            return -1;
        }
        
        lista->nos = novos_nos;
        lista->capacidade = nova_capacidade;
    }
    
    return lista->proximo_livre++;
}

int skiplist_inserir_otimizada(void *_lista, Acidente *acidente) {
    if (!_lista || !acidente) {
        return 0;
    }
    
    SkipListOtimizada *lista = (SkipListOtimizada*)_lista;
    int atual = lista->cabeca;
    
    // Array para armazenar os pontos de atualização (onde inserir o novo nó)
    int atualizacao[MAX_NIVEL];
    
    // Inicializa o array de atualização
    for (int i = 0; i < MAX_NIVEL; i++) {
        atualizacao[i] = lista->cabeca;
    }
    
    // Busca a posição para inserção em cada nível, de cima para baixo
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (lista->nos[atual].proximo[i] != -1 && 
               lista->nos[lista->nos[atual].proximo[i]].acidente.id < acidente->id) {
            atual = lista->nos[atual].proximo[i];
        }
        atualizacao[i] = atual;
    }
    
    // Avança para o próximo nó (potencialmente onde inseriremos)
    atual = lista->nos[atual].proximo[0];
    
    // Se o nó já existe, atualizamos os dados
    if (atual != -1 && lista->nos[atual].acidente.id == acidente->id) {
        memcpy(&lista->nos[atual].acidente, acidente, sizeof(Acidente));
        return 1;
    }
    
    // Cria um novo nó com nível aleatório
    int novo_nivel = gerar_nivel_aleatorio();
    int novo_idx = obter_novo_indice(lista);
    if (novo_idx == -1) {
        return 0;
    }
    
    NoSkipOtimizado *novo = &lista->nos[novo_idx];
    novo->nivel = novo_nivel;
    memcpy(&novo->acidente, acidente, sizeof(Acidente));
    
    // Inicializa os ponteiros do novo nó
    for (int i = 0; i <= novo_nivel; i++) {
        novo->proximo[i] = -1;
    }
    
    // Atualiza o nível atual da skip list se necessário
    if (novo_nivel > lista->nivel_atual) {
        for (int i = lista->nivel_atual + 1; i <= novo_nivel; i++) {
            atualizacao[i] = lista->cabeca;
        }
        lista->nivel_atual = novo_nivel;
    }
    
    // Insere o novo nó em cada nível
    for (int i = 0; i <= novo_nivel; i++) {
        novo->proximo[i] = lista->nos[atualizacao[i]].proximo[i];
        lista->nos[atualizacao[i]].proximo[i] = novo_idx;
    }
    
    lista->tamanho++;
    return 1;
}

Acidente* skiplist_buscar_otimizada(void *_lista, int id) {
    if (!_lista) {
        return NULL;
    }
    
    SkipListOtimizada *lista = (SkipListOtimizada*)_lista;
    int atual = lista->cabeca;
    
    // Busca em cada nível, de cima para baixo
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (lista->nos[atual].proximo[i] != -1 && 
               lista->nos[lista->nos[atual].proximo[i]].acidente.id < id) {
            atual = lista->nos[atual].proximo[i];
        }
    }
    
    // Avança para o próximo nó no nível 0
    atual = lista->nos[atual].proximo[0];
    
    // Verifica se encontramos o nó com o ID desejado
    if (atual != -1 && lista->nos[atual].acidente.id == id) {
        return &lista->nos[atual].acidente;
    }
    
    return NULL;  // Não encontrado
}

int skiplist_remover_otimizada(void *_lista, int id) {
    if (!_lista) {
        return 0;
    }
    
    SkipListOtimizada *lista = (SkipListOtimizada*)_lista;
    int atual = lista->cabeca;
    
    // Array para armazenar os pontos de atualização
    int atualizacao[MAX_NIVEL];
    
    // Busca o nó a ser removido em cada nível
    for (int i = lista->nivel_atual; i >= 0; i--) {
        while (lista->nos[atual].proximo[i] != -1 && 
               lista->nos[lista->nos[atual].proximo[i]].acidente.id < id) {
            atual = lista->nos[atual].proximo[i];
        }
        atualizacao[i] = atual;
    }
    
    // Avança para o próximo nó no nível 0
    atual = lista->nos[atual].proximo[0];
    
    // Verifica se encontramos o nó com o ID desejado
    if (atual == -1 || lista->nos[atual].acidente.id != id) {
        return 0;  // Não encontrado
    }
    
    // Remove o nó de todos os níveis
    for (int i = 0; i <= lista->nivel_atual; i++) {
        if (lista->nos[atualizacao[i]].proximo[i] != atual) {
            break;
        }
        lista->nos[atualizacao[i]].proximo[i] = lista->nos[atual].proximo[i];
    }
    
    // Nesta implementação simplificada, não reutilizamos os nós removidos
    // Em uma implementação real, gerenciaríamos uma lista de índices livres
    
    // Atualiza o nível atual se necessário
    while (lista->nivel_atual > 0 && lista->nos[lista->cabeca].proximo[lista->nivel_atual] == -1) {
        lista->nivel_atual--;
    }
    
    lista->tamanho--;
    return 1;
}

void skiplist_destruir_otimizada(void *_lista) {
    if (!_lista) {
        return;
    }
    
    SkipListOtimizada *lista = (SkipListOtimizada*)_lista;
    
    // Libera o array de nós
    free(lista->nos);
    
    // Libera a estrutura da skip list
    free(lista);
}
