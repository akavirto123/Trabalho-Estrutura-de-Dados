/**
 * arvore_avl.h
 * 
 * Implementação de Árvore AVL para armazenamento e manipulação
 * de dados de acidentes de trânsito com balanceamento automático.
 */

#ifndef ARVORE_AVL_H
#define ARVORE_AVL_H

#include "../utils/tipos.h"

/**
 * Cria uma nova árvore AVL vazia.
 * 
 * @return Ponteiro para a nova árvore ou NULL em caso de falha
 */
void* avl_criar();

/**
 * Insere um acidente na árvore AVL.
 * 
 * @param arvore Ponteiro para a árvore
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int avl_inserir(void *arvore, Acidente *acidente);

/**
 * Busca um acidente pelo ID na árvore AVL.
 * 
 * @param arvore Ponteiro para a árvore
 * @param id ID do acidente a ser buscado (string)
 * @return Ponteiro para o acidente encontrado ou NULL se não existir
 */
Acidente* avl_buscar(void *arvore, const char *id);

/**
 * Remove um acidente da árvore pelo ID.
 * 
 * @param arvore Ponteiro para a árvore
 * @param id ID do acidente a ser removido (string)
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int avl_remover(void *arvore, const char *id);

/**
 * Destrói a árvore e libera toda a memória alocada.
 * 
 * @param arvore Ponteiro para a árvore a ser destruída
 */
void avl_destruir(void *arvore);

/**
 * Retorna o número de elementos na árvore.
 * 
 * @param arvore Ponteiro para a árvore
 * @return Número de elementos
 */
int avl_tamanho(void *arvore);

/**
 * Calcula a altura da árvore.
 * 
 * @param arvore Ponteiro para a árvore
 * @return Altura da árvore (0 para árvore vazia)
 */
int avl_altura(void *arvore);

/**
 * Itera sobre todos os elementos da árvore em ordem e aplica uma função a cada um.
 * 
 * @param arvore Ponteiro para a árvore
 * @param func Função a ser aplicada a cada elemento
 * @param contexto Contexto adicional a ser passado para a função
 */
void avl_iterar_em_ordem(void *arvore, void (*func)(Acidente*, void*), void *contexto);

/**
 * Obtém uma lista dos acidentes na árvore dentro de um intervalo de IDs.
 * 
 * @param arvore Ponteiro para a árvore
 * @param id_min ID mínimo (inclusive) como string
 * @param id_max ID máximo (inclusive) como string
 * @param resultado Vetor para armazenar os ponteiros para os acidentes encontrados
 * @param max_tam Tamanho máximo do vetor de resultado
 * @return Número de acidentes encontrados
 */
int avl_buscar_intervalo(void *arvore, const char *id_min, const char *id_max, Acidente **resultado, int max_tam);

/**
 * Obtém uma lista dos acidentes na árvore dentro de um intervalo de datas.
 * 
 * @param arvore Ponteiro para a árvore
 * @param data_min Data mínima (inclusive)
 * @param data_max Data máxima (inclusive)
 * @param resultado Vetor para armazenar os ponteiros para os acidentes encontrados
 * @param max_tam Tamanho máximo do vetor de resultado
 * @return Número de acidentes encontrados
 */
int avl_buscar_por_data(void *arvore, Data data_min, Data data_max, Acidente **resultado, int max_tam);

/**
 * Verifica se a árvore está balanceada.
 * 
 * @param arvore Ponteiro para a árvore
 * @return 1 se balanceada, 0 caso contrário
 */
int avl_esta_balanceada(void *arvore);

/**
 * Versão otimizada da árvore AVL com compressão de nós.
 * 
 * @return Ponteiro para a nova árvore otimizada ou NULL em caso de falha
 */
void* avl_criar_otimizada();

/**
 * Insere um acidente na árvore AVL otimizada.
 * 
 * @param arvore Ponteiro para a árvore otimizada
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int avl_inserir_otimizada(void *arvore, Acidente *acidente);

/**
 * Busca um acidente pelo ID na árvore AVL otimizada.
 * 
 * @param arvore Ponteiro para a árvore otimizada
 * @param id ID do acidente a ser buscado
 * @return Ponteiro para o acidente encontrado ou NULL se não existir
 */
Acidente* avl_buscar_otimizada(void *arvore, int id);

/**
 * Remove um acidente da árvore otimizada pelo ID.
 * 
 * @param arvore Ponteiro para a árvore otimizada
 * @param id ID do acidente a ser removido
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int avl_remover_otimizada(void *arvore, int id);

/**
 * Destrói a árvore otimizada e libera toda a memória alocada.
 * 
 * @param arvore Ponteiro para a árvore otimizada a ser destruída
 */
void avl_destruir_otimizada(void *arvore);

#endif /* ARVORE_AVL_H */
