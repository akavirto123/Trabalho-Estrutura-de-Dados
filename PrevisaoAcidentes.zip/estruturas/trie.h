/**
 * trie.h
 * 
 * Implementação de Trie (Árvore Prefixada) para armazenamento e 
 * busca eficiente de dados de acidentes por chaves textuais.
 */

#ifndef TRIE_H
#define TRIE_H

#include "../utils/tipos.h"

/**
 * Cria uma nova trie vazia.
 * 
 * @return Ponteiro para a nova trie ou NULL em caso de falha
 */
void* trie_criar();

/**
 * Insere um acidente na trie, usando a combinação de UF e BR como chave.
 * 
 * @param trie Ponteiro para a trie
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int trie_inserir(void *trie, Acidente *acidente);

/**
 * Busca um acidente na trie pela chave composta (UF-BR).
 * 
 * @param trie Ponteiro para a trie
 * @param chave String no formato "UF-BR" (ex: "SP-101")
 * @return Ponteiro para o primeiro acidente encontrado ou NULL se não existir
 */
Acidente* trie_buscar(void *trie, const char *chave);

/**
 * Remove um acidente da trie pela chave.
 * 
 * @param trie Ponteiro para a trie
 * @param chave String no formato "UF-BR" (ex: "SP-101")
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int trie_remover(void *trie, const char *chave);

/**
 * Destrói a trie e libera toda a memória alocada.
 * 
 * @param trie Ponteiro para a trie a ser destruída
 */
void trie_destruir(void *trie);

/**
 * Retorna o número de elementos na trie.
 * 
 * @param trie Ponteiro para a trie
 * @return Número de elementos
 */
int trie_tamanho(void *trie);

/**
 * Retorna a profundidade máxima da trie.
 * 
 * @param trie Ponteiro para a trie
 * @return Profundidade máxima
 */
int trie_profundidade(void *trie);

/**
 * Busca todos os acidentes que correspondem a um prefixo de chave.
 * 
 * @param trie Ponteiro para a trie
 * @param prefixo Prefixo para busca (ex: "SP" para todos acidentes em SP)
 * @param resultado Vetor para armazenar os ponteiros para os acidentes encontrados
 * @param max_tam Tamanho máximo do vetor de resultado
 * @return Número de acidentes encontrados
 */
int trie_buscar_por_prefixo(void *trie, const char *prefixo, 
                          Acidente **resultado, int max_tam);

/**
 * Itera sobre todos os elementos da trie e aplica uma função a cada um.
 * 
 * @param trie Ponteiro para a trie
 * @param func Função a ser aplicada a cada elemento
 * @param contexto Contexto adicional a ser passado para a função
 */
void trie_iterar(void *trie, void (*func)(Acidente*, void*), void *contexto);

/**
 * Busca acidentes por UF.
 * 
 * @param trie Ponteiro para a trie
 * @param uf Sigla do estado (UF)
 * @param resultado Vetor para armazenar os ponteiros para os acidentes encontrados
 * @param max_tam Tamanho máximo do vetor de resultado
 * @return Número de acidentes encontrados
 */
int trie_buscar_por_uf(void *trie, const char *uf, 
                     Acidente **resultado, int max_tam);

/**
 * Versão otimizada da trie usando Patricia Trie (Comprimida).
 * 
 * @return Ponteiro para a nova trie otimizada ou NULL em caso de falha
 */
void* trie_criar_otimizada();

/**
 * Insere um acidente na trie otimizada.
 * 
 * @param trie Ponteiro para a trie otimizada
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int trie_inserir_otimizada(void *trie, Acidente *acidente);

/**
 * Busca um acidente na trie otimizada pela chave.
 * 
 * @param trie Ponteiro para a trie otimizada
 * @param chave String no formato "UF-BR" (ex: "SP-101")
 * @return Ponteiro para o primeiro acidente encontrado ou NULL se não existir
 */
Acidente* trie_buscar_otimizada(void *trie, const char *chave);

/**
 * Remove um acidente da trie otimizada pela chave.
 * 
 * @param trie Ponteiro para a trie otimizada
 * @param chave String no formato "UF-BR" (ex: "SP-101")
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int trie_remover_otimizada(void *trie, const char *chave);

/**
 * Destrói a trie otimizada e libera toda a memória alocada.
 * 
 * @param trie Ponteiro para a trie otimizada a ser destruída
 */
void trie_destruir_otimizada(void *trie);

#endif /* TRIE_H */
