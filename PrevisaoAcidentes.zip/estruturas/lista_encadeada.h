/**
 * lista_encadeada.h
 * 
 * Implementação de Lista Encadeada para armazenamento e manipulação
 * de dados de acidentes de trânsito.
 */

#ifndef LISTA_ENCADEADA_H
#define LISTA_ENCADEADA_H

#include "../utils/tipos.h"

/**
 * Cria uma nova lista encadeada vazia.
 * 
 * @return Ponteiro para a nova lista ou NULL em caso de falha
 */
void* lista_criar();

/**
 * Insere um acidente na lista encadeada.
 * 
 * @param lista Ponteiro para a lista
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int lista_inserir(void *lista, Acidente *acidente);

/**
 * Busca um acidente pelo ID na lista encadeada.
 * 
 * @param lista Ponteiro para a lista
 * @param id ID do acidente a ser buscado
 * @return Ponteiro para o acidente encontrado ou NULL se não existir
 */
Acidente* lista_buscar(void *lista, const char* id);

/**
 * Remove um acidente da lista pelo ID.
 * 
 * @param lista Ponteiro para a lista
 * @param id ID do acidente a ser removido
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int lista_remover(void *lista, const char* id);

/**
 * Destrói a lista e libera toda a memória alocada.
 * 
 * @param lista Ponteiro para a lista a ser destruída
 */
void lista_destruir(void *lista);

/**
 * Retorna o número de elementos na lista.
 * 
 * @param lista Ponteiro para a lista
 * @return Número de elementos
 */
int lista_tamanho(void *lista);

/**
 * Itera sobre todos os elementos da lista e aplica uma função a cada um.
 * 
 * @param lista Ponteiro para a lista
 * @param func Função a ser aplicada a cada elemento
 * @param contexto Contexto adicional a ser passado para a função
 */
void lista_iterar(void *lista, void (*func)(Acidente*, void*), void *contexto);

/**
 * Ordena a lista encadeada com base em um critério específico.
 * 
 * @param lista Ponteiro para a lista
 * @param criterio Critério de ordenação (0=ID, 1=Data, 2=UF, etc)
 * @return 1 se ordenado com sucesso, 0 caso contrário
 */
int lista_ordenar(void *lista, int criterio);

/**
 * Filtra os elementos da lista com base em um critério.
 * 
 * @param lista Ponteiro para a lista original
 * @param criterio Função que define o critério de filtragem
 * @param contexto Contexto adicional para a função de filtragem
 * @return Nova lista contendo apenas os elementos que atendem ao critério
 */
void* lista_filtrar(void *lista, int (*criterio)(Acidente*, void*), void *contexto);

/**
 * Versão otimizada da lista encadeada usando blocos de memória contíguos.
 * 
 * @return Ponteiro para a nova lista otimizada ou NULL em caso de falha
 */
void* lista_criar_otimizada();

/**
 * Insere um acidente na lista encadeada otimizada.
 * 
 * @param lista Ponteiro para a lista otimizada
 * @param acidente Ponteiro para o acidente a ser inserido
 * @return 1 se inserido com sucesso, 0 caso contrário
 */
int lista_inserir_otimizada(void *lista, Acidente *acidente);

/**
 * Busca um acidente pelo ID na lista encadeada otimizada.
 * 
 * @param lista Ponteiro para a lista otimizada
 * @param id ID do acidente a ser buscado
 * @return Ponteiro para o acidente encontrado ou NULL se não existir
 */
Acidente* lista_buscar_otimizada(void *lista, int id);

/**
 * Remove um acidente da lista otimizada pelo ID.
 * 
 * @param lista Ponteiro para a lista otimizada
 * @param id ID do acidente a ser removido
 * @return 1 se removido com sucesso, 0 caso contrário
 */
int lista_remover_otimizada(void *lista, int id);

/**
 * Destrói a lista otimizada e libera toda a memória alocada.
 * 
 * @param lista Ponteiro para a lista otimizada a ser destruída
 */
void lista_destruir_otimizada(void *lista);

#endif /* LISTA_ENCADEADA_H */
