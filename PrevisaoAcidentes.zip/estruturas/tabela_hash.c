/**
 * tabela_hash.c
 * 
 * Implementação de Tabela Hash para armazenamento e manipulação
 * de dados de acidentes de trânsito com resolução de colisões.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tabela_hash.h"
#include "../utils/memoria.h"

// Protótipos de funções internas
int hash_redimensionar(void *tabela, int novo_tamanho);
Acidente* hash_buscar_cuckoo(void *tabela, int id);

// Tamanho inicial padrão para a tabela hash
#define TAMANHO_PADRAO 1024

// Fator de carga para redimensionamento (75%)
#define FATOR_CARGA_LIMITE 0.75

// Número máximo de tentativas para o Cuckoo Hashing
#define MAX_CUCKOO_TENTATIVAS 100

// Estado de slots na tabela hash
#define SLOT_VAZIO 0
#define SLOT_OCUPADO 1
#define SLOT_REMOVIDO 2

// Estrutura de um item na tabela hash
typedef struct {
    Acidente acidente;
    int estado;  // 0 = vazio, 1 = ocupado, 2 = removido
} ItemHash;

// Estrutura da tabela hash
typedef struct {
    ItemHash *tabela;
    int tamanho;           // Número de slots na tabela
    int elementos;         // Número de elementos inseridos
    int colisoes;          // Contador de colisões
    int tipo_resolucao;    // Método de resolução de colisões (0 = sondagem linear, 1 = encadeamento)
} TabelaHash;

// Estrutura para o nó de lista encadeada (usado em hash com encadeamento)
typedef struct NoLista {
    Acidente acidente;
    struct NoLista *proximo;
} NoLista;

// Estrutura para tabela hash com encadeamento separado
typedef struct {
    NoLista **tabela;      // Array de ponteiros para listas
    int tamanho;           // Número de slots na tabela
    int elementos;         // Número de elementos inseridos
    int colisoes;          // Contador de colisões
} TabelaHashEncadeada;

// Estrutura para tabela hash com Cuckoo Hashing
typedef struct {
    ItemHash *tabela1;     // Primeira tabela
    ItemHash *tabela2;     // Segunda tabela
    int tamanho;           // Número de slots em cada tabela
    int elementos;         // Número de elementos inseridos
    int colisoes;          // Contador de colisões
} TabelaHashCuckoo;

// Funções de hash

// Função de hash para strings (djb2 algorithm)
static unsigned int hash_string(const char* str, int tamanho) {
    unsigned int hash = 5381;
    int c;
    
    while ((c = *str++)) {
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    }
    
    return hash % tamanho;
}

// Função de hash primária (usando string)
static unsigned int hash1(const char* chave, int tamanho) {
    return hash_string(chave, tamanho);
}

// Função de hash secundária (usando outra técnica)
static unsigned int hash2(const char* chave, int tamanho) {
    unsigned int hash = 0;
    for (int i = 0; chave[i]; i++) {
        hash = (hash * 65599) + chave[i];
    }
    return (hash % (tamanho - 1)) + 1;  // Evita 0 para hash dupla
}

// Função de hash dupla para sondagem
static unsigned int hash_duplo(const char* chave, int i, int tamanho) {
    return (hash1(chave, tamanho) + i * hash2(chave, tamanho)) % tamanho;
}

// Implementação das funções para tabela hash com sondagem linear

void* hash_criar(int tamanho) {
    if (tamanho <= 0) {
        tamanho = TAMANHO_PADRAO;
    }
    
    TabelaHash *tabela = (TabelaHash*)malloc(sizeof(TabelaHash));
    if (!tabela) {
        return NULL;
    }
    
    tabela->tabela = (ItemHash*)calloc(tamanho, sizeof(ItemHash));
    if (!tabela->tabela) {
        free(tabela);
        return NULL;
    }
    
    // Inicializa todos os slots como vazios
    for (int i = 0; i < tamanho; i++) {
        tabela->tabela[i].estado = SLOT_VAZIO;
    }
    
    tabela->tamanho = tamanho;
    tabela->elementos = 0;
    tabela->colisoes = 0;
    tabela->tipo_resolucao = 0;  // Sondagem linear por padrão
    
    return tabela;
}

int hash_inserir(void *_tabela, Acidente *acidente) {
    if (!_tabela || !acidente) {
        return 0;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    
    // Verifica se precisa redimensionar
    if ((float)tabela->elementos / tabela->tamanho >= FATOR_CARGA_LIMITE) {
        if (!hash_redimensionar(_tabela, tabela->tamanho * 2)) {
            return 0;  // Falha ao redimensionar
        }
    }
    
    unsigned int hash = hash1(acidente->id, tabela->tamanho);
    int posicao = hash;
    int i = 0;
    
    // Verificamos se a posição já está ocupada
    while (tabela->tabela[posicao].estado == SLOT_OCUPADO && i < tabela->tamanho) {
        // Se o ID já existe, substituímos
        if (strcmp(tabela->tabela[posicao].acidente.id, acidente->id) == 0) {
            memcpy(&tabela->tabela[posicao].acidente, acidente, sizeof(Acidente));
            return 1;
        }
        
        // Colisão, tenta a próxima posição
        tabela->colisoes++;
        
        // Escolhe a técnica de resolução de colisão
        if (tabela->tipo_resolucao == 0) {
            // Sondagem linear
            i++;
            posicao = (hash + i) % tabela->tamanho;
        } else {
            // Sondagem com hash duplo
            i++;
            posicao = hash_duplo(acidente->id, i, tabela->tamanho);
        }
    }
    
    // Se chegamos aqui, encontramos um slot vazio ou removido
    memcpy(&tabela->tabela[posicao].acidente, acidente, sizeof(Acidente));
    tabela->tabela[posicao].estado = SLOT_OCUPADO;
    tabela->elementos++;
    
    return 1;
}

Acidente* hash_buscar(void *_tabela, const char* id) {
    if (!_tabela || !id) {
        return NULL;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    unsigned int hash = hash1(id, tabela->tamanho);
    int posicao = hash;
    int i = 0;
    
    while (i < tabela->tamanho) {
        // Se o slot está vazio, o item não existe
        if (tabela->tabela[posicao].estado == SLOT_VAZIO) {
            return NULL;
        }
        
        // Se o slot está ocupado e o ID coincide, encontramos
        if (tabela->tabela[posicao].estado == SLOT_OCUPADO && 
            strcmp(tabela->tabela[posicao].acidente.id, id) == 0) {
            return &tabela->tabela[posicao].acidente;
        }
        
        // Tenta a próxima posição
        if (tabela->tipo_resolucao == 0) {
            // Sondagem linear
            i++;
            posicao = (hash + i) % tabela->tamanho;
        } else {
            // Sondagem com hash duplo
            i++;
            posicao = hash_duplo(id, i, tabela->tamanho);
        }
    }
    
    return NULL;  // Não encontrado
}

int hash_remover(void *_tabela, const char* id) {
    if (!_tabela || !id) {
        return 0;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    unsigned int hash = hash1(id, tabela->tamanho);
    int posicao = hash;
    int i = 0;
    
    while (i < tabela->tamanho) {
        // Se o slot está vazio, o item não existe
        if (tabela->tabela[posicao].estado == SLOT_VAZIO) {
            return 0;
        }
        
        // Se o slot está ocupado e o ID coincide, removemos
        if (tabela->tabela[posicao].estado == SLOT_OCUPADO && 
            strcmp(tabela->tabela[posicao].acidente.id, id) == 0) {
            tabela->tabela[posicao].estado = SLOT_REMOVIDO;
            tabela->elementos--;
            return 1;
        }
        
        // Tenta a próxima posição
        if (tabela->tipo_resolucao == 0) {
            // Sondagem linear
            i++;
            posicao = (hash + i) % tabela->tamanho;
        } else {
            // Sondagem com hash duplo
            i++;
            posicao = hash_duplo(id, i, tabela->tamanho);
        }
    }
    
    return 0;  // Não encontrado
}

void hash_destruir(void *_tabela) {
    if (!_tabela) {
        return;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    
    free(tabela->tabela);
    free(tabela);
}

int hash_tamanho(void *_tabela) {
    if (!_tabela) {
        return 0;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    return tabela->elementos;
}

int hash_obter_colisoes(void *_tabela) {
    if (!_tabela) {
        return 0;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    return tabela->colisoes;
}

float hash_fator_carga(void *_tabela) {
    if (!_tabela) {
        return 0.0f;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    return (float)tabela->elementos / tabela->tamanho;
}

int hash_redimensionar(void *_tabela, int novo_tamanho) {
    if (!_tabela || novo_tamanho <= 0) {
        return 0;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    
    // Cria uma nova tabela com o novo tamanho
    TabelaHash *nova_tabela = (TabelaHash*)hash_criar(novo_tamanho);
    if (!nova_tabela) {
        return 0;
    }
    
    // Herda o método de resolução de colisões
    nova_tabela->tipo_resolucao = tabela->tipo_resolucao;
    
    // Transfere todos os itens para a nova tabela
    for (int i = 0; i < tabela->tamanho; i++) {
        if (tabela->tabela[i].estado == SLOT_OCUPADO) {
            hash_inserir(nova_tabela, &tabela->tabela[i].acidente);
        }
    }
    
    // Libera a tabela antiga
    ItemHash *antiga_tabela = tabela->tabela;
    int antigas_colisoes = tabela->colisoes;
    
    // Transfere a nova tabela para a antiga estrutura
    tabela->tabela = nova_tabela->tabela;
    tabela->tamanho = nova_tabela->tamanho;
    tabela->elementos = nova_tabela->elementos;
    tabela->colisoes = antigas_colisoes + nova_tabela->colisoes;
    
    // Libera a estrutura temporária (mas não os dados)
    free(antiga_tabela);
    free(nova_tabela);
    
    return 1;
}

void hash_iterar(void *_tabela, void (*func)(Acidente*, void*), void *contexto) {
    if (!_tabela || !func) {
        return;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    
    for (int i = 0; i < tabela->tamanho; i++) {
        if (tabela->tabela[i].estado == SLOT_OCUPADO) {
            func(&tabela->tabela[i].acidente, contexto);
        }
    }
}

int hash_obter_todos(void *_tabela, Acidente **resultado, int max_tam) {
    if (!_tabela || !resultado || max_tam <= 0) {
        return 0;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    int count = 0;
    
    for (int i = 0; i < tabela->tamanho && count < max_tam; i++) {
        if (tabela->tabela[i].estado == SLOT_OCUPADO) {
            resultado[count++] = &tabela->tabela[i].acidente;
        }
    }
    
    return count;
}

void* hash_filtrar(void *_tabela, int (*criterio)(Acidente*, void*), void *contexto) {
    if (!_tabela || !criterio) {
        return NULL;
    }
    
    TabelaHash *tabela = (TabelaHash*)_tabela;
    
    // Cria uma nova tabela hash para armazenar os resultados filtrados
    void *nova_tabela = hash_criar(TAMANHO_PADRAO);
    if (!nova_tabela) {
        return NULL;
    }
    
    // Itera sobre todos os elementos da tabela original
    for (int i = 0; i < tabela->tamanho; i++) {
        if (tabela->tabela[i].estado == SLOT_OCUPADO && 
            criterio(&tabela->tabela[i].acidente, contexto)) {
            // Insere na nova tabela os acidentes que atendem ao critério
            hash_inserir(nova_tabela, &tabela->tabela[i].acidente);
        }
    }
    
    return nova_tabela;
}

// Implementação das funções para tabela hash com Cuckoo Hashing

void* hash_criar_cuckoo(int tamanho) {
    if (tamanho <= 0) {
        tamanho = TAMANHO_PADRAO;
    }
    
    TabelaHashCuckoo *tabela = (TabelaHashCuckoo*)malloc(sizeof(TabelaHashCuckoo));
    if (!tabela) {
        return NULL;
    }
    
    tabela->tabela1 = (ItemHash*)calloc(tamanho, sizeof(ItemHash));
    tabela->tabela2 = (ItemHash*)calloc(tamanho, sizeof(ItemHash));
    
    if (!tabela->tabela1 || !tabela->tabela2) {
        if (tabela->tabela1) free(tabela->tabela1);
        if (tabela->tabela2) free(tabela->tabela2);
        free(tabela);
        return NULL;
    }
    
    // Inicializa todos os slots como vazios
    for (int i = 0; i < tamanho; i++) {
        tabela->tabela1[i].estado = SLOT_VAZIO;
        tabela->tabela2[i].estado = SLOT_VAZIO;
    }
    
    tabela->tamanho = tamanho;
    tabela->elementos = 0;
    tabela->colisoes = 0;
    
    return tabela;
}

int hash_inserir_cuckoo(void *_tabela, Acidente *acidente) {
    if (!_tabela || !acidente) {
        return 0;
    }
    
    TabelaHashCuckoo *tabela = (TabelaHashCuckoo*)_tabela;
    
    // Verifica se o item já existe
    Acidente *existente = hash_buscar_cuckoo(_tabela, acidente->id);
    if (existente) {
        // Substitui os dados e retorna
        memcpy(existente, acidente, sizeof(Acidente));
        return 1;
    }
    
    // Se o fator de carga estiver muito alto, redimensiona
    if ((float)tabela->elementos / (2 * tabela->tamanho) >= 0.5) {
        // Cria uma nova tabela com o dobro do tamanho
        TabelaHashCuckoo *nova_tabela = (TabelaHashCuckoo*)hash_criar_cuckoo(tabela->tamanho * 2);
        if (!nova_tabela) {
            return 0;
        }
        
        // Transfere todos os itens para a nova tabela
        for (int i = 0; i < tabela->tamanho; i++) {
            if (tabela->tabela1[i].estado == SLOT_OCUPADO) {
                hash_inserir_cuckoo(nova_tabela, &tabela->tabela1[i].acidente);
            }
            if (tabela->tabela2[i].estado == SLOT_OCUPADO) {
                hash_inserir_cuckoo(nova_tabela, &tabela->tabela2[i].acidente);
            }
        }
        
        // Troca as tabelas
        ItemHash *antiga_tabela1 = tabela->tabela1;
        ItemHash *antiga_tabela2 = tabela->tabela2;
        int antigo_tamanho = tabela->tamanho;
        
        tabela->tabela1 = nova_tabela->tabela1;
        tabela->tabela2 = nova_tabela->tabela2;
        tabela->tamanho = nova_tabela->tamanho;
        tabela->elementos = nova_tabela->elementos;
        
        // Libera a tabela temporária
        free(antiga_tabela1);
        free(antiga_tabela2);
        free(nova_tabela);
    }
    
    // Tenta inserir o novo item
    Acidente atual = *acidente;
    int usar_tabela1 = 1;  // Começa com a tabela 1
    
    for (int tentativa = 0; tentativa < MAX_CUCKOO_TENTATIVAS; tentativa++) {
        unsigned int posicao;
        
        if (usar_tabela1) {
            posicao = hash1(atual.id, tabela->tamanho);
            
            if (tabela->tabela1[posicao].estado != SLOT_OCUPADO) {
                // Slot livre, insere e termina
                memcpy(&tabela->tabela1[posicao].acidente, &atual, sizeof(Acidente));
                tabela->tabela1[posicao].estado = SLOT_OCUPADO;
                tabela->elementos++;
                return 1;
            } else {
                // Colisão, guarda o item atual e desloca o existente
                tabela->colisoes++;
                Acidente temp = tabela->tabela1[posicao].acidente;
                tabela->tabela1[posicao].acidente = atual;
                atual = temp;
                usar_tabela1 = 0;  // Próxima tentativa na tabela 2
            }
        } else {
            posicao = hash2(atual.id, tabela->tamanho);
            
            if (tabela->tabela2[posicao].estado != SLOT_OCUPADO) {
                // Slot livre, insere e termina
                memcpy(&tabela->tabela2[posicao].acidente, &atual, sizeof(Acidente));
                tabela->tabela2[posicao].estado = SLOT_OCUPADO;
                tabela->elementos++;
                return 1;
            } else {
                // Colisão, guarda o item atual e desloca o existente
                tabela->colisoes++;
                Acidente temp = tabela->tabela2[posicao].acidente;
                tabela->tabela2[posicao].acidente = atual;
                atual = temp;
                usar_tabela1 = 1;  // Próxima tentativa na tabela 1
            }
        }
    }
    
    // Se chegamos aqui, não conseguimos inserir após várias tentativas
    // Em uma implementação real, redimensionaríamos a tabela e tentaríamos novamente
    return 0;
}

Acidente* hash_buscar_cuckoo(void *_tabela, int id) {
    if (!_tabela) {
        return NULL;
    }
    
    TabelaHashCuckoo *tabela = (TabelaHashCuckoo*)_tabela;
    
    // Verifica na primeira tabela
    unsigned int pos1 = hash1(id, tabela->tamanho);
    if (tabela->tabela1[pos1].estado == SLOT_OCUPADO && 
        tabela->tabela1[pos1].acidente.id == id) {
        return &tabela->tabela1[pos1].acidente;
    }
    
    // Verifica na segunda tabela
    unsigned int pos2 = hash2(id, tabela->tamanho);
    if (tabela->tabela2[pos2].estado == SLOT_OCUPADO && 
        tabela->tabela2[pos2].acidente.id == id) {
        return &tabela->tabela2[pos2].acidente;
    }
    
    return NULL;  // Não encontrado
}

int hash_remover_cuckoo(void *_tabela, int id) {
    if (!_tabela) {
        return 0;
    }
    
    TabelaHashCuckoo *tabela = (TabelaHashCuckoo*)_tabela;
    
    // Verifica na primeira tabela
    unsigned int pos1 = hash1(id, tabela->tamanho);
    if (tabela->tabela1[pos1].estado == SLOT_OCUPADO && 
        tabela->tabela1[pos1].acidente.id == id) {
        tabela->tabela1[pos1].estado = SLOT_REMOVIDO;
        tabela->elementos--;
        return 1;
    }
    
    // Verifica na segunda tabela
    unsigned int pos2 = hash2(id, tabela->tamanho);
    if (tabela->tabela2[pos2].estado == SLOT_OCUPADO && 
        tabela->tabela2[pos2].acidente.id == id) {
        tabela->tabela2[pos2].estado = SLOT_REMOVIDO;
        tabela->elementos--;
        return 1;
    }
    
    return 0;  // Não encontrado
}

void hash_destruir_cuckoo(void *_tabela) {
    if (!_tabela) {
        return;
    }
    
    TabelaHashCuckoo *tabela = (TabelaHashCuckoo*)_tabela;
    
    free(tabela->tabela1);
    free(tabela->tabela2);
    free(tabela);
}
