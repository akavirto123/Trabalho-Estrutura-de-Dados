/**
 * trie.c
 * 
 * Implementação de Trie (Árvore Prefixada) para armazenamento e 
 * busca eficiente de dados de acidentes por chaves textuais.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "trie.h"
#include "../utils/memoria.h"

// Tamanho do alfabeto (caracteres permitidos na chave)
#define ALFABETO_TAMANHO 128

// Estrutura de um nó da trie
typedef struct NoTrie {
    struct NoTrie *filhos[ALFABETO_TAMANHO]; // Ponteiros para os filhos (um para cada caractere possível)
    Acidente *acidente;                      // Ponteiro para o acidente (NULL se não for fim de palavra)
    int e_fim_palavra;                       // Flag indicando se o nó representa o fim de uma palavra
    int n_acidentes;                         // Número de acidentes associados a este nó (para prefixos)
} NoTrie;

// Estrutura da trie
typedef struct {
    NoTrie *raiz;    // Nó raiz da trie
    int tamanho;     // Número de elementos (chaves) na trie
    int profundidade; // Profundidade máxima da trie
} Trie;

// Estrutura de um nó da trie comprimida (Patricia Trie)
typedef struct NoTrieComprimido {
    struct NoTrieComprimido *filhos[ALFABETO_TAMANHO]; // Ponteiros para os filhos
    char *segmento;                                    // Segmento de chave comprimido
    Acidente *acidente;                                // Ponteiro para o acidente
    int e_fim_palavra;                                 // Flag indicando se o nó representa o fim de uma palavra
    int n_acidentes;                                   // Número de acidentes associados a este nó
} NoTrieComprimido;

// Estrutura da trie comprimida
typedef struct {
    NoTrieComprimido *raiz;  // Nó raiz da trie comprimida
    int tamanho;            // Número de elementos na trie
    int profundidade;       // Profundidade máxima da trie
} TrieComprimida;

// Função auxiliar para criar um novo nó da trie
static NoTrie* criar_no_trie() {
    NoTrie *no = (NoTrie*)malloc(sizeof(NoTrie));
    if (!no) {
        return NULL;
    }
    
    // Inicializa todos os filhos como NULL
    for (int i = 0; i < ALFABETO_TAMANHO; i++) {
        no->filhos[i] = NULL;
    }
    
    no->acidente = NULL;
    no->e_fim_palavra = 0;
    no->n_acidentes = 0;
    
    return no;
}

// Função auxiliar para criar um novo nó da trie comprimida
static NoTrieComprimido* criar_no_trie_comprimido() {
    NoTrieComprimido *no = (NoTrieComprimido*)malloc(sizeof(NoTrieComprimido));
    if (!no) {
        return NULL;
    }
    
    // Inicializa todos os filhos como NULL
    for (int i = 0; i < ALFABETO_TAMANHO; i++) {
        no->filhos[i] = NULL;
    }
    
    no->segmento = NULL;
    no->acidente = NULL;
    no->e_fim_palavra = 0;
    no->n_acidentes = 0;
    
    return no;
}

// Função auxiliar para criar a chave composta a partir de um acidente
static char* criar_chave(Acidente *acidente) {
    if (!acidente) {
        return NULL;
    }
    
    // Formato da chave: "UF-BR" (ex: "SP-101")
    char *chave = (char*)malloc(20 * sizeof(char));  // Tamanho suficiente para UF-BR
    if (!chave) {
        return NULL;
    }
    
    sprintf(chave, "%s-%s", acidente->local.uf, acidente->local.br);
    return chave;
}

// Implementação das funções da trie padrão

void* trie_criar() {
    Trie *trie = (Trie*)malloc(sizeof(Trie));
    if (!trie) {
        return NULL;
    }
    
    trie->raiz = criar_no_trie();
    if (!trie->raiz) {
        free(trie);
        return NULL;
    }
    
    trie->tamanho = 0;
    trie->profundidade = 0;
    
    return trie;
}

int trie_inserir(void *_trie, Acidente *acidente) {
    if (!_trie || !acidente) {
        return 0;
    }
    
    // Cria a chave composta
    char *chave = criar_chave(acidente);
    if (!chave) {
        return 0;
    }
    
    Trie *trie = (Trie*)_trie;
    NoTrie *atual = trie->raiz;
    int profundidade = 0;
    
    // Percorre a trie seguindo os caracteres da chave
    for (int i = 0; chave[i]; i++) {
        int indice = (unsigned char)chave[i];
        profundidade++;
        
        // Verifica se o índice está dentro dos limites do alfabeto
        if (indice >= ALFABETO_TAMANHO) {
            free(chave);
            return 0;
        }
        
        // Se o filho não existe, cria um novo nó
        if (!atual->filhos[indice]) {
            atual->filhos[indice] = criar_no_trie();
            if (!atual->filhos[indice]) {
                free(chave);
                return 0;
            }
        }
        
        // Avança para o próximo nó
        atual = atual->filhos[indice];
        atual->n_acidentes++;  // Incrementa o contador de acidentes no caminho
    }
    
    // Marca o nó como fim de palavra e guarda o ponteiro para o acidente
    atual->e_fim_palavra = 1;
    atual->acidente = acidente;
    
    // Atualiza os metadados da trie
    trie->tamanho++;
    if (profundidade > trie->profundidade) {
        trie->profundidade = profundidade;
    }
    
    free(chave);
    return 1;
}

Acidente* trie_buscar(void *_trie, const char *chave) {
    if (!_trie || !chave) {
        return NULL;
    }
    
    Trie *trie = (Trie*)_trie;
    NoTrie *atual = trie->raiz;
    
    // Percorre a trie seguindo os caracteres da chave
    for (int i = 0; chave[i]; i++) {
        int indice = (unsigned char)chave[i];
        
        // Verifica se o índice está dentro dos limites do alfabeto
        if (indice >= ALFABETO_TAMANHO) {
            return NULL;
        }
        
        // Se o filho não existe, a chave não está na trie
        if (!atual->filhos[indice]) {
            return NULL;
        }
        
        // Avança para o próximo nó
        atual = atual->filhos[indice];
    }
    
    // Verifica se chegamos ao fim de uma palavra
    if (atual->e_fim_palavra) {
        return atual->acidente;
    }
    
    return NULL;  // Não encontrado
}

// Função auxiliar para remover recursivamente
static NoTrie* remover_recursivo(NoTrie *no, const char *chave, int profundidade, int *sucesso) {
    // Caso base: árvore vazia
    if (!no) {
        return NULL;
    }
    
    // Se chegamos ao fim da chave
    if (!chave[profundidade]) {
        // Este nó não é mais fim de palavra
        if (no->e_fim_palavra) {
            no->e_fim_palavra = 0;
            no->acidente = NULL;
            *sucesso = 1;
        }
        
        // Se este nó não tem filhos, pode ser deletado
        int tem_filhos = 0;
        for (int i = 0; i < ALFABETO_TAMANHO; i++) {
            if (no->filhos[i]) {
                tem_filhos = 1;
                break;
            }
        }
        
        if (!tem_filhos) {
            free(no);
            return NULL;
        }
        
        return no;
    }
    
    // Se não chegamos ao fim da chave, recorremos para o filho apropriado
    int indice = (unsigned char)chave[profundidade];
    
    // Verifica se o índice está dentro dos limites do alfabeto
    if (indice >= ALFABETO_TAMANHO) {
        return no;
    }
    
    no->filhos[indice] = remover_recursivo(no->filhos[indice], chave, profundidade + 1, sucesso);
    
    // Se o nó não tem filhos e não é fim de palavra, pode ser deletado
    if (*sucesso) {
        int tem_filhos = 0;
        for (int i = 0; i < ALFABETO_TAMANHO; i++) {
            if (no->filhos[i]) {
                tem_filhos = 1;
                break;
            }
        }
        
        if (!tem_filhos && !no->e_fim_palavra) {
            free(no);
            return NULL;
        }
    }
    
    return no;
}

int trie_remover(void *_trie, const char *chave) {
    if (!_trie || !chave) {
        return 0;
    }
    
    Trie *trie = (Trie*)_trie;
    int sucesso = 0;
    
    trie->raiz = remover_recursivo(trie->raiz, chave, 0, &sucesso);
    
    if (sucesso) {
        trie->tamanho--;
    }
    
    return sucesso;
}

// Função auxiliar para destruir recursivamente todos os nós
static void destruir_recursivo(NoTrie *no) {
    if (!no) {
        return;
    }
    
    // Destrói todos os filhos
    for (int i = 0; i < ALFABETO_TAMANHO; i++) {
        if (no->filhos[i]) {
            destruir_recursivo(no->filhos[i]);
        }
    }
    
    // Destrói o nó atual
    free(no);
}

void trie_destruir(void *_trie) {
    if (!_trie) {
        return;
    }
    
    Trie *trie = (Trie*)_trie;
    
    // Destrói recursivamente todos os nós
    destruir_recursivo(trie->raiz);
    
    // Destrói a estrutura da trie
    free(trie);
}

int trie_tamanho(void *_trie) {
    if (!_trie) {
        return 0;
    }
    
    Trie *trie = (Trie*)_trie;
    return trie->tamanho;
}

int trie_profundidade(void *_trie) {
    if (!_trie) {
        return 0;
    }
    
    Trie *trie = (Trie*)_trie;
    return trie->profundidade;
}

// Função auxiliar para coletar recursivamente todos os acidentes que correspondem a um prefixo
static int coletar_por_prefixo(NoTrie *no, Acidente **resultado, int max_tam, int pos) {
    if (!no || pos >= max_tam) {
        return pos;
    }
    
    // Se este nó é fim de palavra, adiciona ao resultado
    if (no->e_fim_palavra && no->acidente) {
        resultado[pos++] = no->acidente;
    }
    
    // Recursivamente coleta acidentes de todos os filhos
    for (int i = 0; i < ALFABETO_TAMANHO && pos < max_tam; i++) {
        if (no->filhos[i]) {
            pos = coletar_por_prefixo(no->filhos[i], resultado, max_tam, pos);
        }
    }
    
    return pos;
}

int trie_buscar_por_prefixo(void *_trie, const char *prefixo, Acidente **resultado, int max_tam) {
    if (!_trie || !prefixo || !resultado || max_tam <= 0) {
        return 0;
    }
    
    Trie *trie = (Trie*)_trie;
    NoTrie *atual = trie->raiz;
    
    // Percorre a trie seguindo os caracteres do prefixo
    for (int i = 0; prefixo[i]; i++) {
        int indice = (unsigned char)prefixo[i];
        
        // Verifica se o índice está dentro dos limites do alfabeto
        if (indice >= ALFABETO_TAMANHO) {
            return 0;
        }
        
        // Se o filho não existe, o prefixo não está na trie
        if (!atual->filhos[indice]) {
            return 0;
        }
        
        // Avança para o próximo nó
        atual = atual->filhos[indice];
    }
    
    // Coleta todos os acidentes a partir do nó atual
    return coletar_por_prefixo(atual, resultado, max_tam, 0);
}

// Função auxiliar para iterar recursivamente sobre todos os nós
static void iterar_recursivo(NoTrie *no, void (*func)(Acidente*, void*), void *contexto) {
    if (!no) {
        return;
    }
    
    // Se este nó é fim de palavra, processa o acidente
    if (no->e_fim_palavra && no->acidente) {
        func(no->acidente, contexto);
    }
    
    // Recursivamente itera sobre todos os filhos
    for (int i = 0; i < ALFABETO_TAMANHO; i++) {
        if (no->filhos[i]) {
            iterar_recursivo(no->filhos[i], func, contexto);
        }
    }
}

void trie_iterar(void *_trie, void (*func)(Acidente*, void*), void *contexto) {
    if (!_trie || !func) {
        return;
    }
    
    Trie *trie = (Trie*)_trie;
    
    // Itera recursivamente a partir da raiz
    iterar_recursivo(trie->raiz, func, contexto);
}

int trie_buscar_por_uf(void *_trie, const char *uf, Acidente **resultado, int max_tam) {
    if (!_trie || !uf || !resultado || max_tam <= 0) {
        return 0;
    }
    
    // Prefixo é apenas a UF
    return trie_buscar_por_prefixo(_trie, uf, resultado, max_tam);
}

// Implementação da Patricia Trie (Trie Comprimida)

void* trie_criar_otimizada() {
    TrieComprimida *trie = (TrieComprimida*)malloc(sizeof(TrieComprimida));
    if (!trie) {
        return NULL;
    }
    
    trie->raiz = criar_no_trie_comprimido();
    if (!trie->raiz) {
        free(trie);
        return NULL;
    }
    
    trie->tamanho = 0;
    trie->profundidade = 0;
    
    return trie;
}

// Função auxiliar para encontrar o maior prefixo comum entre duas strings
static int prefixo_comum(const char *str1, const char *str2) {
    int i = 0;
    while (str1[i] && str2[i] && str1[i] == str2[i]) {
        i++;
    }
    return i;
}

int trie_inserir_otimizada(void *_trie, Acidente *acidente) {
    if (!_trie || !acidente) {
        return 0;
    }
    
    // Cria a chave composta
    char *chave = criar_chave(acidente);
    if (!chave) {
        return 0;
    }
    
    TrieComprimida *trie = (TrieComprimida*)_trie;
    NoTrieComprimido *atual = trie->raiz;
    NoTrieComprimido *pai = NULL;
    int indice_pai = 0;
    int profundidade = 0;
    int pos_chave = 0;
    
    // Percorre a trie até encontrar onde inserir
    while (pos_chave < strlen(chave)) {
        int indice = (unsigned char)chave[pos_chave];
        
        // Verifica se o índice está dentro dos limites do alfabeto
        if (indice >= ALFABETO_TAMANHO) {
            free(chave);
            return 0;
        }
        
        // Se não há filho neste índice, cria um novo nó com o restante da chave
        if (!atual->filhos[indice]) {
            NoTrieComprimido *novo = criar_no_trie_comprimido();
            if (!novo) {
                free(chave);
                return 0;
            }
            
            // Copia o restante da chave para o segmento do novo nó
            int restante = strlen(chave) - pos_chave;
            novo->segmento = (char*)malloc((restante + 1) * sizeof(char));
            if (!novo->segmento) {
                free(novo);
                free(chave);
                return 0;
            }
            
            strncpy(novo->segmento, chave + pos_chave, restante);
            novo->segmento[restante] = '\0';
            
            // Define o nó como fim de palavra e guarda o acidente
            novo->e_fim_palavra = 1;
            novo->acidente = acidente;
            novo->n_acidentes = 1;
            
            // Adiciona o novo nó como filho
            atual->filhos[indice] = novo;
            
            // Atualiza os metadados da trie
            trie->tamanho++;
            profundidade += restante;
            if (profundidade > trie->profundidade) {
                trie->profundidade = profundidade;
            }
            
            free(chave);
            return 1;
        }
        
        // Há um filho, verifica se há um segmento
        NoTrieComprimido *filho = atual->filhos[indice];
        if (!filho->segmento) {
            // Se não há segmento, avança para o próximo nó
            pai = atual;
            indice_pai = indice;
            atual = filho;
            pos_chave++;
            profundidade++;
            continue;
        }
        
        // Há um segmento, verifica o prefixo comum
        int len_segmento = strlen(filho->segmento);
        int len_comum = prefixo_comum(filho->segmento, chave + pos_chave);
        
        if (len_comum == len_segmento) {
            // O segmento é um prefixo da chave restante
            pos_chave += len_comum;
            profundidade += len_comum;
            pai = atual;
            indice_pai = indice;
            atual = filho;
        } else {
            // Precisa dividir o nó
            NoTrieComprimido *novo_intermediario = criar_no_trie_comprimido();
            if (!novo_intermediario) {
                free(chave);
                return 0;
            }
            
            // O novo nó intermediário terá o prefixo comum
            novo_intermediario->segmento = (char*)malloc((len_comum + 1) * sizeof(char));
            if (!novo_intermediario->segmento) {
                free(novo_intermediario);
                free(chave);
                return 0;
            }
            
            strncpy(novo_intermediario->segmento, filho->segmento, len_comum);
            novo_intermediario->segmento[len_comum] = '\0';
            
            // Atualiza o segmento do filho existente
            char *novo_segmento = (char*)malloc((len_segmento - len_comum + 1) * sizeof(char));
            if (!novo_segmento) {
                free(novo_intermediario->segmento);
                free(novo_intermediario);
                free(chave);
                return 0;
            }
            
            strcpy(novo_segmento, filho->segmento + len_comum);
            free(filho->segmento);
            filho->segmento = novo_segmento;
            
            // Adiciona o filho existente como filho do novo nó intermediário
            novo_intermediario->filhos[(unsigned char)filho->segmento[0]] = filho;
            
            // Se ainda há caracteres na chave, cria um novo nó para o restante
            if (pos_chave + len_comum < strlen(chave)) {
                NoTrieComprimido *novo_filho = criar_no_trie_comprimido();
                if (!novo_filho) {
                    free(novo_intermediario->segmento);
                    free(novo_intermediario);
                    free(chave);
                    return 0;
                }
                
                // Copia o restante da chave para o segmento do novo filho
                int restante = strlen(chave) - (pos_chave + len_comum);
                novo_filho->segmento = (char*)malloc((restante + 1) * sizeof(char));
                if (!novo_filho->segmento) {
                    free(novo_filho);
                    free(novo_intermediario->segmento);
                    free(novo_intermediario);
                    free(chave);
                    return 0;
                }
                
                strncpy(novo_filho->segmento, chave + pos_chave + len_comum, restante);
                novo_filho->segmento[restante] = '\0';
                
                // Define o novo filho como fim de palavra e guarda o acidente
                novo_filho->e_fim_palavra = 1;
                novo_filho->acidente = acidente;
                novo_filho->n_acidentes = 1;
                
                // Adiciona o novo filho como filho do nó intermediário
                novo_intermediario->filhos[(unsigned char)novo_filho->segmento[0]] = novo_filho;
            } else {
                // A chave termina exatamente no nó intermediário
                novo_intermediario->e_fim_palavra = 1;
                novo_intermediario->acidente = acidente;
                novo_intermediario->n_acidentes = 1;
            }
            
            // Substitui o filho existente pelo novo nó intermediário
            atual->filhos[indice] = novo_intermediario;
            
            // Atualiza os metadados da trie
            trie->tamanho++;
            profundidade += len_comum;
            if (profundidade > trie->profundidade) {
                trie->profundidade = profundidade;
            }
            
            free(chave);
            return 1;
        }
    }
    
    // Se chegamos aqui, a chave corresponde exatamente a um caminho existente
    if (!atual->e_fim_palavra) {
        atual->e_fim_palavra = 1;
        atual->acidente = acidente;
        atual->n_acidentes++;
        trie->tamanho++;
    } else {
        // O nó já é fim de palavra, substitui o acidente
        atual->acidente = acidente;
    }
    
    free(chave);
    return 1;
}

Acidente* trie_buscar_otimizada(void *_trie, const char *chave) {
    if (!_trie || !chave) {
        return NULL;
    }
    
    TrieComprimida *trie = (TrieComprimida*)_trie;
    NoTrieComprimido *atual = trie->raiz;
    int pos_chave = 0;
    
    // Percorre a trie até encontrar a chave
    while (pos_chave < strlen(chave)) {
        int indice = (unsigned char)chave[pos_chave];
        
        // Verifica se o índice está dentro dos limites do alfabeto
        if (indice >= ALFABETO_TAMANHO) {
            return NULL;
        }
        
        // Se não há filho neste índice, a chave não está na trie
        if (!atual->filhos[indice]) {
            return NULL;
        }
        
        // Avança para o próximo nó
        NoTrieComprimido *filho = atual->filhos[indice];
        
        // Se há um segmento, verifica se corresponde à parte da chave
        if (filho->segmento) {
            int len_segmento = strlen(filho->segmento);
            
            // Verifica se ainda há caracteres suficientes na chave
            if (pos_chave + len_segmento > strlen(chave)) {
                return NULL;
            }
            
            // Verifica se o segmento corresponde à parte da chave
            if (strncmp(filho->segmento, chave + pos_chave, len_segmento) != 0) {
                return NULL;
            }
            
            // Avança a posição na chave
            pos_chave += len_segmento;
        } else {
            // Avança apenas um caractere
            pos_chave++;
        }
        
        atual = filho;
    }
    
    // Verifica se chegamos ao fim de uma palavra
    if (atual->e_fim_palavra) {
        return atual->acidente;
    }
    
    return NULL;  // Não encontrado
}

// Função auxiliar para destruir recursivamente todos os nós da trie comprimida
static void destruir_recursivo_comprimido(NoTrieComprimido *no) {
    if (!no) {
        return;
    }
    
    // Destrói todos os filhos
    for (int i = 0; i < ALFABETO_TAMANHO; i++) {
        if (no->filhos[i]) {
            destruir_recursivo_comprimido(no->filhos[i]);
        }
    }
    
    // Libera o segmento
    if (no->segmento) {
        free(no->segmento);
    }
    
    // Destrói o nó atual
    free(no);
}

void trie_destruir_otimizada(void *_trie) {
    if (!_trie) {
        return;
    }
    
    TrieComprimida *trie = (TrieComprimida*)_trie;
    
    // Destrói recursivamente todos os nós
    destruir_recursivo_comprimido(trie->raiz);
    
    // Destrói a estrutura da trie
    free(trie);
}

int trie_remover_otimizada(void *_trie, const char *chave) {
    if (!_trie || !chave) {
        return 0;
    }
    
    TrieComprimida *trie = (TrieComprimida*)_trie;
    
    // A implementação completa da remoção na Patricia Trie é complexa
    // Uma implementação simplificada pode apenas marcar o nó como não sendo fim de palavra
    
    NoTrieComprimido *atual = trie->raiz;
    int pos_chave = 0;
    
    // Percorre a trie até encontrar a chave
    while (pos_chave < strlen(chave)) {
        int indice = (unsigned char)chave[pos_chave];
        
        // Verifica se o índice está dentro dos limites do alfabeto
        if (indice >= ALFABETO_TAMANHO) {
            return 0;
        }
        
        // Se não há filho neste índice, a chave não está na trie
        if (!atual->filhos[indice]) {
            return 0;
        }
        
        // Avança para o próximo nó
        NoTrieComprimido *filho = atual->filhos[indice];
        
        // Se há um segmento, verifica se corresponde à parte da chave
        if (filho->segmento) {
            int len_segmento = strlen(filho->segmento);
            
            // Verifica se ainda há caracteres suficientes na chave
            if (pos_chave + len_segmento > strlen(chave)) {
                return 0;
            }
            
            // Verifica se o segmento corresponde à parte da chave
            if (strncmp(filho->segmento, chave + pos_chave, len_segmento) != 0) {
                return 0;
            }
            
            // Avança a posição na chave
            pos_chave += len_segmento;
        } else {
            // Avança apenas um caractere
            pos_chave++;
        }
        
        atual = filho;
    }
    
    // Verifica se chegamos ao fim de uma palavra
    if (atual->e_fim_palavra) {
        atual->e_fim_palavra = 0;
        atual->acidente = NULL;
        atual->n_acidentes--;
        trie->tamanho--;
        return 1;
    }
    
    return 0;  // Não encontrado
}
