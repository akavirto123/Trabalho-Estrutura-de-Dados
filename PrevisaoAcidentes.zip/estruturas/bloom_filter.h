/**
 * Implementação de Bloom Filter - Estrutura Adicional Fora da Ementa
 * 
 * Header para a implementação do Bloom Filter que permite verificar
 * rapidamente se um elemento pertence a um conjunto com uso eficiente de memória.
 */

#ifndef BLOOM_FILTER_H
#define BLOOM_FILTER_H

#include <limits.h>

// Estrutura do Bloom Filter
typedef struct {
    char *array;      // Array de bits (representado como chars)
    int tamanho;      // Tamanho do filtro em bits
    int k_hashes;     // Número de funções hash
} BloomFilter;

// Funções principais
BloomFilter *bloom_criar(int tamanho, int k_hashes);
void bloom_destruir(BloomFilter *bf);
void bloom_adicionar(BloomFilter *bf, const char *elemento);
int bloom_verificar(BloomFilter *bf, const char *elemento);

// Funções utilitárias
float bloom_falso_positivo(BloomFilter *bf, int n_elementos);
int bloom_estimar_elementos(BloomFilter *bf);
void bloom_limpar(BloomFilter *bf);
BloomFilter *bloom_combinar(BloomFilter *bf1, BloomFilter *bf2);
float bloom_interseccao(BloomFilter *bf1, BloomFilter *bf2);
BloomFilter *bloom_otimizado(int n_elementos, float p);

#endif // BLOOM_FILTER_H