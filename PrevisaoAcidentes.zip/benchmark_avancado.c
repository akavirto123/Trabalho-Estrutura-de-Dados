/**
 * Benchmark Avançado - Implementação de métricas extras para avaliação
 * 
 * Este módulo implementa benchmark com métricas avançadas:
 * - Complexidade Assintótica Real: compara desempenho real vs. teórico
 * - Impacto do Paralelismo: avalia eficiência em arquiteturas paralelas
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <pthread.h>

#include "utils/tipos.h"
#include "utils/benchmark.h"
#include "estruturas/lista_encadeada.h"
#include "estruturas/arvore_avl.h"
#include "estruturas/tabela_hash.h"
#include "estruturas/skiplist.h"
#include "estruturas/trie.h"
#include "estruturas/bloom_filter.h"

#define MAX_THREADS 8
#define NUM_AMOSTRAS 5
#define NUM_OPERACOES 10000

// Estrutura para armazenar resultados da complexidade real
typedef struct {
    char nome[50];
    double insercao_teorica;    // Complexidade teórica de inserção - O(n), O(log n), etc.
    double busca_teorica;       // Complexidade teórica de busca
    double remocao_teorica;     // Complexidade teórica de remoção
    double insercao_real[10];   // Tempos reais para diferentes tamanhos de entrada
    double busca_real[10];      // Tempos reais para diferentes tamanhos de entrada
    double remocao_real[10];    // Tempos reais para diferentes tamanhos de entrada
    int tamanhos[10];           // Tamanhos de entrada usados
    int n_medidas;              // Número de medidas realizadas
} ComplexidadeReal;

// Estrutura para armazenar resultados do paralelismo
typedef struct {
    char nome[50];
    double tempo_sequencial;        // Tempo com 1 thread
    double tempo_paralelo[MAX_THREADS];  // Tempo com 2, 4, 8... threads
    double speedup[MAX_THREADS];    // Ganho de desempenho
    double eficiencia[MAX_THREADS]; // Eficiência (speedup/threads)
} ResultadoParalelismo;

// Estrutura para passar dados às threads
typedef struct {
    void *estrutura;
    EstruturaDados tipo;
    Acidente *acidentes;
    int n_acidentes;
    int inicio;
    int fim;
    int operacao;  // 0=inserção, 1=busca, 2=remoção
} ThreadData;

// Variáveis globais para resultados
ComplexidadeReal complexidade_resultados[6]; // 5 estruturas + Bloom Filter
ResultadoParalelismo paralelismo_resultados[6]; // 5 estruturas + Bloom Filter
int n_estruturas_testadas = 0;

// Função para realizar medições de complexidade real
void medir_complexidade_real(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    char *nome_estrutura;
    double teorica_insercao, teorica_busca, teorica_remocao;
    
    // Definir complexidades teóricas
    switch (tipo) {
        case LISTA_ENCADEADA:
            nome_estrutura = "Lista Encadeada";
            teorica_insercao = 1.0;  // O(1)
            teorica_busca = 1.0;     // O(n) -> slope = 1
            teorica_remocao = 1.0;   // O(n) -> slope = 1
            break;
        case ARVORE_AVL:
            nome_estrutura = "Árvore AVL";
            teorica_insercao = 0.1;  // O(log n) -> slope ~= 0.1
            teorica_busca = 0.1;     // O(log n) -> slope ~= 0.1
            teorica_remocao = 0.1;   // O(log n) -> slope ~= 0.1
            break;
        case TABELA_HASH:
            nome_estrutura = "Tabela Hash";
            teorica_insercao = 0.0;  // O(1) -> slope ~= 0
            teorica_busca = 0.0;     // O(1) -> slope ~= 0
            teorica_remocao = 0.0;   // O(1) -> slope ~= 0
            break;
        case SKIPLIST:
            nome_estrutura = "SkipList";
            teorica_insercao = 0.1;  // O(log n) -> slope ~= 0.1
            teorica_busca = 0.1;     // O(log n) -> slope ~= 0.1
            teorica_remocao = 0.1;   // O(log n) -> slope ~= 0.1
            break;
        case TRIE:
            nome_estrutura = "Trie";
            teorica_insercao = 0.0;  // O(k) -> constante para tamanho da string
            teorica_busca = 0.0;     // O(k) -> constante para tamanho da string
            teorica_remocao = 0.0;   // O(k) -> constante para tamanho da string
            break;
        case BLOOM_FILTER:
            nome_estrutura = "Bloom Filter";
            teorica_insercao = 0.0;  // O(k) -> constante para número de hashes
            teorica_busca = 0.0;     // O(k) -> constante para número de hashes
            teorica_remocao = 0.0;   // N/A - não suporta remoção
            break;
        default:
            return;
    }
    
    // Inicializar resultado
    int idx = n_estruturas_testadas;
    strcpy(complexidade_resultados[idx].nome, nome_estrutura);
    complexidade_resultados[idx].insercao_teorica = teorica_insercao;
    complexidade_resultados[idx].busca_teorica = teorica_busca;
    complexidade_resultados[idx].remocao_teorica = teorica_remocao;
    complexidade_resultados[idx].n_medidas = 0;
    
    // Testar diferentes tamanhos (potências de 2 para melhor visualização de log n)
    int tamanhos[] = {128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536};
    int n_tamanhos = sizeof(tamanhos) / sizeof(tamanhos[0]);
    if (n_tamanhos > 10) n_tamanhos = 10;  // Limitar a 10 tamanhos
    
    // Para cada tamanho
    for (int i = 0; i < n_tamanhos && tamanhos[i] <= n_acidentes; i++) {
        int tamanho_teste = tamanhos[i];
        complexidade_resultados[idx].tamanhos[i] = tamanho_teste;
        
        // Criar estrutura
        void *estrutura = NULL;
        switch (tipo) {
            case LISTA_ENCADEADA:
                estrutura = lista_criar();
                break;
            case ARVORE_AVL:
                estrutura = avl_criar();
                break;
            case TABELA_HASH:
                estrutura = hash_criar(tamanho_teste);
                break;
            case SKIPLIST:
                estrutura = skiplist_criar();
                break;
            case TRIE:
                estrutura = trie_criar();
                break;
            case BLOOM_FILTER:
                estrutura = bloom_criar(tamanho_teste * 10, 4); // 10 bits por elemento, 4 funções hash
                break;
            default:
                continue;
        }
        
        if (!estrutura) continue;
        
        // Medir tempo de inserção
        clock_t inicio, fim;
        double tempo_total;
        
        // Inserir elementos
        inicio = clock();
        for (int j = 0; j < tamanho_teste; j++) {
            switch (tipo) {
                case LISTA_ENCADEADA:
                    lista_inserir(estrutura, acidentes[j]);
                    break;
                case ARVORE_AVL:
                    avl_inserir(estrutura, acidentes[j]);
                    break;
                case TABELA_HASH:
                    hash_inserir(estrutura, acidentes[j]);
                    break;
                case SKIPLIST:
                    skiplist_inserir(estrutura, acidentes[j]);
                    break;
                case TRIE:
                    trie_inserir(estrutura, acidentes[j].id, j);
                    break;
                case BLOOM_FILTER:
                    bloom_adicionar(estrutura, acidentes[j].id);
                    break;
                default:
                    break;
            }
        }
        fim = clock();
        tempo_total = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        complexidade_resultados[idx].insercao_real[i] = tempo_total / tamanho_teste;
        
        // Medir tempo de busca
        inicio = clock();
        for (int j = 0; j < tamanho_teste; j++) {
            switch (tipo) {
                case LISTA_ENCADEADA:
                    lista_buscar(estrutura, acidentes[j].id);
                    break;
                case ARVORE_AVL:
                    avl_buscar(estrutura, acidentes[j].id);
                    break;
                case TABELA_HASH:
                    hash_buscar(estrutura, acidentes[j].id);
                    break;
                case SKIPLIST:
                    skiplist_buscar(estrutura, acidentes[j].id);
                    break;
                case TRIE:
                    trie_buscar(estrutura, acidentes[j].id);
                    break;
                case BLOOM_FILTER:
                    bloom_verificar(estrutura, acidentes[j].id);
                    break;
                default:
                    break;
            }
        }
        fim = clock();
        tempo_total = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        complexidade_resultados[idx].busca_real[i] = tempo_total / tamanho_teste;
        
        // Medir tempo de remoção (exceto para Bloom Filter)
        if (tipo != BLOOM_FILTER) {
            inicio = clock();
            for (int j = 0; j < tamanho_teste; j++) {
                switch (tipo) {
                    case LISTA_ENCADEADA:
                        lista_remover(estrutura, acidentes[j].id);
                        break;
                    case ARVORE_AVL:
                        avl_remover(estrutura, acidentes[j].id);
                        break;
                    case TABELA_HASH:
                        hash_remover(estrutura, acidentes[j].id);
                        break;
                    case SKIPLIST:
                        skiplist_remover(estrutura, acidentes[j].id);
                        break;
                    case TRIE:
                        trie_remover(estrutura, acidentes[j].id);
                        break;
                    default:
                        break;
                }
            }
            fim = clock();
            tempo_total = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
            complexidade_resultados[idx].remocao_real[i] = tempo_total / tamanho_teste;
        } else {
            complexidade_resultados[idx].remocao_real[i] = 0;
        }
        
        // Liberar estrutura
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_destruir(estrutura);
                break;
            case ARVORE_AVL:
                avl_destruir(estrutura);
                break;
            case TABELA_HASH:
                hash_destruir(estrutura);
                break;
            case SKIPLIST:
                skiplist_destruir(estrutura);
                break;
            case TRIE:
                trie_destruir(estrutura);
                break;
            case BLOOM_FILTER:
                bloom_destruir(estrutura);
                break;
            default:
                break;
        }
        
        complexidade_resultados[idx].n_medidas++;
    }
    
    n_estruturas_testadas++;
}

// Função para thread realizar operações
void *thread_operacoes(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    
    for (int i = data->inicio; i < data->fim; i++) {
        // Executar operação baseado no tipo
        switch (data->operacao) {
            case 0: // Inserção
                switch (data->tipo) {
                    case LISTA_ENCADEADA:
                        lista_inserir(data->estrutura, data->acidentes[i]);
                        break;
                    case ARVORE_AVL:
                        avl_inserir(data->estrutura, data->acidentes[i]);
                        break;
                    case TABELA_HASH:
                        hash_inserir(data->estrutura, data->acidentes[i]);
                        break;
                    case SKIPLIST:
                        skiplist_inserir(data->estrutura, data->acidentes[i]);
                        break;
                    case TRIE:
                        trie_inserir(data->estrutura, data->acidentes[i].id, i);
                        break;
                    case BLOOM_FILTER:
                        bloom_adicionar(data->estrutura, data->acidentes[i].id);
                        break;
                    default:
                        break;
                }
                break;
            case 1: // Busca
                switch (data->tipo) {
                    case LISTA_ENCADEADA:
                        lista_buscar(data->estrutura, data->acidentes[i].id);
                        break;
                    case ARVORE_AVL:
                        avl_buscar(data->estrutura, data->acidentes[i].id);
                        break;
                    case TABELA_HASH:
                        hash_buscar(data->estrutura, data->acidentes[i].id);
                        break;
                    case SKIPLIST:
                        skiplist_buscar(data->estrutura, data->acidentes[i].id);
                        break;
                    case TRIE:
                        trie_buscar(data->estrutura, data->acidentes[i].id);
                        break;
                    case BLOOM_FILTER:
                        bloom_verificar(data->estrutura, data->acidentes[i].id);
                        break;
                    default:
                        break;
                }
                break;
            case 2: // Remoção
                if (data->tipo != BLOOM_FILTER) {
                    switch (data->tipo) {
                        case LISTA_ENCADEADA:
                            lista_remover(data->estrutura, data->acidentes[i].id);
                            break;
                        case ARVORE_AVL:
                            avl_remover(data->estrutura, data->acidentes[i].id);
                            break;
                        case TABELA_HASH:
                            hash_remover(data->estrutura, data->acidentes[i].id);
                            break;
                        case SKIPLIST:
                            skiplist_remover(data->estrutura, data->acidentes[i].id);
                            break;
                        case TRIE:
                            trie_remover(data->estrutura, data->acidentes[i].id);
                            break;
                        default:
                            break;
                    }
                }
                break;
            default:
                break;
        }
    }
    
    return NULL;
}

// Função para medir impacto do paralelismo
void medir_paralelismo(EstruturaDados tipo, Acidente *acidentes, int n_acidentes) {
    char *nome_estrutura;
    
    // Definir nome da estrutura
    switch (tipo) {
        case LISTA_ENCADEADA:
            nome_estrutura = "Lista Encadeada";
            break;
        case ARVORE_AVL:
            nome_estrutura = "Árvore AVL";
            break;
        case TABELA_HASH:
            nome_estrutura = "Tabela Hash";
            break;
        case SKIPLIST:
            nome_estrutura = "SkipList";
            break;
        case TRIE:
            nome_estrutura = "Trie";
            break;
        case BLOOM_FILTER:
            nome_estrutura = "Bloom Filter";
            break;
        default:
            return;
    }
    
    // Inicializar resultado
    int idx = n_estruturas_testadas - 1; // Usar o mesmo índice da última estrutura testada
    strcpy(paralelismo_resultados[idx].nome, nome_estrutura);
    
    // Número de elementos para teste
    int n_elementos = n_acidentes > 10000 ? 10000 : n_acidentes;
    
    // Medir tempo sequencial (1 thread)
    void *estrutura = NULL;
    
    // Criar estrutura
    switch (tipo) {
        case LISTA_ENCADEADA:
            estrutura = lista_criar();
            break;
        case ARVORE_AVL:
            estrutura = avl_criar();
            break;
        case TABELA_HASH:
            estrutura = hash_criar(n_elementos * 2); // Fator de carga 0.5
            break;
        case SKIPLIST:
            estrutura = skiplist_criar();
            break;
        case TRIE:
            estrutura = trie_criar();
            break;
        case BLOOM_FILTER:
            estrutura = bloom_criar(n_elementos * 10, 4); // 10 bits por elemento
            break;
        default:
            return;
    }
    
    if (!estrutura) return;
    
    // Medir inserção sequencial
    clock_t inicio, fim;
    
    inicio = clock();
    for (int i = 0; i < n_elementos; i++) {
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_inserir(estrutura, acidentes[i]);
                break;
            case ARVORE_AVL:
                avl_inserir(estrutura, acidentes[i]);
                break;
            case TABELA_HASH:
                hash_inserir(estrutura, acidentes[i]);
                break;
            case SKIPLIST:
                skiplist_inserir(estrutura, acidentes[i]);
                break;
            case TRIE:
                trie_inserir(estrutura, acidentes[i].id, i);
                break;
            case BLOOM_FILTER:
                bloom_adicionar(estrutura, acidentes[i].id);
                break;
            default:
                break;
        }
    }
    fim = clock();
    paralelismo_resultados[idx].tempo_sequencial = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
    
    // Liberar estrutura
    switch (tipo) {
        case LISTA_ENCADEADA:
            lista_destruir(estrutura);
            break;
        case ARVORE_AVL:
            avl_destruir(estrutura);
            break;
        case TABELA_HASH:
            hash_destruir(estrutura);
            break;
        case SKIPLIST:
            skiplist_destruir(estrutura);
            break;
        case TRIE:
            trie_destruir(estrutura);
            break;
        case BLOOM_FILTER:
            bloom_destruir(estrutura);
            break;
        default:
            break;
    }
    
    // Testar diferentes números de threads (2, 4, 8)
    for (int n_threads = 2; n_threads <= MAX_THREADS; n_threads *= 2) {
        // Criar estrutura
        switch (tipo) {
            case LISTA_ENCADEADA:
                estrutura = lista_criar();
                break;
            case ARVORE_AVL:
                estrutura = avl_criar();
                break;
            case TABELA_HASH:
                estrutura = hash_criar(n_elementos * 2);
                break;
            case SKIPLIST:
                estrutura = skiplist_criar();
                break;
            case TRIE:
                estrutura = trie_criar();
                break;
            case BLOOM_FILTER:
                estrutura = bloom_criar(n_elementos * 10, 4);
                break;
            default:
                continue;
        }
        
        if (!estrutura) continue;
        
        // Preparar threads
        pthread_t threads[MAX_THREADS];
        ThreadData thread_data[MAX_THREADS];
        
        // Divisão de trabalho
        int elementos_por_thread = n_elementos / n_threads;
        
        inicio = clock();
        
        // Criar threads
        for (int t = 0; t < n_threads; t++) {
            thread_data[t].estrutura = estrutura;
            thread_data[t].tipo = tipo;
            thread_data[t].acidentes = acidentes;
            thread_data[t].n_acidentes = n_acidentes;
            thread_data[t].inicio = t * elementos_por_thread;
            thread_data[t].fim = (t == n_threads - 1) ? n_elementos : (t + 1) * elementos_por_thread;
            thread_data[t].operacao = 0; // Inserção
            
            pthread_create(&threads[t], NULL, thread_operacoes, &thread_data[t]);
        }
        
        // Aguardar threads
        for (int t = 0; t < n_threads; t++) {
            pthread_join(threads[t], NULL);
        }
        
        fim = clock();
        
        // Calcular métricas
        double tempo_paralelo = ((double)(fim - inicio)) / CLOCKS_PER_SEC;
        paralelismo_resultados[idx].tempo_paralelo[n_threads/2 - 1] = tempo_paralelo;
        
        // Speedup = tempo sequencial / tempo paralelo
        double speedup = paralelismo_resultados[idx].tempo_sequencial / tempo_paralelo;
        paralelismo_resultados[idx].speedup[n_threads/2 - 1] = speedup;
        
        // Eficiência = speedup / número de threads
        double eficiencia = speedup / n_threads;
        paralelismo_resultados[idx].eficiencia[n_threads/2 - 1] = eficiencia;
        
        // Liberar estrutura
        switch (tipo) {
            case LISTA_ENCADEADA:
                lista_destruir(estrutura);
                break;
            case ARVORE_AVL:
                avl_destruir(estrutura);
                break;
            case TABELA_HASH:
                hash_destruir(estrutura);
                break;
            case SKIPLIST:
                skiplist_destruir(estrutura);
                break;
            case TRIE:
                trie_destruir(estrutura);
                break;
            case BLOOM_FILTER:
                bloom_destruir(estrutura);
                break;
            default:
                break;
        }
    }
}

// Função para calcular a inclinação (slope) dos dados
double calcular_inclinacao(int *x, double *y, int n) {
    double sum_x = 0, sum_y = 0, sum_xy = 0, sum_x2 = 0;
    
    for (int i = 0; i < n; i++) {
        double log_x = log2(x[i]);
        double log_y = log2(y[i]);
        
        sum_x += log_x;
        sum_y += log_y;
        sum_xy += log_x * log_y;
        sum_x2 += log_x * log_x;
    }
    
    return (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x);
}

// Função para exibir resultados da complexidade
void exibir_resultados_complexidade() {
    printf("\n=== RESULTADOS DE COMPLEXIDADE ASSINTÓTICA REAL ===\n");
    
    for (int i = 0; i < n_estruturas_testadas; i++) {
        ComplexidadeReal *resultado = &complexidade_resultados[i];
        
        printf("\nEstrutura: %s\n", resultado->nome);
        
        // Calcular inclinações reais
        double inclinacao_insercao = calcular_inclinacao(resultado->tamanhos, 
                                                        resultado->insercao_real, 
                                                        resultado->n_medidas);
        
        double inclinacao_busca = calcular_inclinacao(resultado->tamanhos, 
                                                     resultado->busca_real, 
                                                     resultado->n_medidas);
        
        double inclinacao_remocao = 0;
        if (strcmp(resultado->nome, "Bloom Filter") != 0) {
            inclinacao_remocao = calcular_inclinacao(resultado->tamanhos, 
                                                    resultado->remocao_real, 
                                                    resultado->n_medidas);
        }
        
        // Determinar complexidade real
        char *complexidade_insercao, *complexidade_busca, *complexidade_remocao;
        
        if (inclinacao_insercao < 0.05) {
            complexidade_insercao = "O(1)";
        } else if (inclinacao_insercao < 0.3) {
            complexidade_insercao = "O(log n)";
        } else if (inclinacao_insercao < 1.2) {
            complexidade_insercao = "O(n)";
        } else if (inclinacao_insercao < 2.2) {
            complexidade_insercao = "O(n²)";
        } else {
            complexidade_insercao = "O(n³) ou superior";
        }
        
        if (inclinacao_busca < 0.05) {
            complexidade_busca = "O(1)";
        } else if (inclinacao_busca < 0.3) {
            complexidade_busca = "O(log n)";
        } else if (inclinacao_busca < 1.2) {
            complexidade_busca = "O(n)";
        } else if (inclinacao_busca < 2.2) {
            complexidade_busca = "O(n²)";
        } else {
            complexidade_busca = "O(n³) ou superior";
        }
        
        if (strcmp(resultado->nome, "Bloom Filter") != 0) {
            if (inclinacao_remocao < 0.05) {
                complexidade_remocao = "O(1)";
            } else if (inclinacao_remocao < 0.3) {
                complexidade_remocao = "O(log n)";
            } else if (inclinacao_remocao < 1.2) {
                complexidade_remocao = "O(n)";
            } else if (inclinacao_remocao < 2.2) {
                complexidade_remocao = "O(n²)";
            } else {
                complexidade_remocao = "O(n³) ou superior";
            }
        } else {
            complexidade_remocao = "N/A";
        }
        
        // Exibir comparação
        printf("Operação  | Complexidade Teórica | Inclinação Real | Complexidade Real\n");
        printf("----------|----------------------|-----------------|------------------\n");
        printf("Inserção  | %20s | %15.3f | %18s\n", 
               resultado->insercao_teorica < 0.05 ? "O(1)" : 
               resultado->insercao_teorica < 0.3 ? "O(log n)" : "O(n)",
               inclinacao_insercao, complexidade_insercao);
        
        printf("Busca     | %20s | %15.3f | %18s\n", 
               resultado->busca_teorica < 0.05 ? "O(1)" : 
               resultado->busca_teorica < 0.3 ? "O(log n)" : "O(n)",
               inclinacao_busca, complexidade_busca);
        
        if (strcmp(resultado->nome, "Bloom Filter") != 0) {
            printf("Remoção   | %20s | %15.3f | %18s\n", 
                   resultado->remocao_teorica < 0.05 ? "O(1)" : 
                   resultado->remocao_teorica < 0.3 ? "O(log n)" : "O(n)",
                   inclinacao_remocao, complexidade_remocao);
        } else {
            printf("Remoção   | %20s | %15s | %18s\n", "N/A", "N/A", "N/A");
        }
    }
}

// Função para exibir resultados do paralelismo
void exibir_resultados_paralelismo() {
    printf("\n=== RESULTADOS DE IMPACTO DO PARALELISMO ===\n");
    
    for (int i = 0; i < n_estruturas_testadas; i++) {
        ResultadoParalelismo *resultado = &paralelismo_resultados[i];
        
        printf("\nEstrutura: %s\n", resultado->nome);
        printf("Tempo Sequencial (1 thread): %.6f segundos\n", resultado->tempo_sequencial);
        
        printf("\nThreads | Tempo Paralelo | Speedup | Eficiência | Escalabilidade\n");
        printf("--------|---------------|---------|------------|---------------\n");
        
        for (int t = 0; t < 3; t++) {
            int n_threads = (t + 1) * 2; // 2, 4, 8 threads
            
            // Classificar escalabilidade
            char *escalabilidade;
            if (resultado->eficiencia[t] > 0.8) {
                escalabilidade = "Excelente";
            } else if (resultado->eficiencia[t] > 0.6) {
                escalabilidade = "Boa";
            } else if (resultado->eficiencia[t] > 0.4) {
                escalabilidade = "Regular";
            } else {
                escalabilidade = "Ruim";
            }
            
            printf("%6d | %13.6f | %7.2f | %10.2f | %s\n", 
                   n_threads, 
                   resultado->tempo_paralelo[t], 
                   resultado->speedup[t], 
                   resultado->eficiencia[t], 
                   escalabilidade);
        }
    }
}

// Função principal de benchmark avançado
void executar_benchmark_avancado(Acidente *acidentes, int n_acidentes) {
    printf("\n=== EXECUTANDO BENCHMARK AVANÇADO ===\n");
    
    // Inicializar semente aleatória com o tempo atual para garantir
    // que cada execução selecione dados diferentes
    srand(time(NULL));
    
    // Inicializar contadores
    n_estruturas_testadas = 0;
    
    // Testar todas as estruturas
    EstruturaDados estruturas[] = {
        LISTA_ENCADEADA,
        ARVORE_AVL,
        TABELA_HASH,
        SKIPLIST,
        TRIE,
        BLOOM_FILTER
    };
    
    int n_estruturas = sizeof(estruturas) / sizeof(estruturas[0]);
    
    // Executar testes
    for (int i = 0; i < n_estruturas; i++) {
        printf("\nTestando %s...\n", 
               estruturas[i] == LISTA_ENCADEADA ? "Lista Encadeada" :
               estruturas[i] == ARVORE_AVL ? "Árvore AVL" :
               estruturas[i] == TABELA_HASH ? "Tabela Hash" :
               estruturas[i] == SKIPLIST ? "SkipList" :
               estruturas[i] == TRIE ? "Trie" : "Bloom Filter");
        
        // Complexidade Assintótica Real
        printf("  Medindo complexidade assintótica real...\n");
        medir_complexidade_real(estruturas[i], acidentes, n_acidentes);
        
        // Impacto do Paralelismo
        printf("  Medindo impacto do paralelismo...\n");
        medir_paralelismo(estruturas[i], acidentes, n_acidentes);
    }
    
    // Exibir resultados
    exibir_resultados_complexidade();
    exibir_resultados_paralelismo();
    
    printf("\n=== FIM DO BENCHMARK AVANÇADO ===\n");
}