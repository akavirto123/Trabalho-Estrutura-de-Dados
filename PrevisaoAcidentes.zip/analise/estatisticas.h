/**
 * estatisticas.h
 * 
 * Funções para análise estatística dos dados de acidentes de trânsito.
 */

#ifndef ESTATISTICAS_H
#define ESTATISTICAS_H

#include "../utils/tipos.h"

/**
 * Calcula estatísticas gerais dos acidentes usando a estrutura de dados especificada.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void calcular_estatisticas(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Gera estatísticas por UF e exibe o resultado.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void estatisticas_por_uf(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Gera estatísticas por rodovia (BR) e exibe o resultado.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void estatisticas_por_rodovia(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Gera estatísticas por tipo de acidente e exibe o resultado.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void estatisticas_por_tipo(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Gera estatísticas por fase do dia e exibe o resultado.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void estatisticas_por_fase_dia(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Gera estatísticas por condição meteorológica e exibe o resultado.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void estatisticas_por_condicao_meteo(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Gera estatísticas temporais (por mês e dia da semana) e exibe o resultado.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void estatisticas_temporais(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Calcula e exibe índices de gravidade dos acidentes.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void indices_gravidade(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Identifica pontos críticos (trechos com maior concentração de acidentes).
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void identificar_pontos_criticos(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Estrutura para armazenar estatísticas básicas
 */
typedef struct {
    int total;               // Total de amostras
    double media;            // Média dos valores
    double mediana;          // Mediana dos valores
    double desvio_padrao;    // Desvio padrão
    double minimo;           // Valor mínimo
    double maximo;           // Valor máximo
    double quartil_1;        // Primeiro quartil (25%)
    double quartil_3;        // Terceiro quartil (75%)
} EstatisticasBasicas;

/**
 * Calcula estatísticas básicas para um conjunto de valores.
 * 
 * @param valores Array de valores
 * @param n_valores Número de valores no array
 * @return Estrutura com as estatísticas calculadas
 */
EstatisticasBasicas calcular_estatisticas_basicas(double *valores, int n_valores);

#endif /* ESTATISTICAS_H */
