/**
 * classificacao.c
 * 
 * Implementação de funções para classificação e agrupamento de acidentes de trânsito.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "classificacao.h"
#include "../estruturas/lista_encadeada.h"
#include "../estruturas/arvore_avl.h"
#include "../estruturas/tabela_hash.h"
#include "../estruturas/skiplist.h"
#include "../estruturas/trie.h"

// Define níveis de gravidade
#define GRAVIDADE_LEVE 0
#define GRAVIDADE_MODERADA 1
#define GRAVIDADE_GRAVE 2
#define GRAVIDADE_FATAL 3

// Estrutura para armazenar um grupo de acidentes similares
typedef struct {
    int id_grupo;
    char descricao[100];
    Acidente **acidentes;
    int n_acidentes;
    int capacidade;
} GrupoAcidentes;

// Estrutura para armazenar padrões de acidentes
typedef struct {
    char uf[3];
    char br[10];
    char tipo_acidente[50];
    char fase_dia[20];
    char condicao_meteo[50];
    int frequencia;
    double indice_gravidade;
} PadraoAcidente;

// Implementação das funções públicas

void classificar_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n=== CLASSIFICAÇÃO DE ACIDENTES ===\n\n");
    
    printf("Utilizando estrutura: ");
    switch (estrutura) {
        case LISTA_ENCADEADA: printf("Lista Encadeada\n"); break;
        case ARVORE_AVL: printf("Árvore AVL\n"); break;
        case TABELA_HASH: printf("Tabela Hash\n"); break;
        case SKIPLIST: printf("Skip List\n"); break;
        case TRIE: printf("Trie\n"); break;
        default: printf("Desconhecida\n"); break;
    }
    
    // Menu de opções para classificações específicas
    int opcao;
    do {
        printf("\nEscolha o tipo de classificação:\n");
        printf("1. Agrupar por Similaridade\n");
        printf("2. Classificar por Gravidade\n");
        printf("3. Identificar Padrões\n");
        printf("4. Analisar Correlações\n");
        printf("0. Voltar ao menu principal\n");
        printf("Opção: ");
        scanf("%d", &opcao);
        
        switch (opcao) {
            case 1:
                agrupar_por_similaridade(estrutura, acidentes, n_acidentes);
                break;
            case 2:
                classificar_por_gravidade(estrutura, acidentes, n_acidentes);
                break;
            case 3:
                identificar_padroes(estrutura, acidentes, n_acidentes);
                break;
            case 4:
                analisar_correlacoes(estrutura, acidentes, n_acidentes);
                break;
            case 0:
                printf("Voltando ao menu principal...\n");
                break;
            default:
                printf("Opção inválida!\n");
                break;
        }
    } while (opcao != 0);
}

// Função auxiliar para calcular a similaridade entre dois acidentes
static double calcular_similaridade(const Acidente *a1, const Acidente *a2) {
    double similaridade = 0.0;
    
    // Similaridade por UF (igual = 1, diferente = 0)
    if (strcmp(a1->local.uf, a2->local.uf) == 0) {
        similaridade += 1.0;
    }
    
    // Similaridade por BR (igual = 1, diferente = 0)
    if (strcmp(a1->local.br, a2->local.br) == 0) {
        similaridade += 1.0;
    }
    
    // Similaridade por tipo de acidente (igual = 1, diferente = 0)
    if (strcmp(a1->condicoes.classificacao, a2->condicoes.classificacao) == 0) {
        similaridade += 1.0;
    }
    
    // Similaridade por fase do dia (igual = 1, diferente = 0)
    if (strcmp(a1->condicoes.fase_dia, a2->condicoes.fase_dia) == 0) {
        similaridade += 1.0;
    }
    
    // Similaridade por condição meteorológica (igual = 1, diferente = 0)
    if (strcmp(a1->condicoes.condicao_meteo, a2->condicoes.condicao_meteo) == 0) {
        similaridade += 1.0;
    }
    
    // Normaliza a similaridade (máximo = 5)
    return similaridade / 5.0;
}

// Implementação da função de agrupamento por similaridade
void agrupar_por_similaridade(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Agrupamento por Similaridade ---\n");
    
    // Limiar de similaridade para considerar acidentes como similares
    const double LIMIAR_SIMILARIDADE = 0.6;
    
    // Define o número máximo de grupos
    const int MAX_GRUPOS = 20;
    
    // Cria grupos de acidentes
    GrupoAcidentes grupos[MAX_GRUPOS];
    int n_grupos = 0;
    
    // Inicializa os grupos
    for (int i = 0; i < MAX_GRUPOS; i++) {
        grupos[i].id_grupo = i;
        grupos[i].n_acidentes = 0;
        grupos[i].capacidade = 100;  // Capacidade inicial
        grupos[i].acidentes = (Acidente**)malloc(grupos[i].capacidade * sizeof(Acidente*));
        sprintf(grupos[i].descricao, "Grupo %d", i + 1);
    }
    
    // Agrupa acidentes
    for (int i = 0; i < n_acidentes; i++) {
        Acidente *atual = &acidentes[i];
        int melhor_grupo = -1;
        double melhor_similaridade = 0.0;
        
        // Verifica os grupos existentes
        for (int g = 0; g < n_grupos; g++) {
            double similaridade_media = 0.0;
            
            // Calcula a similaridade média com os acidentes do grupo
            for (int j = 0; j < grupos[g].n_acidentes; j++) {
                similaridade_media += calcular_similaridade(atual, grupos[g].acidentes[j]);
            }
            
            if (grupos[g].n_acidentes > 0) {
                similaridade_media /= grupos[g].n_acidentes;
            }
            
            // Verifica se é o melhor grupo até agora
            if (similaridade_media > melhor_similaridade) {
                melhor_similaridade = similaridade_media;
                melhor_grupo = g;
            }
        }
        
        // Se não encontrou um grupo similar ou se a similaridade está abaixo do limiar, cria um novo grupo
        if (melhor_grupo == -1 || melhor_similaridade < LIMIAR_SIMILARIDADE) {
            if (n_grupos < MAX_GRUPOS) {
                melhor_grupo = n_grupos++;
                
                // Define a descrição do grupo com base no primeiro acidente
                sprintf(grupos[melhor_grupo].descricao, "Acidentes em %s-%s (%s)", 
                        atual->local.uf, atual->local.br, atual->condicoes.classificacao);
            } else {
                // Se excedeu o número máximo de grupos, usa o grupo mais similar
                melhor_grupo = 0;
                for (int g = 1; g < n_grupos; g++) {
                    double similaridade_media = 0.0;
                    
                    for (int j = 0; j < grupos[g].n_acidentes; j++) {
                        similaridade_media += calcular_similaridade(atual, grupos[g].acidentes[j]);
                    }
                    
                    if (grupos[g].n_acidentes > 0) {
                        similaridade_media /= grupos[g].n_acidentes;
                    }
                    
                    if (similaridade_media > melhor_similaridade) {
                        melhor_similaridade = similaridade_media;
                        melhor_grupo = g;
                    }
                }
            }
        }
        
        // Adiciona o acidente ao grupo
        if (grupos[melhor_grupo].n_acidentes >= grupos[melhor_grupo].capacidade) {
            // Aumenta a capacidade do grupo
            grupos[melhor_grupo].capacidade *= 2;
            grupos[melhor_grupo].acidentes = (Acidente**)realloc(grupos[melhor_grupo].acidentes, 
                                               grupos[melhor_grupo].capacidade * sizeof(Acidente*));
        }
        
        grupos[melhor_grupo].acidentes[grupos[melhor_grupo].n_acidentes++] = atual;
    }
    
    // Exibe os resultados dos grupos
    printf("\nForam encontrados %d grupos de acidentes similares:\n", n_grupos);
    
    for (int g = 0; g < n_grupos; g++) {
        printf("\nGrupo %d: %s\n", g + 1, grupos[g].descricao);
        printf("Número de acidentes: %d\n", grupos[g].n_acidentes);
        
        // Calcula algumas estatísticas do grupo
        int total_feridos = 0;
        int total_mortos = 0;
        int total_veiculos = 0;
        
        for (int i = 0; i < grupos[g].n_acidentes; i++) {
            total_feridos += grupos[g].acidentes[i]->condicoes.feridos;
            total_mortos += grupos[g].acidentes[i]->condicoes.mortos;
            total_veiculos += grupos[g].acidentes[i]->condicoes.veiculos;
        }
        
        printf("Total de feridos: %d (%.2f por acidente)\n", 
               total_feridos, (float)total_feridos / grupos[g].n_acidentes);
        printf("Total de mortos: %d (%.2f por acidente)\n", 
               total_mortos, (float)total_mortos / grupos[g].n_acidentes);
        printf("Total de veículos: %d (%.2f por acidente)\n", 
               total_veiculos, (float)total_veiculos / grupos[g].n_acidentes);
        
        // Mostra alguns exemplos de acidentes do grupo
        printf("Exemplos de acidentes deste grupo:\n");
        int max_exemplos = grupos[g].n_acidentes < 3 ? grupos[g].n_acidentes : 3;
        
        for (int i = 0; i < max_exemplos; i++) {
            printf("  - ID %d: %s em %s-%s, %02d/%02d/%04d, %s\n", 
                   grupos[g].acidentes[i]->id,
                   grupos[g].acidentes[i]->condicoes.classificacao,
                   grupos[g].acidentes[i]->local.uf,
                   grupos[g].acidentes[i]->local.br,
                   grupos[g].acidentes[i]->data.dia,
                   grupos[g].acidentes[i]->data.mes,
                   grupos[g].acidentes[i]->data.ano,
                   grupos[g].acidentes[i]->condicoes.fase_dia);
        }
    }
    
    // Libera a memória alocada para os grupos
    for (int i = 0; i < MAX_GRUPOS; i++) {
        free(grupos[i].acidentes);
    }
}

// Função auxiliar para determinar o nível de gravidade de um acidente
static int determinar_gravidade(const Acidente *acidente) {
    // Determina a gravidade com base no número de feridos e mortos
    if (acidente->condicoes.mortos > 0) {
        return GRAVIDADE_FATAL;
    } else if (acidente->condicoes.feridos > 2) {
        return GRAVIDADE_GRAVE;
    } else if (acidente->condicoes.feridos > 0) {
        return GRAVIDADE_MODERADA;
    } else {
        return GRAVIDADE_LEVE;
    }
}

void classificar_por_gravidade(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Classificação por Gravidade ---\n");
    
    // Contadores para cada nível de gravidade
    int contagem_gravidade[4] = {0, 0, 0, 0};
    
    // Classifica os acidentes e conta
    for (int i = 0; i < n_acidentes; i++) {
        int gravidade = determinar_gravidade(&acidentes[i]);
        contagem_gravidade[gravidade]++;
    }
    
    // Exibe os resultados
    printf("\nDistribuição por nível de gravidade:\n");
    printf("Leve (sem feridos): %d (%.2f%%)\n", 
           contagem_gravidade[GRAVIDADE_LEVE], 
           (float)contagem_gravidade[GRAVIDADE_LEVE] / n_acidentes * 100);
    printf("Moderada (1-2 feridos): %d (%.2f%%)\n", 
           contagem_gravidade[GRAVIDADE_MODERADA], 
           (float)contagem_gravidade[GRAVIDADE_MODERADA] / n_acidentes * 100);
    printf("Grave (3+ feridos): %d (%.2f%%)\n", 
           contagem_gravidade[GRAVIDADE_GRAVE], 
           (float)contagem_gravidade[GRAVIDADE_GRAVE] / n_acidentes * 100);
    printf("Fatal (com óbitos): %d (%.2f%%)\n", 
           contagem_gravidade[GRAVIDADE_FATAL], 
           (float)contagem_gravidade[GRAVIDADE_FATAL] / n_acidentes * 100);
    
    // Análise adicional por tipo de acidente e gravidade
    printf("\nDistribuição de gravidade por tipo de acidente:\n");
    
    // Armazena tipos únicos de acidentes
    char tipos[100][50];
    int n_tipos = 0;
    
    // Identifica tipos únicos
    for (int i = 0; i < n_acidentes; i++) {
        int tipo_existe = 0;
        for (int j = 0; j < n_tipos; j++) {
            if (strcmp(tipos[j], acidentes[i].condicoes.classificacao) == 0) {
                tipo_existe = 1;
                break;
            }
        }
        
        if (!tipo_existe && n_tipos < 100) {
            strcpy(tipos[n_tipos], acidentes[i].condicoes.classificacao);
            n_tipos++;
        }
    }
    
    // Conta a gravidade para cada tipo
    for (int t = 0; t < n_tipos; t++) {
        int contagem_tipo[4] = {0, 0, 0, 0};
        int total_tipo = 0;
        
        for (int i = 0; i < n_acidentes; i++) {
            if (strcmp(tipos[t], acidentes[i].condicoes.classificacao) == 0) {
                int gravidade = determinar_gravidade(&acidentes[i]);
                contagem_tipo[gravidade]++;
                total_tipo++;
            }
        }
        
        if (total_tipo > 0) {
            printf("\nTipo: %s (Total: %d)\n", tipos[t], total_tipo);
            printf("  Leve: %.1f%%, Moderada: %.1f%%, Grave: %.1f%%, Fatal: %.1f%%\n",
                   (float)contagem_tipo[GRAVIDADE_LEVE] / total_tipo * 100,
                   (float)contagem_tipo[GRAVIDADE_MODERADA] / total_tipo * 100,
                   (float)contagem_tipo[GRAVIDADE_GRAVE] / total_tipo * 100,
                   (float)contagem_tipo[GRAVIDADE_FATAL] / total_tipo * 100);
        }
    }
}

void identificar_padroes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Identificação de Padrões de Acidentes ---\n");
    
    // Número máximo de padrões a identificar
    const int MAX_PADROES = 100;
    
    // Array para armazenar os padrões
    PadraoAcidente padroes[MAX_PADROES];
    int n_padroes = 0;
    
    // Inicializa o array de padrões
    memset(padroes, 0, sizeof(padroes));
    
    // Analisa cada acidente
    for (int i = 0; i < n_acidentes; i++) {
        Acidente *atual = &acidentes[i];
        
        // Verifica se este padrão já existe
        int padrao_idx = -1;
        for (int j = 0; j < n_padroes; j++) {
            if (strcmp(padroes[j].uf, atual->local.uf) == 0 &&
                strcmp(padroes[j].br, atual->local.br) == 0 &&
                strcmp(padroes[j].tipo_acidente, atual->condicoes.classificacao) == 0 &&
                strcmp(padroes[j].fase_dia, atual->condicoes.fase_dia) == 0 &&
                strcmp(padroes[j].condicao_meteo, atual->condicoes.condicao_meteo) == 0) {
                padrao_idx = j;
                break;
            }
        }
        
        // Se não existe, cria um novo padrão (se houver espaço)
        if (padrao_idx == -1) {
            if (n_padroes < MAX_PADROES) {
                padrao_idx = n_padroes++;
                strcpy(padroes[padrao_idx].uf, atual->local.uf);
                strcpy(padroes[padrao_idx].br, atual->local.br);
                strcpy(padroes[padrao_idx].tipo_acidente, atual->condicoes.classificacao);
                strcpy(padroes[padrao_idx].fase_dia, atual->condicoes.fase_dia);
                strcpy(padroes[padrao_idx].condicao_meteo, atual->condicoes.condicao_meteo);
                padroes[padrao_idx].frequencia = 0;
                padroes[padrao_idx].indice_gravidade = 0.0;
            } else {
                continue;  // Se excedeu o número máximo de padrões, ignora
            }
        }
        
        // Incrementa a frequência e atualiza o índice de gravidade
        padroes[padrao_idx].frequencia++;
        padroes[padrao_idx].indice_gravidade += atual->condicoes.feridos + 5 * atual->condicoes.mortos;
    }
    
    // Calcula o índice de gravidade médio para cada padrão
    for (int i = 0; i < n_padroes; i++) {
        if (padroes[i].frequencia > 0) {
            padroes[i].indice_gravidade /= padroes[i].frequencia;
        }
    }
    
    // Ordena os padrões por frequência (decrescente)
    for (int i = 0; i < n_padroes - 1; i++) {
        for (int j = i + 1; j < n_padroes; j++) {
            if (padroes[j].frequencia > padroes[i].frequencia) {
                PadraoAcidente temp = padroes[i];
                padroes[i] = padroes[j];
                padroes[j] = temp;
            }
        }
    }
    
    // Exibe os padrões mais frequentes
    printf("\nPadrões de acidentes mais frequentes:\n");
    
    int limit = n_padroes > 10 ? 10 : n_padroes;
    for (int i = 0; i < limit; i++) {
        printf("\n%d. Padrão #%d (Frequência: %d)\n", i + 1, i + 1, padroes[i].frequencia);
        printf("   Local: %s-%s\n", padroes[i].uf, padroes[i].br);
        printf("   Tipo: %s\n", padroes[i].tipo_acidente);
        printf("   Fase do dia: %s\n", padroes[i].fase_dia);
        printf("   Condição meteorológica: %s\n", padroes[i].condicao_meteo);
        printf("   Índice de gravidade: %.2f\n", padroes[i].indice_gravidade);
        
        // Calcula o percentual deste padrão no total de acidentes
        float percentual = (float)padroes[i].frequencia / n_acidentes * 100.0;
        printf("   Representa %.2f%% dos acidentes analisados\n", percentual);
    }
}

void analisar_correlacoes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Análise de Correlações entre Fatores ---\n");
    
    // Correlação entre fase do dia e gravidade
    printf("\nCorrelação entre Fase do Dia e Gravidade:\n");
    
    // Armazena fases únicas do dia
    char fases[10][20];
    int n_fases = 0;
    
    // Identifica fases únicas
    for (int i = 0; i < n_acidentes; i++) {
        int fase_existe = 0;
        for (int j = 0; j < n_fases; j++) {
            if (strcmp(fases[j], acidentes[i].condicoes.fase_dia) == 0) {
                fase_existe = 1;
                break;
            }
        }
        
        if (!fase_existe && n_fases < 10 && acidentes[i].condicoes.fase_dia[0] != '\0') {
            strcpy(fases[n_fases], acidentes[i].condicoes.fase_dia);
            n_fases++;
        }
    }
    
    // Analisa cada fase do dia
    for (int f = 0; f < n_fases; f++) {
        int total_acidentes = 0;
        int total_feridos = 0;
        int total_mortos = 0;
        int acidentes_por_gravidade[4] = {0, 0, 0, 0};
        
        for (int i = 0; i < n_acidentes; i++) {
            if (strcmp(fases[f], acidentes[i].condicoes.fase_dia) == 0) {
                total_acidentes++;
                total_feridos += acidentes[i].condicoes.feridos;
                total_mortos += acidentes[i].condicoes.mortos;
                
                int gravidade = determinar_gravidade(&acidentes[i]);
                acidentes_por_gravidade[gravidade]++;
            }
        }
        
        if (total_acidentes > 0) {
            printf("\nFase: %s (Total: %d acidentes)\n", fases[f], total_acidentes);
            printf("  Média de feridos: %.2f por acidente\n", (float)total_feridos / total_acidentes);
            printf("  Média de mortos: %.2f por acidente\n", (float)total_mortos / total_acidentes);
            printf("  Distribuição de gravidade:\n");
            printf("    Leve: %.1f%%, Moderada: %.1f%%, Grave: %.1f%%, Fatal: %.1f%%\n",
                   (float)acidentes_por_gravidade[GRAVIDADE_LEVE] / total_acidentes * 100,
                   (float)acidentes_por_gravidade[GRAVIDADE_MODERADA] / total_acidentes * 100,
                   (float)acidentes_por_gravidade[GRAVIDADE_GRAVE] / total_acidentes * 100,
                   (float)acidentes_por_gravidade[GRAVIDADE_FATAL] / total_acidentes * 100);
        }
    }
    
    // Correlação entre condição meteorológica e gravidade
    printf("\nCorrelação entre Condição Meteorológica e Gravidade:\n");
    
    // Armazena condições meteorológicas únicas
    char condicoes[10][50];
    int n_condicoes = 0;
    
    // Identifica condições únicas
    for (int i = 0; i < n_acidentes; i++) {
        int condicao_existe = 0;
        for (int j = 0; j < n_condicoes; j++) {
            if (strcmp(condicoes[j], acidentes[i].condicoes.condicao_meteo) == 0) {
                condicao_existe = 1;
                break;
            }
        }
        
        if (!condicao_existe && n_condicoes < 10 && acidentes[i].condicoes.condicao_meteo[0] != '\0') {
            strcpy(condicoes[n_condicoes], acidentes[i].condicoes.condicao_meteo);
            n_condicoes++;
        }
    }
    
    // Analisa cada condição meteorológica
    for (int c = 0; c < n_condicoes; c++) {
        int total_acidentes = 0;
        int total_feridos = 0;
        int total_mortos = 0;
        int acidentes_por_gravidade[4] = {0, 0, 0, 0};
        
        for (int i = 0; i < n_acidentes; i++) {
            if (strcmp(condicoes[c], acidentes[i].condicoes.condicao_meteo) == 0) {
                total_acidentes++;
                total_feridos += acidentes[i].condicoes.feridos;
                total_mortos += acidentes[i].condicoes.mortos;
                
                int gravidade = determinar_gravidade(&acidentes[i]);
                acidentes_por_gravidade[gravidade]++;
            }
        }
        
        if (total_acidentes > 0) {
            printf("\nCondição: %s (Total: %d acidentes)\n", condicoes[c], total_acidentes);
            printf("  Média de feridos: %.2f por acidente\n", (float)total_feridos / total_acidentes);
            printf("  Média de mortos: %.2f por acidente\n", (float)total_mortos / total_acidentes);
            printf("  Distribuição de gravidade:\n");
            printf("    Leve: %.1f%%, Moderada: %.1f%%, Grave: %.1f%%, Fatal: %.1f%%\n",
                   (float)acidentes_por_gravidade[GRAVIDADE_LEVE] / total_acidentes * 100,
                   (float)acidentes_por_gravidade[GRAVIDADE_MODERADA] / total_acidentes * 100,
                   (float)acidentes_por_gravidade[GRAVIDADE_GRAVE] / total_acidentes * 100,
                   (float)acidentes_por_gravidade[GRAVIDADE_FATAL] / total_acidentes * 100);
        }
    }
    
    // Análise de correlação entre tipo de acidente e UF
    printf("\nCorrelação entre Tipo de Acidente e UF (Top 5 combinações):\n");
    
    // Mapa para contar combinações de tipo e UF
    typedef struct {
        char tipo[50];
        char uf[3];
        int contagem;
    } TipoUF;
    
    TipoUF tipo_uf[100];
    int n_tipo_uf = 0;
    
    // Conta as combinações de tipo e UF
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se esta combinação já existe
        int idx = -1;
        for (int j = 0; j < n_tipo_uf; j++) {
            if (strcmp(tipo_uf[j].tipo, acidentes[i].condicoes.classificacao) == 0 &&
                strcmp(tipo_uf[j].uf, acidentes[i].local.uf) == 0) {
                idx = j;
                break;
            }
        }
        
        // Se não existe, cria uma nova (se houver espaço)
        if (idx == -1) {
            if (n_tipo_uf < 100) {
                idx = n_tipo_uf++;
                strcpy(tipo_uf[idx].tipo, acidentes[i].condicoes.classificacao);
                strcpy(tipo_uf[idx].uf, acidentes[i].local.uf);
                tipo_uf[idx].contagem = 0;
            } else {
                continue;  // Se excedeu o número máximo, ignora
            }
        }
        
        // Incrementa a contagem
        tipo_uf[idx].contagem++;
    }
    
    // Ordena as combinações por contagem (decrescente)
    for (int i = 0; i < n_tipo_uf - 1; i++) {
        for (int j = i + 1; j < n_tipo_uf; j++) {
            if (tipo_uf[j].contagem > tipo_uf[i].contagem) {
                TipoUF temp = tipo_uf[i];
                tipo_uf[i] = tipo_uf[j];
                tipo_uf[j] = temp;
            }
        }
    }
    
    // Exibe as 5 combinações mais frequentes
    int limit = n_tipo_uf > 5 ? 5 : n_tipo_uf;
    for (int i = 0; i < limit; i++) {
        float percentual = (float)tipo_uf[i].contagem / n_acidentes * 100.0;
        printf("%d. %s em %s: %d acidentes (%.2f%%)\n", 
               i + 1, tipo_uf[i].tipo, tipo_uf[i].uf, tipo_uf[i].contagem, percentual);
    }
}