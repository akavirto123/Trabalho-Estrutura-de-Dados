/**
 * previsao.c
 * 
 * Implementação de funções para previsão de tendências de acidentes de trânsito.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>  // Necessário para floor()
#include <time.h>  // Necessário para srand e time
#include "previsao.h"

// Variável global para controlar o modo de simulação mês a mês
static int simulacao_mes_a_mes = 0;
#include "../estruturas/lista_encadeada.h"
#include "../estruturas/arvore_avl.h"
#include "../estruturas/tabela_hash.h"
#include "../estruturas/skiplist.h"
#include "../estruturas/trie.h"

// Estrutura para armazenar dados temporais para análise
typedef struct {
    int periodo;       // Mês, dia, etc.
    int ano;           // Ano
    int acidentes;     // Número de acidentes
    int feridos;       // Número de feridos
    int mortos;        // Número de mortos
} DadoTemporal;

// Implementação das funções públicas

void prever_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n=== PREVISÃO DE TENDÊNCIAS DE ACIDENTES ===\n\n");
    
    printf("Utilizando estrutura: ");
    switch (estrutura) {
        case LISTA_ENCADEADA: printf("Lista Encadeada\n"); break;
        case ARVORE_AVL: printf("Árvore AVL\n"); break;
        case TABELA_HASH: printf("Tabela Hash\n"); break;
        case SKIPLIST: printf("Skip List\n"); break;
        case TRIE: printf("Trie\n"); break;
        default: printf("Desconhecida\n"); break;
    }
    
    // Menu de opções para previsões específicas
    int opcao;
    do {
        printf("\nEscolha o tipo de previsão:\n");
        printf("1. Previsão de Quantidade de Acidentes\n");
        printf("2. Previsão de Distribuição por UF\n");
        printf("3. Previsão de Distribuição por Rodovia\n");
        printf("4. Previsão de Gravidade\n");
        printf("5. Tendências Temporais\n");
        printf("6. Simulação de Impacto de Melhorias\n");
        printf("0. Voltar ao menu principal\n");
        printf("Opção: ");
        scanf("%d", &opcao);
        
        switch (opcao) {
            case 1:
                prever_quantidade_acidentes(estrutura, acidentes, n_acidentes);
                break;
            case 2:
                prever_distribuicao_por_uf(estrutura, acidentes, n_acidentes);
                break;
            case 3:
                prever_distribuicao_por_rodovia(estrutura, acidentes, n_acidentes);
                break;
            case 4:
                prever_gravidade_acidentes(estrutura, acidentes, n_acidentes);
                break;
            case 5:
                identificar_tendencias_temporais(estrutura, acidentes, n_acidentes);
                break;
            case 6:
                simular_impacto_melhorias(estrutura, acidentes, n_acidentes);
                break;
            case 0:
                printf("Voltando ao menu principal...\n");
                break;
            default:
                printf("Opção inválida!\n");
                break;
        }
    } while (opcao != 0);
}

// Função auxiliar para agrupar acidentes por período (mês)
static void agrupar_por_mes(Acidente *acidentes, int n_acidentes, DadoTemporal *dados, int *n_periodos) {
    // Inicializa o contador de períodos
    *n_periodos = 0;
    
    // Agrupa os acidentes por mês e ano
    for (int i = 0; i < n_acidentes; i++) {
        Acidente *atual = &acidentes[i];
        
        // Cria um identificador único para o mês/ano
        int mes = atual->data.mes;
        int ano = atual->data.ano;
        
        // Verifica se este período já existe nos dados
        int idx = -1;
        for (int j = 0; j < *n_periodos; j++) {
            if (dados[j].periodo == mes && dados[j].ano == ano) {
                idx = j;
                break;
            }
        }
        
        // Se não existe, cria um novo período
        if (idx == -1) {
            idx = (*n_periodos)++;
            dados[idx].periodo = mes;
            dados[idx].ano = ano;
            dados[idx].acidentes = 0;
            dados[idx].feridos = 0;
            dados[idx].mortos = 0;
        }
        
        // Incrementa as contagens para este período
        dados[idx].acidentes++;
        dados[idx].feridos += atual->condicoes.feridos;
        dados[idx].mortos += atual->condicoes.mortos;
    }
    
    // Ordena os dados por ano e mês
    for (int i = 0; i < *n_periodos - 1; i++) {
        for (int j = i + 1; j < *n_periodos; j++) {
            if (dados[j].ano < dados[i].ano || 
                (dados[j].ano == dados[i].ano && dados[j].periodo < dados[i].periodo)) {
                DadoTemporal temp = dados[i];
                dados[i] = dados[j];
                dados[j] = temp;
            }
        }
    }
}

void regressao_linear(const double *x, const double *y, int n, double *a, double *b, double *r2) {
    if (n <= 1) {
        *a = 0;
        *b = 0;
        *r2 = 0;
        return;
    }
    
    // Calcula médias
    double soma_x = 0.0, soma_y = 0.0, soma_xy = 0.0, soma_x2 = 0.0, soma_y2 = 0.0;
    
    for (int i = 0; i < n; i++) {
        soma_x += x[i];
        soma_y += y[i];
        soma_xy += x[i] * y[i];
        soma_x2 += x[i] * x[i];
        soma_y2 += y[i] * y[i];
    }
    
    double media_x = soma_x / n;
    double media_y = soma_y / n;
    
    // Calcula coeficientes da regressão linear
    double numerador = soma_xy - n * media_x * media_y;
    double denominador = soma_x2 - n * media_x * media_x;
    
    if (fabs(denominador) < 1e-10) {
        // Evita divisão por zero
        *a = 0;
        *b = media_y;
        *r2 = 0;
        return;
    }
    
    *b = numerador / denominador;  // Inclinação
    *a = media_y - (*b) * media_x; // Intercepto
    
    // Calcula coeficiente de determinação (R²)
    double ss_total = 0.0, ss_residual = 0.0;
    
    for (int i = 0; i < n; i++) {
        double pred = (*a) + (*b) * x[i];
        ss_total += (y[i] - media_y) * (y[i] - media_y);
        ss_residual += (y[i] - pred) * (y[i] - pred);
    }
    
    if (fabs(ss_total) < 1e-10) {
        *r2 = 0;
    } else {
        *r2 = 1.0 - (ss_residual / ss_total);
    }
}

void media_movel(const double *y, int n, int janela, double *previsoes, int n_previsoes) {
    if (n <= 0 || janela <= 0 || n_previsoes <= 0) {
        return;
    }
    
    // Se a janela for maior que o número de pontos, ajusta a janela
    if (janela > n) {
        janela = n;
    }
    
    // Calcula as médias móveis
    for (int i = 0; i < n_previsoes; i++) {
        double soma = 0.0;
        int cont = 0;
        
        // Usa os últimos 'janela' pontos para a previsão
        for (int j = n - janela; j < n; j++) {
            soma += y[j];
            cont++;
        }
        
        // A previsão é a média dos pontos na janela
        previsoes[i] = soma / cont;
    }
}

void modelo_sazonal(const double *y, int n, int periodo, double *previsoes, int n_previsoes) {
    if (n <= 0 || periodo <= 0 || n_previsoes <= 0) {
        return;
    }
    
    // Se não há dados suficientes para um período completo, usa média simples
    if (n < periodo) {
        double soma = 0.0;
        for (int i = 0; i < n; i++) {
            soma += y[i];
        }
        double media = soma / n;
        
        for (int i = 0; i < n_previsoes; i++) {
            previsoes[i] = media;
        }
        return;
    }
    
    // Calcula fatores sazonais
    double fatores_sazonais[periodo];
    memset(fatores_sazonais, 0, periodo * sizeof(double));
    
    int ciclos_completos = n / periodo;
    
    // Calcula a média global
    double soma_total = 0.0;
    for (int i = 0; i < n; i++) {
        soma_total += y[i];
    }
    double media_global = soma_total / n;
    
    // Calcula os fatores sazonais (média de cada posição no ciclo / média global)
    for (int p = 0; p < periodo; p++) {
        double soma = 0.0;
        int cont = 0;
        
        for (int c = 0; c < ciclos_completos; c++) {
            int idx = c * periodo + p;
            if (idx < n) {
                soma += y[idx];
                cont++;
            }
        }
        
        if (cont > 0 && fabs(media_global) > 1e-10) {
            fatores_sazonais[p] = (soma / cont) / media_global;
        } else {
            fatores_sazonais[p] = 1.0;
        }
    }
    
    // Gera previsões usando os fatores sazonais
    for (int i = 0; i < n_previsoes; i++) {
        int pos_ciclo = (n + i) % periodo;
        previsoes[i] = media_global * fatores_sazonais[pos_ciclo];
    }
}

// Função para calcular métricas de erro
void calcular_metricas_erro(const double *reais, const double *previstos, int n, 
                           double *mae, double *rmse, double *smape) {
    double soma_erros = 0.0;
    double soma_erros_quadrados = 0.0;
    double soma_smape = 0.0;
    
    for (int i = 0; i < n; i++) {
        double erro = fabs(reais[i] - previstos[i]);
        soma_erros += erro;
        soma_erros_quadrados += erro * erro;
        
        // SMAPE (Symmetric Mean Absolute Percentage Error)
        if (fabs(reais[i]) + fabs(previstos[i]) > 0) {
            soma_smape += 200.0 * erro / (fabs(reais[i]) + fabs(previstos[i]));
        }
    }
    
    *mae = soma_erros / n;                     // Mean Absolute Error
    *rmse = sqrt(soma_erros_quadrados / n);    // Root Mean Squared Error
    *smape = soma_smape / n;                   // Symmetric Mean Absolute Percentage Error
}

void prever_quantidade_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Previsão de Quantidade de Acidentes ---\n");
    
    // Número máximo de períodos (meses) a analisar
    const int MAX_PERIODOS = 100;
    
    // Array para armazenar os dados temporais
    DadoTemporal dados[MAX_PERIODOS];
    int n_periodos = 0;
    
    // Agrupa os acidentes por mês
    agrupar_por_mes(acidentes, n_acidentes, dados, &n_periodos);
    
    // Verifica se há dados suficientes
    if (n_periodos < 3) {
        printf("Não há dados suficientes para realizar previsões confiáveis.\n");
        return;
    }
    
    // Exibe os dados agrupados por mês
    printf("\nDados históricos por mês:\n");
    printf("%-5s | %-10s | %-10s | %-10s | %-10s\n",
           "Mês", "Ano", "Acidentes", "Feridos", "Mortos");
    printf("------+------------+------------+------------+------------\n");
    
    for (int i = 0; i < n_periodos; i++) {
        printf("%-5d | %-10d | %-10d | %-10d | %-10d\n",
               dados[i].periodo, dados[i].ano, 
               dados[i].acidentes, dados[i].feridos, dados[i].mortos);
    }
    
    // Prepara os dados para regressão linear
    double x[MAX_PERIODOS], y_acidentes[MAX_PERIODOS];
    double y_feridos[MAX_PERIODOS], y_mortos[MAX_PERIODOS];
    
    for (int i = 0; i < n_periodos; i++) {
        // Converte o período para uma escala contínua (mês + ano*12)
        x[i] = dados[i].ano * 12.0 + dados[i].periodo;
        y_acidentes[i] = dados[i].acidentes;
        y_feridos[i] = dados[i].feridos;
        y_mortos[i] = dados[i].mortos;
    }
    
    // Realiza regressão linear para acidentes
    double a, b, r2;
    regressao_linear(x, y_acidentes, n_periodos, &a, &b, &r2);
    
    printf("\nModelo de Regressão Linear para Acidentes:\n");
    printf("Equação: Acidentes = %.2f + %.2f * Período\n", a, b);
    printf("Coeficiente de determinação (R²): %.4f\n", r2);
    
    // Calcular métricas de erro com validação cruzada
    // Usando os últimos 2 meses como teste
    int n_treino = n_periodos - 2;
    if (n_treino >= 3) {  // Precisamos de pelo menos 3 pontos para treinar
        double a_validacao, b_validacao, r2_validacao;
        regressao_linear(x, y_acidentes, n_treino, &a_validacao, &b_validacao, &r2_validacao);
        
        double previstos[2];
        double reais[2] = {y_acidentes[n_treino], y_acidentes[n_treino + 1]};
        
        previstos[0] = a_validacao + b_validacao * x[n_treino];
        previstos[1] = a_validacao + b_validacao * x[n_treino + 1];
        
        double mae, rmse, smape;
        calcular_metricas_erro(reais, previstos, 2, &mae, &rmse, &smape);
        
        printf("\nMétricas de erro (validação nos últimos 2 meses):\n");
        printf("MAE (Erro Médio Absoluto): %.2f\n", mae);
        printf("RMSE (Raiz do Erro Quadrático Médio): %.2f\n", rmse);
        printf("SMAPE (Erro Percentual Absoluto Simétrico Médio): %.2f%%\n", smape);
    }
    
    // Realiza previsões para os próximos 3 meses
    const int N_PREVISOES = 3;
    double ultimo_periodo = x[n_periodos - 1];
    
    printf("\nPrevisões para os próximos %d meses usando Regressão Linear:\n", N_PREVISOES);
    printf("%-5s | %-10s | %-15s | %-15s | %-15s | %-15s\n",
           "Mês", "Ano", "Acidentes", "Feridos", "Mortos", "Método");
    printf("------+------------+-----------------+-----------------+----------------+----------------\n");
    
    double previsoes_acidentes_rl[N_PREVISOES];
    double previsoes_feridos_rl[N_PREVISOES];
    double previsoes_mortos_rl[N_PREVISOES];
    int meses_previsao[N_PREVISOES];
    int anos_previsao[N_PREVISOES];
    
    // Calcula médias para previsão proporcional
    double media_feridos_por_acidente = 0.0, media_mortos_por_acidente = 0.0;
    double soma_feridos = 0.0, soma_mortos = 0.0, soma_acidentes = 0.0;
    
    for (int j = 0; j < n_periodos; j++) {
        soma_feridos += dados[j].feridos;
        soma_mortos += dados[j].mortos;
        soma_acidentes += dados[j].acidentes;
    }
    
    if (soma_acidentes > 0) {
        media_feridos_por_acidente = soma_feridos / soma_acidentes;
        media_mortos_por_acidente = soma_mortos / soma_acidentes;
    }
    
    for (int i = 1; i <= N_PREVISOES; i++) {
        double periodo = ultimo_periodo + i;
        int mes = (int)periodo % 12;
        if (mes == 0) mes = 12;  // Converte 0 para 12 (dezembro)
        int ano = (int)periodo / 12;
        
        meses_previsao[i-1] = mes;
        anos_previsao[i-1] = ano;
        
        // Prevê acidentes usando regressão linear
        double previsao_acidentes = a + b * periodo;
        double previsao_feridos = previsao_acidentes * media_feridos_por_acidente;
        double previsao_mortos = previsao_acidentes * media_mortos_por_acidente;
        
        previsoes_acidentes_rl[i-1] = previsao_acidentes;
        previsoes_feridos_rl[i-1] = previsao_feridos;
        previsoes_mortos_rl[i-1] = previsao_mortos;
        
        printf("%-5d | %-10d | %-15.2f | %-15.2f | %-15.2f | %-15s\n",
               mes, ano, previsao_acidentes, previsao_feridos, previsao_mortos, "Regressão Linear");
    }
    
    // Usa modelo de média móvel para comparação
    const int JANELA = 3;  // Janela de 3 meses
    double previsoes_mm[N_PREVISOES];
    media_movel(y_acidentes, n_periodos, JANELA, previsoes_mm, N_PREVISOES);
    
    printf("\nPrevisões usando Média Móvel (janela de %d meses):\n", JANELA);
    printf("%-5s | %-10s | %-15s | %-15s | %-15s | %-15s\n",
           "Mês", "Ano", "Acidentes", "Feridos", "Mortos", "Método");
    printf("------+------------+-----------------+-----------------+----------------+----------------\n");
    
    for (int i = 0; i < N_PREVISOES; i++) {
        double previsao_feridos = previsoes_mm[i] * media_feridos_por_acidente;
        double previsao_mortos = previsoes_mm[i] * media_mortos_por_acidente;
        
        printf("%-5d | %-10d | %-15.2f | %-15.2f | %-15.2f | %-15s\n",
               meses_previsao[i], anos_previsao[i], 
               previsoes_mm[i], previsao_feridos, previsao_mortos, "Média Móvel");
    }
    
    // Usa modelo sazonal se houver dados suficientes
    if (n_periodos >= 12) {
        const int PERIODO_ANUAL = 12;
        double previsoes_sazonais[N_PREVISOES];
        modelo_sazonal(y_acidentes, n_periodos, PERIODO_ANUAL, previsoes_sazonais, N_PREVISOES);
        
        printf("\nPrevisões usando Modelo Sazonal (período anual):\n");
        printf("%-5s | %-10s | %-15s | %-15s | %-15s | %-15s\n",
               "Mês", "Ano", "Acidentes", "Feridos", "Mortos", "Método");
        printf("------+------------+-----------------+-----------------+----------------+----------------\n");
        
        for (int i = 0; i < N_PREVISOES; i++) {
            double previsao_feridos = previsoes_sazonais[i] * media_feridos_por_acidente;
            double previsao_mortos = previsoes_sazonais[i] * media_mortos_por_acidente;
            
            printf("%-5d | %-10d | %-15.2f | %-15.2f | %-15.2f | %-15s\n",
                   meses_previsao[i], anos_previsao[i], 
                   previsoes_sazonais[i], previsao_feridos, previsao_mortos, "Modelo Sazonal");
        }
    }
    
    // Simular cenário com intervenção
    printf("\n=== Simulação de Cenários com Intervenção ===\n");
    printf("Escolha o tipo de intervenção a simular:\n");
    printf("1. Redução de 10%% nos acidentes por melhorias na sinalização\n");
    printf("2. Redução de 20%% na gravidade por campanhas educativas\n");
    printf("3. Redução de 30%% nos acidentes noturnos por melhor iluminação\n");
    printf("4. Sem intervenção - Avançar meses com previsão original\n");
    printf("5. Volta ao menu de previsões\n");
    
    int opcao_intervencao;
    printf("Opção: ");
    scanf("%d", &opcao_intervencao);
    
    if (opcao_intervencao >= 1 && opcao_intervencao <= 4) {
        char *tipo_simulacao = opcao_intervencao == 4 ? "SEM INTERVENÇÃO" : "COM INTERVENÇÃO";
        // Mostra a tabela de comparação apenas se tiver intervenção
        if (opcao_intervencao <= 3) {
            printf("\nSimulando o cenário com intervenção...\n");
            printf("\nPrevisões ANTES vs DEPOIS da intervenção:\n");
            printf("%-5s | %-10s | %-15s | %-15s | %-15s\n",
                   "Mês", "Ano", "Antes (acid.)", "Depois (acid.)", "Redução");
            printf("------+------------+-----------------+-----------------+----------------\n");
            
            for (int i = 0; i < N_PREVISOES; i++) {
                double reducao = 0.0;
                const char* descricao_intervencao = "";
                
                switch(opcao_intervencao) {
                    case 1:
                        reducao = 0.10;  // 10% de redução
                        descricao_intervencao = "Melhoria na sinalização: Redução de 10% nos acidentes";
                        break;
                    case 2:
                        reducao = 0.05;  // 5% de redução nos acidentes, 20% na gravidade
                        descricao_intervencao = "Campanha educativa: Redução de 5% nos acidentes, 20% na gravidade";
                        break;
                    case 3:
                        reducao = 0.30;  // 30% de redução apenas para acidentes noturnos (estimado como 1/3 do total)
                        descricao_intervencao = "Melhoria na iluminação: Redução de 30% nos acidentes noturnos";
                        if (opcao_intervencao == 3) {
                            reducao = 0.30 * 0.33;  // 30% de redução em 33% dos acidentes (noturnos)
                        }
                        break;
                }
                
                double acidentes_antes = previsoes_acidentes_rl[i];
                double acidentes_depois = acidentes_antes * (1.0 - reducao);
                double reducao_absoluta = acidentes_antes - acidentes_depois;
                
                printf("%-5d | %-10d | %-15.2f | %-15.2f | %-15.2f\n",
                       meses_previsao[i], anos_previsao[i], 
                       acidentes_antes, acidentes_depois, reducao_absoluta);
            }
            
            printf("\nDescrição da intervenção: %s\n", 
                  opcao_intervencao == 1 ? "Melhoria na sinalização em pontos críticos" :
                  opcao_intervencao == 2 ? "Campanha educativa focada na redução de velocidade" :
                  "Melhoria na iluminação em trechos de rodovias federais");
            
            printf("\nPós-processamento realizado: %s\n",
                  opcao_intervencao == 1 ? "Aplicação de fator de redução em toda a previsão" :
                  opcao_intervencao == 2 ? "Redução menor no número total, maior impacto na gravidade" :
                  "Aplicação de redução específica aos acidentes noturnos (estimados em 33% do total)");
        } else {
            // Opção 4: Sem intervenção
            printf("\nSimulando o cenário sem intervenção...\n");
            printf("Será exibida a simulação mês a mês utilizando as previsões originais.\n");
        }
        
        // Simulação mês a mês para verificar a acurácia
        printf("\n=== Simulação Mês a Mês ===\n");
        
        // Verifica se a simulação mês a mês foi ativada globalmente
        int opcao_mes_a_mes = getSimulacaoMesAMes();
        
        // Se não foi ativada globalmente, pergunta ao usuário
        if (opcao_mes_a_mes == 0) {
            printf("Deseja avançar mês a mês para verificar a acurácia das previsões? (1-Sim, 0-Não): ");
            scanf("%d", &opcao_mes_a_mes);
        } else {
            printf("Modo de simulação mês a mês ativado automaticamente.\n");
        }
        
        if (opcao_mes_a_mes == 1) {
            printf("\nSimulação de validação da previsão mês a mês (12 meses):\n");
            
            // Para fins de simulação, vamos criar dados "reais" baseados nas previsões com variação aleatória
            srand(time(NULL));  // Inicializa o gerador de números aleatórios
            
            // Simulação para 12 meses, estendendo além das previsões iniciais
            const int MESES_SIMULACAO = 12;
            
            // Parâmetros de modelo para extrapolação
            double ultimo_periodo = x[n_periodos - 1];
            double media_feridos_por_acidente_hist = media_feridos_por_acidente;
            double media_mortos_por_acidente_hist = media_mortos_por_acidente;
            
            for (int i = 0; i < MESES_SIMULACAO; i++) {
                // Cálculo do período (mês e ano)
                double periodo = ultimo_periodo + i + 1;
                int mes = (int)periodo % 12;
                if (mes == 0) mes = 12;  // Converte 0 para 12 (dezembro)
                int ano = (int)periodo / 12;
                
                // Gera previsão conforme o modelo
                double previsao_acidentes;
                if (i < N_PREVISOES) {
                    // Usa previsões já calculadas para os 3 primeiros meses
                    previsao_acidentes = previsoes_acidentes_rl[i];
                } else {
                    // Extrapola usando regressão linear para meses adicionais
                    previsao_acidentes = a + b * periodo;
                }
                
                // Aplica redução da intervenção, se houver (exceto para opção 4 - Sem intervenção)
                double reducao = 0.0;
                if (opcao_intervencao >= 1 && opcao_intervencao <= 3) {
                    switch(opcao_intervencao) {
                        case 1: reducao = 0.10; break;  // 10% de redução
                        case 2: reducao = 0.05; break;  // 5% de redução
                        case 3: reducao = 0.30 * 0.33; break;  // 30% em 33% dos acidentes
                    }
                    previsao_acidentes *= (1.0 - reducao);
                }
                
                // Para opção sem intervenção, mantém previsão original sem alterações
                
                // Simula dados "reais" com variação de até ±10% da previsão, 
                // aumentando gradualmente para simular incerteza futura
                double fator_incerteza = 1.0 + (i * 0.5 / MESES_SIMULACAO); // Aumenta até 50% mais incerteza
                double variacao = (rand() % 21 - 10) / 100.0 * fator_incerteza;  // Variação entre -10% e +10%, aumentando
                double acidentes_reais = previsao_acidentes * (1.0 + variacao);
                
                printf("\nMês %d/%d (Mês %d):\n", mes, ano, i+1);
                printf("Previsão: %.2f acidentes\n", previsao_acidentes);
                printf("Real (simulado): %.2f acidentes\n", acidentes_reais);
                
                // Estatísticas adicionais para meses além da previsão inicial
                if (i >= N_PREVISOES) {
                    printf("Nota: Projeção estendida além do horizonte inicial de previsão.\n");
                }
                
                double erro_percentual = fabs(acidentes_reais - previsao_acidentes) / previsao_acidentes * 100.0;
                printf("Erro percentual: %.2f%%\n", erro_percentual);
                
                if (erro_percentual <= 5.0) {
                    printf("Avaliação: Excelente! (erro < 5%%)\n");
                } else if (erro_percentual <= 10.0) {
                    printf("Avaliação: Boa (erro < 10%%)\n");
                } else if (erro_percentual <= 20.0) {
                    printf("Avaliação: Regular (erro < 20%%)\n");
                } else {
                    printf("Avaliação: Ruim (erro > 20%%)\n");
                }
                
                // Adiciona alertas sazonais baseados no mês
                switch(mes) {
                    case 12:
                    case 1: 
                        printf("Alerta Sazonal: Alto volume de tráfego devido a férias de verão.\n");
                        break;
                    case 6:
                    case 7:
                        printf("Alerta Sazonal: Potencial aumento de acidentes em rodovias devido a férias escolares.\n");
                        break;
                }
                
                if (i < MESES_SIMULACAO - 1) {
                    printf("\nPressione ENTER para avançar para o próximo mês...");
                    getchar(); // Consome o \n anterior
                    getchar(); // Aguarda o ENTER
                }
            }
            
            printf("\nSimulação concluída para todos os 12 meses!\n");
            printf("Avaliação geral: As previsões tendem a ser mais precisas no curto prazo e\n");
            printf("perdem precisão conforme o horizonte de previsão aumenta.\n");
        }
    }
}

void prever_distribuicao_por_uf(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Previsão de Distribuição por UF ---\n");
    
    // Número máximo de UFs
    const int MAX_UFS = 30;
    
    // Estrutura para armazenar estatísticas por UF
    typedef struct {
        char uf[3];
        int acidentes;
        int feridos;
        int mortos;
        double percentual;
        double tendencia;  // Taxa de variação (positiva = aumento, negativa = diminuição)
    } EstatisticaUF;
    
    EstatisticaUF ufs[MAX_UFS];
    int n_ufs = 0;
    
    // Inicializa o array
    memset(ufs, 0, sizeof(ufs));
    
    // Conta acidentes por UF
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a UF já está na lista
        int uf_idx = -1;
        for (int j = 0; j < n_ufs; j++) {
            if (strcmp(ufs[j].uf, acidentes[i].local.uf) == 0) {
                uf_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (uf_idx == -1) {
            if (n_ufs >= MAX_UFS) {
                continue;  // Lista cheia, ignora
            }
            uf_idx = n_ufs++;
            strncpy(ufs[uf_idx].uf, acidentes[i].local.uf, sizeof(ufs[uf_idx].uf) - 1);
        }
        
        // Incrementa contadores
        ufs[uf_idx].acidentes++;
        ufs[uf_idx].feridos += acidentes[i].condicoes.feridos;
        ufs[uf_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Calcula percentuais e tendências
    for (int i = 0; i < n_ufs; i++) {
        ufs[i].percentual = (double)ufs[i].acidentes / n_acidentes * 100.0;
        
        // Calcula tendência (simplificada)
        // Divide dados em dois períodos e compara
        int acidentes_primeiro_periodo = 0;
        int acidentes_segundo_periodo = 0;
        int meio = n_acidentes / 2;
        
        for (int j = 0; j < meio; j++) {
            if (strcmp(acidentes[j].local.uf, ufs[i].uf) == 0) {
                acidentes_primeiro_periodo++;
            }
        }
        
        for (int j = meio; j < n_acidentes; j++) {
            if (strcmp(acidentes[j].local.uf, ufs[i].uf) == 0) {
                acidentes_segundo_periodo++;
            }
        }
        
        // Calcula variação percentual
        if (acidentes_primeiro_periodo > 0) {
            ufs[i].tendencia = ((double)acidentes_segundo_periodo - acidentes_primeiro_periodo) / 
                               acidentes_primeiro_periodo * 100.0;
        } else {
            ufs[i].tendencia = 0.0;
        }
    }
    
    // Ordena por número de acidentes (decrescente)
    for (int i = 0; i < n_ufs - 1; i++) {
        for (int j = i + 1; j < n_ufs; j++) {
            if (ufs[j].acidentes > ufs[i].acidentes) {
                EstatisticaUF temp = ufs[i];
                ufs[i] = ufs[j];
                ufs[j] = temp;
            }
        }
    }
    
    // Exibe estatísticas atuais
    printf("\nDistribuição atual de acidentes por UF:\n");
    printf("%-5s | %-10s | %-10s | %-10s | %-10s | %-15s\n",
           "UF", "Acidentes", "Feridos", "Mortos", "Percentual", "Tendência");
    printf("------+------------+------------+------------+------------+-----------------\n");
    
    for (int i = 0; i < n_ufs; i++) {
        printf("%-5s | %-10d | %-10d | %-10d | %-10.2f%% | %+15.2f%%\n",
               ufs[i].uf, ufs[i].acidentes, ufs[i].feridos, ufs[i].mortos, 
               ufs[i].percentual, ufs[i].tendencia);
    }
    
    // Previsão de distribuição futura
    printf("\nPrevisão de distribuição futura por UF:\n");
    
    // Calcula distribuição prevista aplicando a tendência
    double percentuais_previstos[MAX_UFS];
    double soma_percentuais = 0.0;
    
    for (int i = 0; i < n_ufs; i++) {
        // Aplica tendência ao percentual atual
        percentuais_previstos[i] = ufs[i].percentual * (1.0 + ufs[i].tendencia / 100.0);
        if (percentuais_previstos[i] < 0) percentuais_previstos[i] = 0;
        soma_percentuais += percentuais_previstos[i];
    }
    
    // Normaliza os percentuais previstos
    if (soma_percentuais > 0) {
        for (int i = 0; i < n_ufs; i++) {
            percentuais_previstos[i] = percentuais_previstos[i] / soma_percentuais * 100.0;
        }
    }
    
    // Exibe previsões
    printf("%-5s | %-15s | %-15s | %-15s\n",
           "UF", "Atual (%)", "Previsto (%)", "Variação (pp)");
    printf("------+-----------------+-----------------+----------------\n");
    
    for (int i = 0; i < n_ufs; i++) {
        double variacao = percentuais_previstos[i] - ufs[i].percentual;
        printf("%-5s | %-15.2f | %-15.2f | %+15.2f\n",
               ufs[i].uf, ufs[i].percentual, percentuais_previstos[i], variacao);
    }
    
    // Identifica UFs com maior tendência de aumento
    printf("\nUFs com maior tendência de aumento:\n");
    
    // Ordena por tendência (decrescente)
    for (int i = 0; i < n_ufs - 1; i++) {
        for (int j = i + 1; j < n_ufs; j++) {
            if (ufs[j].tendencia > ufs[i].tendencia) {
                EstatisticaUF temp = ufs[i];
                ufs[i] = ufs[j];
                ufs[j] = temp;
            }
        }
    }
    
    // Exibe as 5 UFs com maior tendência de aumento
    int limit = n_ufs > 5 ? 5 : n_ufs;
    for (int i = 0; i < limit; i++) {
        if (ufs[i].tendencia > 0) {
            printf("%d. %s: %+.2f%% (de %.2f%% para %.2f%%)\n", 
                   i + 1, ufs[i].uf, ufs[i].tendencia, 
                   ufs[i].percentual, ufs[i].percentual * (1.0 + ufs[i].tendencia / 100.0));
        }
    }
}

void prever_distribuicao_por_rodovia(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Previsão de Distribuição por Rodovia (BR) ---\n");
    
    // Número máximo de BRs
    const int MAX_BRS = 50;
    
    // Estrutura para armazenar estatísticas por BR
    typedef struct {
        char br[10];
        int acidentes;
        int feridos;
        int mortos;
        double percentual;
        double tendencia;  // Taxa de variação (positiva = aumento, negativa = diminuição)
        double indice_gravidade;  // Índice de gravidade (feridos + 5*mortos) / acidentes
    } EstatisticaBR;
    
    EstatisticaBR brs[MAX_BRS];
    int n_brs = 0;
    
    // Inicializa o array
    memset(brs, 0, sizeof(brs));
    
    // Conta acidentes por BR
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a BR já está na lista
        int br_idx = -1;
        for (int j = 0; j < n_brs; j++) {
            if (strcmp(brs[j].br, acidentes[i].local.br) == 0) {
                br_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (br_idx == -1) {
            if (n_brs >= MAX_BRS) {
                continue;  // Lista cheia, ignora
            }
            br_idx = n_brs++;
            strncpy(brs[br_idx].br, acidentes[i].local.br, sizeof(brs[br_idx].br) - 1);
        }
        
        // Incrementa contadores
        brs[br_idx].acidentes++;
        brs[br_idx].feridos += acidentes[i].condicoes.feridos;
        brs[br_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Calcula percentuais, índices de gravidade e tendências
    for (int i = 0; i < n_brs; i++) {
        brs[i].percentual = (double)brs[i].acidentes / n_acidentes * 100.0;
        brs[i].indice_gravidade = (brs[i].feridos + 5.0 * brs[i].mortos) / brs[i].acidentes;
        
        // Calcula tendência (simplificada)
        // Divide dados em dois períodos e compara
        int acidentes_primeiro_periodo = 0;
        int acidentes_segundo_periodo = 0;
        int meio = n_acidentes / 2;
        
        for (int j = 0; j < meio; j++) {
            if (strcmp(acidentes[j].local.br, brs[i].br) == 0) {
                acidentes_primeiro_periodo++;
            }
        }
        
        for (int j = meio; j < n_acidentes; j++) {
            if (strcmp(acidentes[j].local.br, brs[i].br) == 0) {
                acidentes_segundo_periodo++;
            }
        }
        
        // Calcula variação percentual
        if (acidentes_primeiro_periodo > 0) {
            brs[i].tendencia = ((double)acidentes_segundo_periodo - acidentes_primeiro_periodo) / 
                              acidentes_primeiro_periodo * 100.0;
        } else {
            brs[i].tendencia = 0.0;
        }
    }
    
    // Ordena por número de acidentes (decrescente)
    for (int i = 0; i < n_brs - 1; i++) {
        for (int j = i + 1; j < n_brs; j++) {
            if (brs[j].acidentes > brs[i].acidentes) {
                EstatisticaBR temp = brs[i];
                brs[i] = brs[j];
                brs[j] = temp;
            }
        }
    }
    
    // Exibe estatísticas atuais (limitadas às 15 BRs com mais acidentes)
    printf("\nDistribuição atual de acidentes por BR (top 15):\n");
    printf("%-10s | %-10s | %-10s | %-10s | %-10s | %-10s | %-15s\n",
           "BR", "Acidentes", "Feridos", "Mortos", "Percentual", "Gravidade", "Tendência");
    printf("------------+------------+------------+------------+------------+------------+-----------------\n");
    
    int limit = n_brs > 15 ? 15 : n_brs;
    for (int i = 0; i < limit; i++) {
        printf("%-10s | %-10d | %-10d | %-10d | %-10.2f%% | %-10.2f | %+15.2f%%\n",
               brs[i].br, brs[i].acidentes, brs[i].feridos, brs[i].mortos, 
               brs[i].percentual, brs[i].indice_gravidade, brs[i].tendencia);
    }
    
    // Ordena por tendência (decrescente) para identificar BRs em crescimento
    for (int i = 0; i < n_brs - 1; i++) {
        for (int j = i + 1; j < n_brs; j++) {
            if (brs[j].tendencia > brs[i].tendencia) {
                EstatisticaBR temp = brs[i];
                brs[i] = brs[j];
                brs[j] = temp;
            }
        }
    }
    
    // Exibe BRs com maior tendência de aumento
    printf("\nBRs com maior tendência de aumento de acidentes:\n");
    limit = n_brs > 5 ? 5 : n_brs;
    for (int i = 0; i < limit; i++) {
        if (brs[i].tendencia > 0) {
            printf("%d. %s: %+.2f%% (atualmente com %d acidentes, %.2f%% do total)\n", 
                   i + 1, brs[i].br, brs[i].tendencia, brs[i].acidentes, brs[i].percentual);
        }
    }
    
    // Ordena por índice de gravidade (decrescente)
    for (int i = 0; i < n_brs - 1; i++) {
        for (int j = i + 1; j < n_brs; j++) {
            if (brs[j].indice_gravidade > brs[i].indice_gravidade) {
                EstatisticaBR temp = brs[i];
                brs[i] = brs[j];
                brs[j] = temp;
            }
        }
    }
    
    // Exibe BRs com maior índice de gravidade
    printf("\nBRs com maior índice de gravidade:\n");
    limit = n_brs > 5 ? 5 : n_brs;
    for (int i = 0; i < limit; i++) {
        printf("%d. %s: %.2f (atualmente com %d acidentes, %d mortos)\n", 
               i + 1, brs[i].br, brs[i].indice_gravidade, brs[i].acidentes, brs[i].mortos);
    }
    
    // Previsão de risco futuro
    printf("\nPrevisão de rodovias com maior risco futuro (combinando gravidade e tendência):\n");
    
    // Calcula índice de risco futuro combinando gravidade e tendência
    double indices_risco[MAX_BRS];
    for (int i = 0; i < n_brs; i++) {
        // Normaliza tendência para [0, 2] (onde > 1 significa aumento)
        double tendencia_norm = brs[i].tendencia > 0 ? 
                               1.0 + (brs[i].tendencia / 100.0) : 
                               1.0 / (1.0 - (brs[i].tendencia / 100.0));
        
        // Índice de risco é gravidade atual × tendência normalizada
        indices_risco[i] = brs[i].indice_gravidade * tendencia_norm;
    }
    
    // Ordena por índice de risco (decrescente)
    for (int i = 0; i < n_brs - 1; i++) {
        for (int j = i + 1; j < n_brs; j++) {
            if (indices_risco[j] > indices_risco[i]) {
                double temp_indice = indices_risco[i];
                indices_risco[i] = indices_risco[j];
                indices_risco[j] = temp_indice;
                
                EstatisticaBR temp_br = brs[i];
                brs[i] = brs[j];
                brs[j] = temp_br;
            }
        }
    }
    
    limit = n_brs > 5 ? 5 : n_brs;
    for (int i = 0; i < limit; i++) {
        printf("%d. %s: Índice de risco futuro %.2f (gravidade: %.2f, tendência: %+.2f%%)\n", 
               i + 1, brs[i].br, indices_risco[i], brs[i].indice_gravidade, brs[i].tendencia);
    }
}

void prever_gravidade_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Previsão de Gravidade de Acidentes ---\n");
    
    // Número máximo de períodos (meses) a analisar
    const int MAX_PERIODOS = 100;
    
    // Array para armazenar os dados temporais
    DadoTemporal dados[MAX_PERIODOS];
    int n_periodos = 0;
    
    // Agrupa os acidentes por mês
    agrupar_por_mes(acidentes, n_acidentes, dados, &n_periodos);
    
    // Verifica se há dados suficientes
    if (n_periodos < 3) {
        printf("Não há dados suficientes para realizar previsões confiáveis.\n");
        return;
    }
    
    // Calcula índices de gravidade por período
    double indices_gravidade[MAX_PERIODOS];
    double feridos_por_acidente[MAX_PERIODOS];
    double mortos_por_acidente[MAX_PERIODOS];
    
    for (int i = 0; i < n_periodos; i++) {
        if (dados[i].acidentes > 0) {
            feridos_por_acidente[i] = (double)dados[i].feridos / dados[i].acidentes;
            mortos_por_acidente[i] = (double)dados[i].mortos / dados[i].acidentes;
            indices_gravidade[i] = (dados[i].feridos + 5.0 * dados[i].mortos) / dados[i].acidentes;
        } else {
            feridos_por_acidente[i] = 0;
            mortos_por_acidente[i] = 0;
            indices_gravidade[i] = 0;
        }
    }
    
    // Exibe estatísticas de gravidade por período
    printf("\nEvolução histórica da gravidade por período:\n");
    printf("%-5s | %-10s | %-15s | %-15s | %-15s\n",
           "Mês", "Ano", "Feridos/Acid.", "Mortos/Acid.", "Índice Gravidade");
    printf("------+------------+-----------------+-----------------+------------------\n");
    
    for (int i = 0; i < n_periodos; i++) {
        printf("%-5d | %-10d | %-15.2f | %-15.2f | %-15.2f\n",
               dados[i].periodo, dados[i].ano, 
               feridos_por_acidente[i], mortos_por_acidente[i], indices_gravidade[i]);
    }
    
    // Prepara os dados para regressão linear
    double x[MAX_PERIODOS];
    
    for (int i = 0; i < n_periodos; i++) {
        // Converte o período para uma escala contínua (mês + ano*12)
        x[i] = dados[i].ano * 12.0 + dados[i].periodo;
    }
    
    // Realiza regressão linear para índice de gravidade
    double a, b, r2;
    regressao_linear(x, indices_gravidade, n_periodos, &a, &b, &r2);
    
    printf("\nModelo de Tendência para Índice de Gravidade:\n");
    printf("Equação: Índice = %.4f + %.4f * Período\n", a, b);
    printf("Coeficiente de determinação (R²): %.4f\n", r2);
    
    // Interpreta a tendência
    if (fabs(b) < 0.001) {
        printf("Tendência: Estabilidade na gravidade dos acidentes.\n");
    } else if (b > 0) {
        printf("Tendência: Aumento na gravidade dos acidentes (%.2f%% por período).\n", 
               b / indices_gravidade[n_periodos - 1] * 100.0);
    } else {
        printf("Tendência: Diminuição na gravidade dos acidentes (%.2f%% por período).\n", 
               -b / indices_gravidade[n_periodos - 1] * 100.0);
    }
    
    // Realiza previsões para os próximos 3 meses
    const int N_PREVISOES = 3;
    double ultimo_periodo = x[n_periodos - 1];
    
    printf("\nPrevisões de gravidade para os próximos %d meses:\n", N_PREVISOES);
    printf("%-5s | %-10s | %-15s\n",
           "Mês", "Ano", "Índice Previsto");
    printf("------+------------+-----------------\n");
    
    for (int i = 1; i <= N_PREVISOES; i++) {
        double periodo = ultimo_periodo + i;
        int mes = (int)periodo % 12;
        if (mes == 0) mes = 12;  // Converte 0 para 12 (dezembro)
        int ano = (int)periodo / 12;
        
        // Prevê índice de gravidade usando regressão linear
        double previsao_indice = a + b * periodo;
        if (previsao_indice < 0) previsao_indice = 0;  // Evita índices negativos
        
        printf("%-5d | %-10d | %-15.2f\n", mes, ano, previsao_indice);
    }
    
    // Análise de fatores que influenciam a gravidade
    printf("\nAnálise de fatores que influenciam a gravidade:\n");
    
    // 1. Gravidade por tipo de acidente
    typedef struct {
        char tipo[50];
        int acidentes;
        int feridos;
        int mortos;
        double indice_gravidade;
    } GravidadeTipo;
    
    GravidadeTipo tipos[30];
    int n_tipos = 0;
    
    memset(tipos, 0, sizeof(tipos));
    
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se o tipo já está na lista
        int tipo_idx = -1;
        for (int j = 0; j < n_tipos; j++) {
            if (strcmp(tipos[j].tipo, acidentes[i].condicoes.classificacao) == 0) {
                tipo_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (tipo_idx == -1) {
            if (n_tipos >= 30) {
                continue;  // Lista cheia, ignora
            }
            tipo_idx = n_tipos++;
            strncpy(tipos[tipo_idx].tipo, acidentes[i].condicoes.classificacao, sizeof(tipos[tipo_idx].tipo) - 1);
        }
        
        // Incrementa contadores
        tipos[tipo_idx].acidentes++;
        tipos[tipo_idx].feridos += acidentes[i].condicoes.feridos;
        tipos[tipo_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Calcula índice de gravidade para cada tipo
    for (int i = 0; i < n_tipos; i++) {
        if (tipos[i].acidentes > 0) {
            tipos[i].indice_gravidade = (tipos[i].feridos + 5.0 * tipos[i].mortos) / tipos[i].acidentes;
        }
    }
    
    // Ordena por índice de gravidade (decrescente)
    for (int i = 0; i < n_tipos - 1; i++) {
        for (int j = i + 1; j < n_tipos; j++) {
            if (tipos[j].indice_gravidade > tipos[i].indice_gravidade) {
                GravidadeTipo temp = tipos[i];
                tipos[i] = tipos[j];
                tipos[j] = temp;
            }
        }
    }
    
    printf("\nTipos de acidente com maior gravidade:\n");
    int limit = n_tipos > 5 ? 5 : n_tipos;
    for (int i = 0; i < limit; i++) {
        printf("%d. %s: Índice de gravidade %.2f (%d acidentes, %d feridos, %d mortos)\n", 
               i + 1, tipos[i].tipo, tipos[i].indice_gravidade, 
               tipos[i].acidentes, tipos[i].feridos, tipos[i].mortos);
    }
    
    // 2. Gravidade por fase do dia
    typedef struct {
        char fase[20];
        int acidentes;
        int feridos;
        int mortos;
        double indice_gravidade;
    } GravidadeFase;
    
    GravidadeFase fases[5];
    int n_fases = 0;
    
    memset(fases, 0, sizeof(fases));
    
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a fase já está na lista
        int fase_idx = -1;
        for (int j = 0; j < n_fases; j++) {
            if (strcmp(fases[j].fase, acidentes[i].condicoes.fase_dia) == 0) {
                fase_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (fase_idx == -1) {
            if (n_fases >= 5 || acidentes[i].condicoes.fase_dia[0] == '\0') {
                continue;  // Lista cheia ou fase vazia, ignora
            }
            fase_idx = n_fases++;
            strncpy(fases[fase_idx].fase, acidentes[i].condicoes.fase_dia, sizeof(fases[fase_idx].fase) - 1);
        }
        
        // Incrementa contadores
        fases[fase_idx].acidentes++;
        fases[fase_idx].feridos += acidentes[i].condicoes.feridos;
        fases[fase_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Calcula índice de gravidade para cada fase
    for (int i = 0; i < n_fases; i++) {
        if (fases[i].acidentes > 0) {
            fases[i].indice_gravidade = (fases[i].feridos + 5.0 * fases[i].mortos) / fases[i].acidentes;
        }
    }
    
    // Ordena por índice de gravidade (decrescente)
    for (int i = 0; i < n_fases - 1; i++) {
        for (int j = i + 1; j < n_fases; j++) {
            if (fases[j].indice_gravidade > fases[i].indice_gravidade) {
                GravidadeFase temp = fases[i];
                fases[i] = fases[j];
                fases[j] = temp;
            }
        }
    }
    
    printf("\nFases do dia com maior gravidade:\n");
    for (int i = 0; i < n_fases; i++) {
        printf("%d. %s: Índice de gravidade %.2f (%d acidentes, %d feridos, %d mortos)\n", 
               i + 1, fases[i].fase, fases[i].indice_gravidade, 
               fases[i].acidentes, fases[i].feridos, fases[i].mortos);
    }
}

void identificar_tendencias_temporais(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Identificação de Tendências Temporais ---\n");
    
    // Número máximo de períodos (meses) a analisar
    const int MAX_PERIODOS = 100;
    
    // Array para armazenar os dados temporais
    DadoTemporal dados[MAX_PERIODOS];
    int n_periodos = 0;
    
    // Agrupa os acidentes por mês
    agrupar_por_mes(acidentes, n_acidentes, dados, &n_periodos);
    
    // Verifica se há dados suficientes
    if (n_periodos < 6) {
        printf("Não há dados suficientes para identificar tendências temporais confiáveis.\n");
        return;
    }
    
    // Exibe os dados agrupados por mês
    printf("\nDados históricos por mês:\n");
    printf("%-5s | %-10s | %-10s\n",
           "Mês", "Ano", "Acidentes");
    printf("------+------------+------------\n");
    
    for (int i = 0; i < n_periodos; i++) {
        printf("%-5d | %-10d | %-10d\n",
               dados[i].periodo, dados[i].ano, dados[i].acidentes);
    }
    
    // Análise de tendência geral (usando regressão linear)
    double x[MAX_PERIODOS], y[MAX_PERIODOS];
    
    for (int i = 0; i < n_periodos; i++) {
        // Converte o período para uma escala contínua (mês + ano*12)
        x[i] = dados[i].ano * 12.0 + dados[i].periodo;
        y[i] = dados[i].acidentes;
    }
    
    double a, b, r2;
    regressao_linear(x, y, n_periodos, &a, &b, &r2);
    
    printf("\nTendência Linear: Acidentes = %.2f + %.2f * Período\n", a, b);
    printf("Coeficiente de determinação (R²): %.4f\n", r2);
    
    // Interpreta a tendência
    if (fabs(b) < 0.001) {
        printf("Tendência Geral: Estabilidade no número de acidentes.\n");
    } else if (b > 0) {
        printf("Tendência Geral: Aumento no número de acidentes (%.2f por período).\n", b);
    } else {
        printf("Tendência Geral: Diminuição no número de acidentes (%.2f por período).\n", b);
    }
    
    // Análise de sazonalidade (média de acidentes por mês)
    int acidentes_por_mes[12] = {0};
    int contagens_mes[12] = {0};
    
    for (int i = 0; i < n_periodos; i++) {
        int mes = dados[i].periodo;
        if (mes >= 1 && mes <= 12) {
            acidentes_por_mes[mes - 1] += dados[i].acidentes;
            contagens_mes[mes - 1]++;
        }
    }
    
    printf("\nSazonalidade - Média de acidentes por mês:\n");
    
    const char *nomes_meses[] = {
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    };
    
    // Calcula as médias por mês
    double medias_por_mes[12];
    double media_geral = 0.0;
    int total_meses = 0;
    
    for (int i = 0; i < 12; i++) {
        if (contagens_mes[i] > 0) {
            medias_por_mes[i] = (double)acidentes_por_mes[i] / contagens_mes[i];
            media_geral += acidentes_por_mes[i];
            total_meses += contagens_mes[i];
        } else {
            medias_por_mes[i] = 0.0;
        }
    }
    
    if (total_meses > 0) {
        media_geral /= total_meses;
    }
    
    // Exibe as médias por mês e calcula o fator sazonal
    printf("%-12s | %-15s | %-15s | %-15s\n",
           "Mês", "Média Acidentes", "Fator Sazonal", "Variação");
    printf("--------------+-----------------+-----------------+----------------\n");
    
    for (int i = 0; i < 12; i++) {
        if (contagens_mes[i] > 0) {
            double fator_sazonal = media_geral > 0 ? medias_por_mes[i] / media_geral : 1.0;
            double variacao = (fator_sazonal - 1.0) * 100.0;
            
            printf("%-12s | %-15.2f | %-15.2f | %+15.2f%%\n",
                   nomes_meses[i], medias_por_mes[i], fator_sazonal, variacao);
        }
    }
    
    // Identifica meses com maior incidência
    printf("\nMeses com maior incidência de acidentes (acima da média):\n");
    
    int indices_meses[12];
    for (int i = 0; i < 12; i++) {
        indices_meses[i] = i;
    }
    
    // Ordena os meses por média de acidentes (decrescente)
    for (int i = 0; i < 12 - 1; i++) {
        for (int j = i + 1; j < 12; j++) {
            if (medias_por_mes[indices_meses[j]] > medias_por_mes[indices_meses[i]]) {
                int temp = indices_meses[i];
                indices_meses[i] = indices_meses[j];
                indices_meses[j] = temp;
            }
        }
    }
    
    for (int i = 0; i < 12; i++) {
        int idx = indices_meses[i];
        if (contagens_mes[idx] > 0 && medias_por_mes[idx] > media_geral) {
            double acima = (medias_por_mes[idx] - media_geral) / media_geral * 100.0;
            printf("%d. %s: %.2f acidentes (%.2f%% acima da média)\n", 
                   i + 1, nomes_meses[idx], medias_por_mes[idx], acima);
        }
    }
    
    // Análise de tendência por dia da semana
    int acidentes_por_dia[7] = {0};
    
    for (int i = 0; i < n_acidentes; i++) {
        // Calcula o dia da semana a partir da data do acidente (usando o algoritmo de Zeller)
        int d = acidentes[i].data.dia;
        int m = acidentes[i].data.mes;
        int y = acidentes[i].data.ano;
        
        // Ajusta mês e ano (janeiro e fevereiro são considerados meses 13 e 14 do ano anterior)
        if (m < 3) {
            m += 12;
            y--;
        }
        
        int h = (d + (13 * (m + 1)) / 5 + y + y / 4 - y / 100 + y / 400) % 7;
        
        // h = 0 é sábado, h = 1 é domingo, ..., h = 6 é sexta
        // Ajusta para domingo = 0, segunda = 1, ..., sábado = 6
        int dia_semana = (h + 1) % 7;
        
        acidentes_por_dia[dia_semana]++;
    }
    
    printf("\nDistribuição de acidentes por dia da semana:\n");
    
    const char *nomes_dias[] = {
        "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira",
        "Quinta-feira", "Sexta-feira", "Sábado"
    };
    
    // Calcula a média diária
    double media_diaria = (double)n_acidentes / 7;
    
    for (int i = 0; i < 7; i++) {
        double percentual = (double)acidentes_por_dia[i] / n_acidentes * 100.0;
        double variacao = acidentes_por_dia[i] - media_diaria;
        double variacao_percentual = variacao / media_diaria * 100.0;
        
        printf("%s: %d acidentes (%.2f%% do total, %+.2f%% da média)\n", 
               nomes_dias[i], acidentes_por_dia[i], percentual, variacao_percentual);
    }
    
    // Identifica padrões específicos
    printf("\nResumo de tendências temporais identificadas:\n");
    
    // 1. Tendência Geral
    if (r2 > 0.5) {  // Correlação razoável
        if (b > 0) {
            printf("- Tendência geral de aumento no número de acidentes.\n");
        } else if (b < 0) {
            printf("- Tendência geral de diminuição no número de acidentes.\n");
        }
    } else {
        printf("- Sem tendência linear clara (baixa correlação).\n");
    }
    
    // 2. Sazonalidade Mensal
    printf("- ");
    int meses_alta = 0;
    for (int i = 0; i < 3 && i < 12; i++) {
        int idx = indices_meses[i];
        if (contagens_mes[idx] > 0 && medias_por_mes[idx] > media_geral) {
            if (meses_alta > 0) printf(", ");
            printf("%s", nomes_meses[idx]);
            meses_alta++;
        }
    }
    if (meses_alta > 0) {
        printf(" apresentam maior incidência de acidentes.\n");
    } else {
        printf("Sem padrão sazonal mensal significativo.\n");
    }
    
    // 3. Padrão Semanal
    // Ordena os dias por número de acidentes
    int indices_dias[7];
    for (int i = 0; i < 7; i++) {
        indices_dias[i] = i;
    }
    
    for (int i = 0; i < 7 - 1; i++) {
        for (int j = i + 1; j < 7; j++) {
            if (acidentes_por_dia[indices_dias[j]] > acidentes_por_dia[indices_dias[i]]) {
                int temp = indices_dias[i];
                indices_dias[i] = indices_dias[j];
                indices_dias[j] = temp;
            }
        }
    }
    
    printf("- Dias com maior incidência: ");
    for (int i = 0; i < 2 && i < 7; i++) {
        int idx = indices_dias[i];
        if (i > 0) printf(" e ");
        printf("%s", nomes_dias[idx]);
    }
    printf(".\n");
    
    // 4. Previsão para o próximo período
    double ultimo_periodo = x[n_periodos - 1];
    double proximo_periodo = ultimo_periodo + 1;
    int proximo_mes = (int)proximo_periodo % 12;
    if (proximo_mes == 0) proximo_mes = 12;
    int proximo_ano = (int)proximo_periodo / 12;
    
    // Previsão usando tendência linear + fator sazonal
    double previsao_linear = a + b * proximo_periodo;
    double fator_sazonal = medias_por_mes[proximo_mes - 1] / media_geral;
    
    printf("- Para %s/%d: Previsão de %.0f acidentes (tendência linear ajustada pela sazonalidade).\n",
           nomes_meses[proximo_mes - 1], proximo_ano, previsao_linear * fator_sazonal);
}

void simular_impacto_melhorias(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Simulação de Impacto de Melhorias em Pontos Críticos ---\n");
    
    // Número máximo de pontos críticos a identificar
    const int MAX_PONTOS = 50;
    
    // Estrutura para armazenar informações sobre trechos críticos
    typedef struct {
        char uf[3];
        char br[10];
        double km_inicio;
        double km_fim;
        int acidentes;
        int feridos;
        int mortos;
        double indice_gravidade;
    } TrechoCritico;
    
    TrechoCritico trechos[MAX_PONTOS];
    int n_trechos = 0;
    
    // Tamanho do trecho para agrupar acidentes (em km)
    const double TAMANHO_TRECHO = 5.0;
    
    printf("Identificando trechos críticos (agrupando a cada %.1f km)...\n", TAMANHO_TRECHO);
    
    // Para cada rodovia (BR), identifica trechos críticos
    // Primeiro, lista todas as BRs únicas
    char brs_unicas[MAX_PONTOS][10];
    int n_brs = 0;
    
    for (int i = 0; i < n_acidentes; i++) {
        int br_existe = 0;
        for (int j = 0; j < n_brs; j++) {
            if (strcmp(brs_unicas[j], acidentes[i].local.br) == 0) {
                br_existe = 1;
                break;
            }
        }
        
        if (!br_existe && n_brs < MAX_PONTOS) {
            strcpy(brs_unicas[n_brs], acidentes[i].local.br);
            n_brs++;
        }
    }
    
    // Para cada BR, analisa os trechos
    for (int b = 0; b < n_brs; b++) {
        // Lista todos os acidentes desta BR, ordenados por km
        typedef struct {
            int indice;     // índice no array original de acidentes
            double km;      // quilômetro da rodovia
        } AcidenteKM;
        
        AcidenteKM acidentes_br[n_acidentes];
        int n_acidentes_br = 0;
        
        for (int i = 0; i < n_acidentes; i++) {
            if (strcmp(acidentes[i].local.br, brs_unicas[b]) == 0) {
                acidentes_br[n_acidentes_br].indice = i;
                acidentes_br[n_acidentes_br].km = acidentes[i].local.km;
                n_acidentes_br++;
            }
        }
        
        // Ordena por km
        for (int i = 0; i < n_acidentes_br - 1; i++) {
            for (int j = i + 1; j < n_acidentes_br; j++) {
                if (acidentes_br[j].km < acidentes_br[i].km) {
                    AcidenteKM temp = acidentes_br[i];
                    acidentes_br[i] = acidentes_br[j];
                    acidentes_br[j] = temp;
                }
            }
        }
        
        // Agrupa em trechos
        if (n_acidentes_br > 0) {
            double km_atual = floor(acidentes_br[0].km / TAMANHO_TRECHO) * TAMANHO_TRECHO;
            int acidentes_trecho = 0;
            int feridos_trecho = 0;
            int mortos_trecho = 0;
            
            for (int i = 0; i < n_acidentes_br; i++) {
                double km = acidentes_br[i].km;
                int idx = acidentes_br[i].indice;
                
                // Verifica se estamos no mesmo trecho
                if (km < km_atual + TAMANHO_TRECHO) {
                    // Mesmo trecho, acumula
                    acidentes_trecho++;
                    feridos_trecho += acidentes[idx].condicoes.feridos;
                    mortos_trecho += acidentes[idx].condicoes.mortos;
                } else {
                    // Novo trecho, grava o anterior se tiver acidentes suficientes
                    if (acidentes_trecho >= 5 && n_trechos < MAX_PONTOS) {
                        strcpy(trechos[n_trechos].br, brs_unicas[b]);
                        strcpy(trechos[n_trechos].uf, acidentes[acidentes_br[i-1].indice].local.uf);
                        trechos[n_trechos].km_inicio = km_atual;
                        trechos[n_trechos].km_fim = km_atual + TAMANHO_TRECHO;
                        trechos[n_trechos].acidentes = acidentes_trecho;
                        trechos[n_trechos].feridos = feridos_trecho;
                        trechos[n_trechos].mortos = mortos_trecho;
                        trechos[n_trechos].indice_gravidade = 
                            (feridos_trecho + 5.0 * mortos_trecho) / acidentes_trecho;
                        n_trechos++;
                    }
                    
                    // Inicia novo trecho
                    km_atual = floor(km / TAMANHO_TRECHO) * TAMANHO_TRECHO;
                    acidentes_trecho = 1;
                    feridos_trecho = acidentes[idx].condicoes.feridos;
                    mortos_trecho = acidentes[idx].condicoes.mortos;
                }
            }
            
            // Processa o último trecho
            if (acidentes_trecho >= 5 && n_trechos < MAX_PONTOS) {
                strcpy(trechos[n_trechos].br, brs_unicas[b]);
                strcpy(trechos[n_trechos].uf, acidentes[acidentes_br[n_acidentes_br-1].indice].local.uf);
                trechos[n_trechos].km_inicio = km_atual;
                trechos[n_trechos].km_fim = km_atual + TAMANHO_TRECHO;
                trechos[n_trechos].acidentes = acidentes_trecho;
                trechos[n_trechos].feridos = feridos_trecho;
                trechos[n_trechos].mortos = mortos_trecho;
                trechos[n_trechos].indice_gravidade = 
                    (feridos_trecho + 5.0 * mortos_trecho) / acidentes_trecho;
                n_trechos++;
            }
        }
    }
    
    // Ordena os trechos por índice de gravidade (decrescente)
    for (int i = 0; i < n_trechos - 1; i++) {
        for (int j = i + 1; j < n_trechos; j++) {
            if (trechos[j].indice_gravidade > trechos[i].indice_gravidade) {
                TrechoCritico temp = trechos[i];
                trechos[i] = trechos[j];
                trechos[j] = temp;
            }
        }
    }
    
    // Exibe os trechos críticos identificados
    printf("\nTrechos críticos identificados (top 10):\n");
    printf("%-7s | %-10s | %-20s | %-10s | %-10s | %-10s | %-15s\n",
           "UF", "BR", "Trecho (km)", "Acidentes", "Feridos", "Mortos", "Índice Grav.");
    printf("---------+------------+----------------------+------------+------------+------------+-----------------\n");
    
    int limit = n_trechos > 10 ? 10 : n_trechos;
    for (int i = 0; i < limit; i++) {
        printf("%-7s | %-10s | %.1f - %.1f km      | %-10d | %-10d | %-10d | %-15.2f\n",
               trechos[i].uf, trechos[i].br, trechos[i].km_inicio, trechos[i].km_fim,
               trechos[i].acidentes, trechos[i].feridos, trechos[i].mortos,
               trechos[i].indice_gravidade);
    }
    
    // Simula o impacto de melhorias
    printf("\nSimulação de impacto de melhorias:\n");
    
    // Define os tipos de melhorias e suas eficácias estimadas
    typedef struct {
        char descricao[100];
        double reducao_acidentes;  // Redução percentual estimada
        double reducao_gravidade;  // Redução percentual na gravidade
        double custo_por_km;       // Custo estimado por km (em milhares de R$)
    } Melhoria;
    
    Melhoria melhorias[] = {
        {"Implantação de redutores de velocidade", 0.25, 0.15, 50.0},
        {"Melhoria na sinalização", 0.15, 0.10, 30.0},
        {"Duplicação da pista", 0.40, 0.35, 800.0},
        {"Correção da geometria da via", 0.20, 0.25, 200.0},
        {"Instalação de barreiras de contenção", 0.10, 0.30, 100.0}
    };
    
    int n_melhorias = sizeof(melhorias) / sizeof(Melhoria);
    
    printf("\nOpções de melhorias disponíveis:\n");
    for (int i = 0; i < n_melhorias; i++) {
        printf("%d. %s (Redução de acidentes: %.1f%%, Redução de gravidade: %.1f%%, Custo: R$ %.1f mil/km)\n",
               i + 1, melhorias[i].descricao, 
               melhorias[i].reducao_acidentes * 100.0,
               melhorias[i].reducao_gravidade * 100.0,
               melhorias[i].custo_por_km);
    }
    
    // Escolhe uma melhoria para simular
    int escolha;
    printf("\nEscolha uma melhoria para simular (1-%d): ", n_melhorias);
    scanf("%d", &escolha);
    
    if (escolha < 1 || escolha > n_melhorias) {
        printf("Opção inválida! Usando a primeira melhoria como padrão.\n");
        escolha = 1;
    }
    
    Melhoria melhoria_escolhida = melhorias[escolha - 1];
    
    // Simula o impacto nos trechos críticos
    printf("\nImpacto da melhoria '%s' nos trechos críticos:\n", melhoria_escolhida.descricao);
    printf("%-7s | %-10s | %-15s | %-15s | %-15s | %-15s | %-15s\n",
           "UF", "BR", "Trecho (km)", "Acidentes Prev.", "Mortos Prev.", "Redução Acid.", "Custo (mil R$)");
    printf("---------+------------+-----------------+-----------------+-----------------+-----------------+-----------------\n");
    
    // Totais para resumo
    int total_acidentes_evitados = 0;
    int total_mortos_evitados = 0;
    double custo_total = 0.0;
    
    limit = n_trechos > 5 ? 5 : n_trechos;  // Simula apenas os 5 trechos mais graves
    for (int i = 0; i < limit; i++) {
        // Calcula o impacto da melhoria
        double comprimento_trecho = trechos[i].km_fim - trechos[i].km_inicio;
        int acidentes_previstos = (int)(trechos[i].acidentes * (1.0 - melhoria_escolhida.reducao_acidentes));
        int acidentes_evitados = trechos[i].acidentes - acidentes_previstos;
        
        int mortos_previstos = (int)(trechos[i].mortos * (1.0 - melhoria_escolhida.reducao_gravidade));
        int mortos_evitados = trechos[i].mortos - mortos_previstos;
        
        double custo = comprimento_trecho * melhoria_escolhida.custo_por_km;
        
        printf("%-7s | %-10s | %.1f - %.1f km | %-15d | %-15d | %-15d | %-15.2f\n",
               trechos[i].uf, trechos[i].br, trechos[i].km_inicio, trechos[i].km_fim,
               acidentes_previstos, mortos_previstos, acidentes_evitados, custo);
        
        total_acidentes_evitados += acidentes_evitados;
        total_mortos_evitados += mortos_evitados;
        custo_total += custo;
    }
    
    // Exibe resumo da simulação
    printf("\nResumo da simulação:\n");
    printf("- Total de acidentes evitados: %d\n", total_acidentes_evitados);
    printf("- Total de mortos evitados: %d\n", total_mortos_evitados);
    printf("- Custo total das melhorias: R$ %.2f mil\n", custo_total);
    
    double custo_por_acidente = custo_total / total_acidentes_evitados;
    printf("- Custo médio por acidente evitado: R$ %.2f mil\n", custo_por_acidente);
    
    if (total_mortos_evitados > 0) {
        double custo_por_vida = custo_total / total_mortos_evitados;
        printf("- Custo médio por vida salva: R$ %.2f mil\n", custo_por_vida);
    }
}
// Implementação das funções para controle de simulação mês a mês
void setSimulacaoMesAMes(int ativar) {
    simulacao_mes_a_mes = ativar;
}

int getSimulacaoMesAMes(void) {
    return simulacao_mes_a_mes;
}
