/**
 * comparacao.c
 * 
 * Implementação de funções para comparação de múltiplos cenários de intervenção.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "comparacao.h"
#include "previsao.h"
#include "../utils/visualizacao.h"

// Valor econômico estimado para custos sociais (em milhares de R$)
#define CUSTO_ACIDENTE_MATERIAL 20.0    // 20 mil reais por acidente material
#define CUSTO_FERIDO 80.0               // 80 mil reais por ferido
#define CUSTO_MORTE 1500.0              // 1,5 milhão de reais por morte

// Cenários pré-definidos
const Cenario CENARIOS[] = {
    {
        "Sinalização",
        "Melhoria na sinalização em pontos críticos das rodovias",
        0.10,  // Reduz acidentes em 10%
        0.05,  // Reduz gravidade em 5%
        50.0   // Custo: 50 mil por km
    },
    {
        "Educ. e Fiscalização",
        "Campanhas educativas e aumento da fiscalização eletrônica",
        0.05,  // Reduz acidentes em 5%
        0.20,  // Reduz gravidade em 20%
        30.0   // Custo: 30 mil por km
    },
    {
        "Iluminação",
        "Melhoria na iluminação em trechos de rodovias federais",
        0.10,  // Reduz acidentes em 10%
        0.05,  // Reduz gravidade em 5%
        40.0   // Custo: 40 mil por km
    },
    {
        "Duplicação",
        "Duplicação de pistas em trechos críticos",
        0.40,  // Reduz acidentes em 40%
        0.30,  // Reduz gravidade em 30%
        800.0  // Custo: 800 mil por km
    },
    {
        "Combinado",
        "Combinação de sinalização, iluminação e educação",
        0.20,  // Reduz acidentes em 20%
        0.25,  // Reduz gravidade em 25%
        120.0  // Custo: 120 mil por km
    }
};
const int NUM_CENARIOS = sizeof(CENARIOS) / sizeof(Cenario);

// Cenário base (sem intervenção)
const Cenario CENARIO_BASE = {
    "Sem Intervenção",
    "Cenário base sem implementação de melhorias",
    0.0,  // Sem redução de acidentes
    0.0,  // Sem redução de gravidade
    0.0   // Sem custo
};

void agrupar_dados_mensais(Acidente *acidentes, int n_acidentes, 
                          double *acidentes_por_mes, double *feridos_por_mes, 
                          double *mortos_por_mes, int *n_meses) {
    // Estrutura para armazenar dados por mês-ano
    typedef struct {
        int mes;
        int ano;
        int acidentes;
        int feridos;
        int mortos;
    } DadosMes;
    
    // Tamanho máximo de períodos a analisar
    const int MAX_PERIODOS = 100;
    DadosMes dados[MAX_PERIODOS];
    *n_meses = 0;
    
    // Conta acidentes por mês-ano
    for (int i = 0; i < n_acidentes; i++) {
        int mes = acidentes[i].data.mes;
        int ano = acidentes[i].data.ano;
        
        // Procura se o período já existe
        int idx = -1;
        for (int j = 0; j < *n_meses; j++) {
            if (dados[j].mes == mes && dados[j].ano == ano) {
                idx = j;
                break;
            }
        }
        
        // Se não existe, cria novo período
        if (idx == -1) {
            if (*n_meses >= MAX_PERIODOS) continue;
            idx = (*n_meses)++;
            dados[idx].mes = mes;
            dados[idx].ano = ano;
            dados[idx].acidentes = 0;
            dados[idx].feridos = 0;
            dados[idx].mortos = 0;
        }
        
        // Incrementa contadores
        dados[idx].acidentes++;
        dados[idx].feridos += acidentes[i].condicoes.feridos;
        dados[idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Ordena por data
    for (int i = 0; i < *n_meses - 1; i++) {
        for (int j = i + 1; j < *n_meses; j++) {
            if (dados[j].ano < dados[i].ano || 
                (dados[j].ano == dados[i].ano && dados[j].mes < dados[i].mes)) {
                DadosMes temp = dados[i];
                dados[i] = dados[j];
                dados[j] = temp;
            }
        }
    }
    
    // Copia dados para os arrays de resultado
    for (int i = 0; i < *n_meses; i++) {
        acidentes_por_mes[i] = dados[i].acidentes;
        feridos_por_mes[i] = dados[i].feridos;
        mortos_por_mes[i] = dados[i].mortos;
    }
}

void gerar_previsoes(double *historico, int n_historico, double *previsoes, int n_previsoes) {
    // Usa regressão linear para gerar previsões
    double x[100], y[100];
    for (int i = 0; i < n_historico; i++) {
        x[i] = i;
        y[i] = historico[i];
    }
    
    double a, b, r2;
    regressao_linear(x, y, n_historico, &a, &b, &r2);
    
    // Gera previsões
    for (int i = 0; i < n_previsoes; i++) {
        double x_pred = n_historico + i;
        previsoes[i] = a + b * x_pred;
        if (previsoes[i] < 0) previsoes[i] = 0;  // Evita valores negativos
    }
}

void simular_cenario(Acidente *acidentes, int n_acidentes, const Cenario *cenario,
                    double *resultado_acidentes, double *resultado_feridos, 
                    double *resultado_mortos, int n_periodos) {
    // Agrupa dados históricos por mês
    double acidentes_por_mes[100];
    double feridos_por_mes[100];
    double mortos_por_mes[100];
    int n_meses;
    
    agrupar_dados_mensais(acidentes, n_acidentes, acidentes_por_mes, 
                         feridos_por_mes, mortos_por_mes, &n_meses);
    
    // Gera previsões para os próximos períodos
    gerar_previsoes(acidentes_por_mes, n_meses, resultado_acidentes, n_periodos);
    gerar_previsoes(feridos_por_mes, n_meses, resultado_feridos, n_periodos);
    gerar_previsoes(mortos_por_mes, n_meses, resultado_mortos, n_periodos);
    
    // Aplica fatores de redução do cenário
    for (int i = 0; i < n_periodos; i++) {
        resultado_acidentes[i] *= (1.0 - cenario->fator_reducao);
        
        // Aplica reduções de gravidade aos feridos e mortos
        resultado_feridos[i] *= (1.0 - cenario->fator_reducao) * (1.0 - cenario->fator_reducao_grave);
        resultado_mortos[i] *= (1.0 - cenario->fator_reducao) * (1.0 - cenario->fator_reducao_grave);
    }
}

double calcular_roi(int acidentes_evitados, int feridos_evitados, int mortos_evitados, double custo) {
    if (custo <= 0.0) return 0.0;  // Evita divisão por zero
    
    // Calcula benefícios econômicos (em milhares de R$)
    double beneficio = acidentes_evitados * CUSTO_ACIDENTE_MATERIAL +
                       feridos_evitados * CUSTO_FERIDO +
                       mortos_evitados * CUSTO_MORTE;
    
    // Calcula ROI: (benefício - custo) / custo
    return (beneficio - custo) / custo;
}

void comparar_cenarios(Acidente *acidentes, int n_acidentes) {
    printf("\n=== COMPARAÇÃO DE MÚLTIPLOS CENÁRIOS DE INTERVENÇÃO ===\n\n");
    
    // Número de períodos para previsão
    const int N_PERIODOS = 12;
    
    // Matriz para armazenar resultados de cada cenário
    double **resultados_acidentes = (double**)malloc((NUM_CENARIOS + 1) * sizeof(double*));
    double **resultados_feridos = (double**)malloc((NUM_CENARIOS + 1) * sizeof(double*));
    double **resultados_mortos = (double**)malloc((NUM_CENARIOS + 1) * sizeof(double*));
    
    for (int i = 0; i <= NUM_CENARIOS; i++) {
        resultados_acidentes[i] = (double*)malloc(N_PERIODOS * sizeof(double));
        resultados_feridos[i] = (double*)malloc(N_PERIODOS * sizeof(double));
        resultados_mortos[i] = (double*)malloc(N_PERIODOS * sizeof(double));
    }
    
    // Simula cenário base (sem intervenção)
    printf("Simulando cenário base (sem intervenção)...\n");
    simular_cenario(acidentes, n_acidentes, &CENARIO_BASE, 
                   resultados_acidentes[0], resultados_feridos[0], resultados_mortos[0], 
                   N_PERIODOS);
    
    // Simula cada cenário
    for (int i = 0; i < NUM_CENARIOS; i++) {
        printf("Simulando cenário %d: %s...\n", i + 1, CENARIOS[i].nome);
        simular_cenario(acidentes, n_acidentes, &CENARIOS[i], 
                       resultados_acidentes[i + 1], resultados_feridos[i + 1], resultados_mortos[i + 1], 
                       N_PERIODOS);
    }
    
    // Exibe resultados
    printf("\nComparação de Cenários para os Próximos %d Meses:\n\n", N_PERIODOS);
    
    // Calcula totais para cada cenário
    double totais_acidentes[NUM_CENARIOS + 1];
    double totais_feridos[NUM_CENARIOS + 1];
    double totais_mortos[NUM_CENARIOS + 1];
    
    for (int i = 0; i <= NUM_CENARIOS; i++) {
        totais_acidentes[i] = 0.0;
        totais_feridos[i] = 0.0;
        totais_mortos[i] = 0.0;
        
        for (int j = 0; j < N_PERIODOS; j++) {
            totais_acidentes[i] += resultados_acidentes[i][j];
            totais_feridos[i] += resultados_feridos[i][j];
            totais_mortos[i] += resultados_mortos[i][j];
        }
    }
    
    // Tabela comparativa de totais
    printf("Totais previstos para o período de %d meses:\n", N_PERIODOS);
    printf("%-20s | %-10s | %-10s | %-10s | %-15s\n",
           "Cenário", "Acidentes", "Feridos", "Mortos", "Custo (mil R$)");
    printf("----------------------+------------+------------+------------+-----------------\n");
    
    // Cenário base
    printf("%-20s | %-10.0f | %-10.0f | %-10.0f | %-15.2f\n",
           CENARIO_BASE.nome, totais_acidentes[0], totais_feridos[0], totais_mortos[0], 0.0);
    
    // Outros cenários
    for (int i = 0; i < NUM_CENARIOS; i++) {
        // Calcular custo para este cenário (assumindo 100km de rodovia)
        double custo = CENARIOS[i].custo_estimado * 100.0;
        
        printf("%-20s | %-10.0f | %-10.0f | %-10.0f | %-15.2f\n",
               CENARIOS[i].nome, totais_acidentes[i + 1], totais_feridos[i + 1], 
               totais_mortos[i + 1], custo);
    }
    
    // Comparação de reduções
    printf("\nRedução prevista em relação ao cenário base:\n");
    printf("%-20s | %-10s | %-10s | %-10s | %-15s\n",
           "Cenário", "Acidentes", "Feridos", "Mortos", "ROI Estimado");
    printf("----------------------+------------+------------+------------+-----------------\n");
    
    for (int i = 0; i < NUM_CENARIOS; i++) {
        // Calcula reduções
        int acid_reduzidos = (int)(totais_acidentes[0] - totais_acidentes[i + 1]);
        int fer_reduzidos = (int)(totais_feridos[0] - totais_feridos[i + 1]);
        int mort_reduzidos = (int)(totais_mortos[0] - totais_mortos[i + 1]);
        
        // Calcula ROI
        double custo = CENARIOS[i].custo_estimado * 100.0;
        double roi = calcular_roi(acid_reduzidos, fer_reduzidos, mort_reduzidos, custo);
        
        printf("%-20s | %-10d | %-10d | %-10d | %-15.2f\n",
               CENARIOS[i].nome, acid_reduzidos, fer_reduzidos, mort_reduzidos, roi);
    }
    
    // Preparar dados para gráfico comparativo
    const char *rotulos[N_PERIODOS];
    const char *nomes_meses[] = {
        "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
        "Jul", "Ago", "Set", "Out", "Nov", "Dez"
    };
    
    for (int i = 0; i < N_PERIODOS; i++) {
        rotulos[i] = nomes_meses[i % 12];
    }
    
    const char *nomes_cenarios[NUM_CENARIOS + 1];
    nomes_cenarios[0] = CENARIO_BASE.nome;
    for (int i = 0; i < NUM_CENARIOS; i++) {
        nomes_cenarios[i + 1] = CENARIOS[i].nome;
    }
    
    // Desenhar gráfico comparativo de acidentes
    printf("\n");
    desenhar_grafico_comparativo("Comparação de Acidentes por Cenário", 
                                rotulos, nomes_cenarios, resultados_acidentes, 
                                NUM_CENARIOS + 1, N_PERIODOS, 80);
    
    // Desenhar gráfico comparativo de mortos
    printf("\n");
    desenhar_grafico_comparativo("Comparação de Mortos por Cenário", 
                                rotulos, nomes_cenarios, resultados_mortos, 
                                NUM_CENARIOS + 1, N_PERIODOS, 80);
    
    // Conclusão
    printf("\nCONCLUSÕES DA ANÁLISE:\n");
    
    // Encontrar cenário com melhor ROI
    int melhor_roi_idx = 0;
    double melhor_roi = -1.0;
    
    for (int i = 0; i < NUM_CENARIOS; i++) {
        // Calcula reduções
        int acid_reduzidos = (int)(totais_acidentes[0] - totais_acidentes[i + 1]);
        int fer_reduzidos = (int)(totais_feridos[0] - totais_feridos[i + 1]);
        int mort_reduzidos = (int)(totais_mortos[0] - totais_mortos[i + 1]);
        
        // Calcula ROI
        double custo = CENARIOS[i].custo_estimado * 100.0;
        double roi = calcular_roi(acid_reduzidos, fer_reduzidos, mort_reduzidos, custo);
        
        if (roi > melhor_roi) {
            melhor_roi = roi;
            melhor_roi_idx = i;
        }
    }
    
    // Encontrar cenário com maior redução de mortos
    int melhor_mortos_idx = 0;
    double maior_reducao_mortos = -1.0;
    
    for (int i = 0; i < NUM_CENARIOS; i++) {
        double reducao = totais_mortos[0] - totais_mortos[i + 1];
        if (reducao > maior_reducao_mortos) {
            maior_reducao_mortos = reducao;
            melhor_mortos_idx = i;
        }
    }
    
    printf("1. Melhor cenário em termos de ROI: %s (ROI = %.2f)\n", 
           CENARIOS[melhor_roi_idx].nome, melhor_roi);
    printf("   %s\n", CENARIOS[melhor_roi_idx].descricao);
    
    printf("2. Melhor cenário para redução de mortes: %s (%.0f mortes evitadas)\n", 
           CENARIOS[melhor_mortos_idx].nome, maior_reducao_mortos);
    printf("   %s\n", CENARIOS[melhor_mortos_idx].descricao);
    
    // Se o cenário combinado está entre os analisados, ver se ele tem vantagens
    for (int i = 0; i < NUM_CENARIOS; i++) {
        if (strcmp(CENARIOS[i].nome, "Combinado") == 0) {
            printf("3. O cenário combinado %s oferece um equilíbrio entre custo e eficácia,\n", 
                   CENARIOS[i].nome);
            printf("   com ROI de %.2f e redução de %.0f mortes.\n", 
                   calcular_roi(
                       (int)(totais_acidentes[0] - totais_acidentes[i + 1]),
                       (int)(totais_feridos[0] - totais_feridos[i + 1]),
                       (int)(totais_mortos[0] - totais_mortos[i + 1]),
                       CENARIOS[i].custo_estimado * 100.0
                   ),
                   totais_mortos[0] - totais_mortos[i + 1]);
            break;
        }
    }
    
    // Libera memória
    for (int i = 0; i <= NUM_CENARIOS; i++) {
        free(resultados_acidentes[i]);
        free(resultados_feridos[i]);
        free(resultados_mortos[i]);
    }
    free(resultados_acidentes);
    free(resultados_feridos);
    free(resultados_mortos);
}