/**
 * machine_learning.h
 * 
 * Funções para aplicação de algoritmos de aprendizado de máquina
 * para previsão de acidentes de trânsito.
 */

#ifndef MACHINE_LEARNING_H
#define MACHINE_LEARNING_H

#include "../utils/tipos.h"

/**
 * Estrutura para armazenar modelo de regressão polinomial.
 */
typedef struct {
    int grau;              // Grau do polinômio
    double *coeficientes;  // Coeficientes do polinômio
    double erro_medio;     // Erro médio do modelo
} ModeloPolinomial;

/**
 * Estrutura para armazenar modelo de previsão ensemble.
 */
typedef struct {
    int n_modelos;         // Número de modelos no ensemble
    ModeloPolinomial *modelos;  // Array de modelos
    double *pesos;         // Pesos de cada modelo no ensemble
} ModeloEnsemble;

/**
 * Treina um modelo de regressão polinomial para prever acidentes.
 * 
 * @param x Array de valores independentes (períodos de tempo)
 * @param y Array de valores dependentes (número de acidentes)
 * @param n Número de pontos de dados
 * @param grau Grau do polinômio
 * @return Modelo polinomial treinado
 */
ModeloPolinomial treinar_modelo_polinomial(const double *x, const double *y, int n, int grau);

/**
 * Faz previsões usando um modelo polinomial.
 * 
 * @param modelo Modelo polinomial treinado
 * @param x Valor independente
 * @return Previsão para o valor x
 */
double prever_polinomial(const ModeloPolinomial *modelo, double x);

/**
 * Libera a memória alocada para um modelo polinomial.
 * 
 * @param modelo Modelo polinomial a ser liberado
 */
void liberar_modelo_polinomial(ModeloPolinomial *modelo);

/**
 * Treina um modelo ensemble combinando múltiplos modelos polinomiais
 * de diferentes graus.
 * 
 * @param x Array de valores independentes (períodos de tempo)
 * @param y Array de valores dependentes (número de acidentes)
 * @param n Número de pontos de dados
 * @param n_modelos Número de modelos a combinar
 * @param graus Array com os graus para cada modelo polinomial
 * @return Modelo ensemble treinado
 */
ModeloEnsemble treinar_modelo_ensemble(const double *x, const double *y, int n, 
                                       int n_modelos, const int *graus);

/**
 * Faz previsões usando um modelo ensemble.
 * 
 * @param modelo Modelo ensemble treinado
 * @param x Valor independente
 * @return Previsão para o valor x
 */
double prever_ensemble(const ModeloEnsemble *modelo, double x);

/**
 * Libera a memória alocada para um modelo ensemble.
 * 
 * @param modelo Modelo ensemble a ser liberado
 */
void liberar_modelo_ensemble(ModeloEnsemble *modelo);

/**
 * Realiza validação cruzada para encontrar o melhor modelo.
 * 
 * @param x Array de valores independentes (períodos de tempo)
 * @param y Array de valores dependentes (número de acidentes)
 * @param n Número de pontos de dados
 * @param k Número de folds para validação cruzada
 * @param max_grau Grau máximo a ser testado
 * @return Grau do melhor modelo encontrado
 */
int encontrar_melhor_modelo(const double *x, const double *y, int n, int k, int max_grau);

/**
 * Realiza previsões avançadas usando aprendizado de máquina.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada para os dados
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void prever_ml(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

#endif /* MACHINE_LEARNING_H */