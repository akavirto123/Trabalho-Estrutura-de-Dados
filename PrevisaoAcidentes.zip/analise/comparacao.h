/**
 * comparacao.h
 * 
 * Funções para comparação de múltiplos cenários de intervenção.
 */

#ifndef COMPARACAO_H
#define COMPARACAO_H

#include "../utils/tipos.h"

/**
 * Estrutura para armazenar um cenário de intervenção.
 */
typedef struct {
    char nome[100];              // Nome do cenário
    char descricao[200];         // Descrição detalhada do cenário
    double fator_reducao;        // Fator de redução de acidentes
    double fator_reducao_grave;  // Fator de redução de gravidade
    double custo_estimado;       // Custo estimado em milhares de R$
} Cenario;

/**
 * Realiza uma comparação entre múltiplos cenários de intervenção.
 * 
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void comparar_cenarios(Acidente *acidentes, int n_acidentes);

/**
 * Executa uma simulação para um cenário específico.
 * 
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 * @param cenario Cenário a ser simulado
 * @param resultado_acidentes Array para armazenar resultados de acidentes
 * @param resultado_feridos Array para armazenar resultados de feridos
 * @param resultado_mortos Array para armazenar resultados de mortos
 * @param n_periodos Número de períodos a simular
 */
void simular_cenario(Acidente *acidentes, int n_acidentes, const Cenario *cenario,
                    double *resultado_acidentes, double *resultado_feridos, 
                    double *resultado_mortos, int n_periodos);

/**
 * Calcula o retorno sobre investimento (ROI) de um cenário.
 * 
 * @param acidentes_evitados Quantidade de acidentes evitados
 * @param feridos_evitados Quantidade de feridos evitados
 * @param mortos_evitados Quantidade de mortos evitados
 * @param custo Custo da intervenção em milhares de R$
 * @return ROI estimado
 */
double calcular_roi(int acidentes_evitados, int feridos_evitados, int mortos_evitados, double custo);

#endif /* COMPARACAO_H */