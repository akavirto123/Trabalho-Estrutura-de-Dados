/**
 * previsao.h
 * 
 * Funções para previsão de tendências de acidentes de trânsito.
 */

#ifndef PREVISAO_H
#define PREVISAO_H

#include "../utils/tipos.h"

/**
 * Realiza previsões de tendências de acidentes usando a estrutura de dados especificada.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void prever_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Estima a quantidade de acidentes para os próximos meses com base em séries temporais.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void prever_quantidade_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Prevê a distribuição de acidentes por UF para o próximo período.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void prever_distribuicao_por_uf(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Prevê a distribuição de acidentes por rodovia (BR) para o próximo período.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void prever_distribuicao_por_rodovia(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Prevê a gravidade de acidentes para diferentes condições.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void prever_gravidade_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Identifica tendências temporais em acidentes (padrões sazonais, diários, etc.).
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void identificar_tendencias_temporais(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Simula o impacto de melhorias de segurança em pontos críticos.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void simular_impacto_melhorias(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Estrutura para armazenar resultados de previsão por tempo.
 */
typedef struct {
    int periodo;            // Período de tempo (mês, ano, etc.)
    double valor_previsto;  // Valor previsto para o período
    double intervalo_min;   // Limite inferior do intervalo de confiança
    double intervalo_max;   // Limite superior do intervalo de confiança
} PrevisaoTemporal;

/**
 * Implementa um modelo simples de regressão linear para previsão.
 * 
 * @param x Array com valores independentes (ex: meses)
 * @param y Array com valores dependentes (ex: número de acidentes)
 * @param n Número de pontos de dados
 * @param a Ponteiro para armazenar o coeficiente a (intercepto)
 * @param b Ponteiro para armazenar o coeficiente b (inclinação)
 * @param r2 Ponteiro para armazenar o coeficiente de determinação (R²)
 */
void regressao_linear(const double *x, const double *y, int n, double *a, double *b, double *r2);

/**
 * Implementa um modelo simples de média móvel para previsão.
 * 
 * @param y Array com valores históricos
 * @param n Número de pontos de dados
 * @param janela Tamanho da janela de média móvel
 * @param previsoes Array para armazenar as previsões
 * @param n_previsoes Número de períodos futuros a serem previstos
 */
void media_movel(const double *y, int n, int janela, double *previsoes, int n_previsoes);

/**
 * Implementa um modelo simples de sazonalidade para previsão.
 * 
 * @param y Array com valores históricos
 * @param n Número de pontos de dados
 * @param periodo Período de sazonalidade (ex: 12 para mensal)
 * @param previsoes Array para armazenar as previsões
 * @param n_previsoes Número de períodos futuros a serem previstos
 */
void modelo_sazonal(const double *y, int n, int periodo, double *previsoes, int n_previsoes);

/**
 * Define se a simulação mês a mês será ativada automaticamente
 * 
 * @param ativar 1 para ativar, 0 para desativar
 */
void setSimulacaoMesAMes(int ativar);

/**
 * Obtém o estado atual da simulação mês a mês
 * 
 * @return 1 se ativada, 0 se desativada
 */
int getSimulacaoMesAMes(void);

#endif /* PREVISAO_H */
