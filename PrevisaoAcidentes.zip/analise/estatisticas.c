/**
 * estatisticas.c
 * 
 * Implementação de funções para análise estatística dos dados de acidentes de trânsito.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "estatisticas.h"
#include "../estruturas/lista_encadeada.h"
#include "../estruturas/arvore_avl.h"
#include "../estruturas/tabela_hash.h"
#include "../estruturas/skiplist.h"
#include "../estruturas/trie.h"

// Número máximo de UFs, BRs, tipos de acidente, etc.
#define MAX_UF 30
#define MAX_BR 50
#define MAX_TIPOS 30
#define MAX_FASE_DIA 5
#define MAX_COND_METEO 10
#define MAX_MESES 12
#define MAX_DIAS_SEMANA 7

// Limite para considerar um trecho como ponto crítico (número mínimo de acidentes)
#define LIMITE_PONTO_CRITICO 5

// Estrutura para armazenar contagens por categoria
typedef struct {
    char nome[100];
    int acidentes;
    int feridos;
    int mortos;
    int veiculos;
} ContadorCategoria;

// Estrutura para armazenar informações sobre um ponto crítico
typedef struct {
    char uf[3];
    char br[10];
    double km_inicio;
    double km_fim;
    int acidentes;
    int feridos;
    int mortos;
    double indice_gravidade;
} PontoCritico;

// Funções auxiliares

// Função para ordenar valores (usada para calcular mediana e quartis)
static int comparar_double(const void *a, const void *b) {
    double va = *(const double*)a;
    double vb = *(const double*)b;
    return (va > vb) - (va < vb);
}

// Função para ordenar contadores de categoria por número de acidentes (decrescente)
static int comparar_contadores(const void *a, const void *b) {
    ContadorCategoria *ca = (ContadorCategoria*)a;
    ContadorCategoria *cb = (ContadorCategoria*)b;
    return cb->acidentes - ca->acidentes;
}

// Função para ordenar pontos críticos por índice de gravidade (decrescente)
static int comparar_pontos_criticos(const void *a, const void *b) {
    PontoCritico *pa = (PontoCritico*)a;
    PontoCritico *pb = (PontoCritico*)b;
    return (pb->indice_gravidade > pa->indice_gravidade) - 
           (pb->indice_gravidade < pa->indice_gravidade);
}

// Implementação das funções públicas

void calcular_estatisticas(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n=== ANÁLISE ESTATÍSTICA DOS ACIDENTES ===\n\n");
    
    printf("Utilizando estrutura: ");
    switch (estrutura) {
        case LISTA_ENCADEADA: printf("Lista Encadeada\n"); break;
        case ARVORE_AVL: printf("Árvore AVL\n"); break;
        case TABELA_HASH: printf("Tabela Hash\n"); break;
        case SKIPLIST: printf("Skip List\n"); break;
        case TRIE: printf("Trie\n"); break;
        default: printf("Desconhecida\n"); break;
    }
    
    // Estatísticas gerais
    printf("\n--- Estatísticas Gerais ---\n");
    
    int total_acidentes = n_acidentes;
    int total_feridos = 0;
    int total_mortos = 0;
    int total_veiculos = 0;
    
    for (int i = 0; i < n_acidentes; i++) {
        total_feridos += acidentes[i].condicoes.feridos;
        total_mortos += acidentes[i].condicoes.mortos;
        total_veiculos += acidentes[i].condicoes.veiculos;
    }
    
    printf("Total de acidentes: %d\n", total_acidentes);
    printf("Total de feridos: %d (média de %.2f por acidente)\n", 
           total_feridos, (float)total_feridos / total_acidentes);
    printf("Total de mortos: %d (média de %.2f por acidente)\n", 
           total_mortos, (float)total_mortos / total_acidentes);
    printf("Total de veículos envolvidos: %d (média de %.2f por acidente)\n", 
           total_veiculos, (float)total_veiculos / total_acidentes);
    
    // Taxa de letalidade (mortos / envolvidos)
    int total_envolvidos = 0;
    for (int i = 0; i < n_acidentes; i++) {
        total_envolvidos += acidentes[i].condicoes.pessoas_envolvidas;
    }
    
    float letalidade = (float)total_mortos / total_envolvidos * 100.0;
    printf("Taxa de letalidade: %.2f%%\n", letalidade);
    
    // Menu de opções para análises específicas
    int opcao;
    do {
        printf("\nEscolha o tipo de estatística a visualizar:\n");
        printf("1. Estatísticas por UF\n");
        printf("2. Estatísticas por Rodovia (BR)\n");
        printf("3. Estatísticas por Tipo de Acidente\n");
        printf("4. Estatísticas por Fase do Dia\n");
        printf("5. Estatísticas por Condição Meteorológica\n");
        printf("6. Estatísticas Temporais (mês e dia da semana)\n");
        printf("7. Índices de Gravidade\n");
        printf("8. Identificação de Pontos Críticos\n");
        printf("0. Voltar ao menu principal\n");
        printf("Opção: ");
        scanf("%d", &opcao);
        
        switch (opcao) {
            case 1:
                estatisticas_por_uf(estrutura, acidentes, n_acidentes);
                break;
            case 2:
                estatisticas_por_rodovia(estrutura, acidentes, n_acidentes);
                break;
            case 3:
                estatisticas_por_tipo(estrutura, acidentes, n_acidentes);
                break;
            case 4:
                estatisticas_por_fase_dia(estrutura, acidentes, n_acidentes);
                break;
            case 5:
                estatisticas_por_condicao_meteo(estrutura, acidentes, n_acidentes);
                break;
            case 6:
                estatisticas_temporais(estrutura, acidentes, n_acidentes);
                break;
            case 7:
                indices_gravidade(estrutura, acidentes, n_acidentes);
                break;
            case 8:
                identificar_pontos_criticos(estrutura, acidentes, n_acidentes);
                break;
            case 0:
                printf("Voltando ao menu principal...\n");
                break;
            default:
                printf("Opção inválida!\n");
                break;
        }
    } while (opcao != 0);
}

EstatisticasBasicas calcular_estatisticas_basicas(double *valores, int n_valores) {
    EstatisticasBasicas stats;
    
    if (!valores || n_valores <= 0) {
        stats.total = 0;
        stats.media = 0;
        stats.mediana = 0;
        stats.desvio_padrao = 0;
        stats.minimo = 0;
        stats.maximo = 0;
        stats.quartil_1 = 0;
        stats.quartil_3 = 0;
        return stats;
    }
    
    // Copia os valores para um array temporário e ordena
    double *temp = (double*)malloc(n_valores * sizeof(double));
    if (!temp) {
        stats.total = 0;
        return stats;
    }
    
    memcpy(temp, valores, n_valores * sizeof(double));
    qsort(temp, n_valores, sizeof(double), comparar_double);
    
    // Calcula estatísticas básicas
    stats.total = n_valores;
    
    // Média
    double soma = 0;
    for (int i = 0; i < n_valores; i++) {
        soma += temp[i];
    }
    stats.media = soma / n_valores;
    
    // Mediana
    if (n_valores % 2 == 0) {
        stats.mediana = (temp[n_valores/2 - 1] + temp[n_valores/2]) / 2.0;
    } else {
        stats.mediana = temp[n_valores/2];
    }
    
    // Desvio padrão
    double soma_quadrados = 0;
    for (int i = 0; i < n_valores; i++) {
        soma_quadrados += (temp[i] - stats.media) * (temp[i] - stats.media);
    }
    stats.desvio_padrao = sqrt(soma_quadrados / n_valores);
    
    // Mínimo e máximo
    stats.minimo = temp[0];
    stats.maximo = temp[n_valores - 1];
    
    // Quartis
    int pos_q1 = n_valores / 4;
    int pos_q3 = (3 * n_valores) / 4;
    
    if (n_valores % 4 == 0) {
        stats.quartil_1 = (temp[pos_q1 - 1] + temp[pos_q1]) / 2.0;
        stats.quartil_3 = (temp[pos_q3 - 1] + temp[pos_q3]) / 2.0;
    } else {
        stats.quartil_1 = temp[pos_q1];
        stats.quartil_3 = temp[pos_q3];
    }
    
    free(temp);
    return stats;
}

void estatisticas_por_uf(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Estatísticas por UF ---\n");
    
    // Cria contadores para cada UF
    ContadorCategoria ufs[MAX_UF];
    int n_ufs = 0;
    
    // Inicializa array
    memset(ufs, 0, sizeof(ufs));
    
    // Conta acidentes por UF
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a UF já está na lista
        int uf_idx = -1;
        for (int j = 0; j < n_ufs; j++) {
            if (strcmp(ufs[j].nome, acidentes[i].local.uf) == 0) {
                uf_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (uf_idx == -1) {
            if (n_ufs >= MAX_UF) {
                continue;  // Lista cheia, ignora
            }
            uf_idx = n_ufs++;
            strncpy(ufs[uf_idx].nome, acidentes[i].local.uf, sizeof(ufs[uf_idx].nome) - 1);
        }
        
        // Incrementa contadores
        ufs[uf_idx].acidentes++;
        ufs[uf_idx].feridos += acidentes[i].condicoes.feridos;
        ufs[uf_idx].mortos += acidentes[i].condicoes.mortos;
        ufs[uf_idx].veiculos += acidentes[i].condicoes.veiculos;
    }
    
    // Ordena por número de acidentes (decrescente)
    qsort(ufs, n_ufs, sizeof(ContadorCategoria), comparar_contadores);
    
    // Exibe resultados
    printf("%-5s | %-10s | %-10s | %-10s | %-10s | %-15s | %-15s\n",
           "UF", "Acidentes", "Feridos", "Mortos", "Veículos", "Acid/Veíc", "Mortos/Acid");
    printf("------+------------+------------+------------+------------+-----------------+----------------\n");
    
    for (int i = 0; i < n_ufs; i++) {
        float acid_veic = ufs[i].veiculos > 0 ? (float)ufs[i].acidentes / ufs[i].veiculos : 0;
        float mort_acid = ufs[i].acidentes > 0 ? (float)ufs[i].mortos / ufs[i].acidentes : 0;
        
        printf("%-5s | %-10d | %-10d | %-10d | %-10d | %-15.2f | %-15.2f\n",
               ufs[i].nome, ufs[i].acidentes, ufs[i].feridos, ufs[i].mortos, 
               ufs[i].veiculos, acid_veic, mort_acid);
    }
    
    // Calcula estatísticas de acidentes por UF
    double valores[MAX_UF];
    for (int i = 0; i < n_ufs; i++) {
        valores[i] = ufs[i].acidentes;
    }
    
    EstatisticasBasicas stats = calcular_estatisticas_basicas(valores, n_ufs);
    
    printf("\nEstatísticas de acidentes por UF:\n");
    printf("Total de UFs: %d\n", stats.total);
    printf("Média de acidentes por UF: %.2f\n", stats.media);
    printf("Mediana: %.2f\n", stats.mediana);
    printf("Desvio padrão: %.2f\n", stats.desvio_padrao);
    printf("Mínimo: %.0f acidentes\n", stats.minimo);
    printf("Máximo: %.0f acidentes\n", stats.maximo);
    printf("Primeiro quartil (Q1): %.2f\n", stats.quartil_1);
    printf("Terceiro quartil (Q3): %.2f\n", stats.quartil_3);
}

void estatisticas_por_rodovia(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Estatísticas por Rodovia (BR) ---\n");
    
    // Cria contadores para cada BR
    ContadorCategoria brs[MAX_BR];
    int n_brs = 0;
    
    // Inicializa array
    memset(brs, 0, sizeof(brs));
    
    // Conta acidentes por BR
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a BR já está na lista
        int br_idx = -1;
        for (int j = 0; j < n_brs; j++) {
            if (strcmp(brs[j].nome, acidentes[i].local.br) == 0) {
                br_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (br_idx == -1) {
            if (n_brs >= MAX_BR) {
                continue;  // Lista cheia, ignora
            }
            br_idx = n_brs++;
            strncpy(brs[br_idx].nome, acidentes[i].local.br, sizeof(brs[br_idx].nome) - 1);
        }
        
        // Incrementa contadores
        brs[br_idx].acidentes++;
        brs[br_idx].feridos += acidentes[i].condicoes.feridos;
        brs[br_idx].mortos += acidentes[i].condicoes.mortos;
        brs[br_idx].veiculos += acidentes[i].condicoes.veiculos;
    }
    
    // Ordena por número de acidentes (decrescente)
    qsort(brs, n_brs, sizeof(ContadorCategoria), comparar_contadores);
    
    // Exibe resultados
    printf("%-10s | %-10s | %-10s | %-10s | %-10s | %-15s\n",
           "BR", "Acidentes", "Feridos", "Mortos", "Veículos", "Índice Gravidade");
    printf("------------+------------+------------+------------+------------+----------------\n");
    
    for (int i = 0; i < n_brs && i < 15; i++) {  // Mostra apenas as 15 BRs com mais acidentes
        float indice_grav = (float)(brs[i].feridos + 5 * brs[i].mortos) / brs[i].acidentes;
        
        printf("%-10s | %-10d | %-10d | %-10d | %-10d | %-15.2f\n",
               brs[i].nome, brs[i].acidentes, brs[i].feridos, brs[i].mortos, 
               brs[i].veiculos, indice_grav);
    }
    
    // Calcula estatísticas de acidentes por BR
    double valores[MAX_BR];
    for (int i = 0; i < n_brs; i++) {
        valores[i] = brs[i].acidentes;
    }
    
    EstatisticasBasicas stats = calcular_estatisticas_basicas(valores, n_brs);
    
    printf("\nEstatísticas de acidentes por BR:\n");
    printf("Total de BRs: %d\n", stats.total);
    printf("Média de acidentes por BR: %.2f\n", stats.media);
    printf("Mediana: %.2f\n", stats.mediana);
    printf("Desvio padrão: %.2f\n", stats.desvio_padrao);
    printf("Mínimo: %.0f acidentes\n", stats.minimo);
    printf("Máximo: %.0f acidentes\n", stats.maximo);
}

void estatisticas_por_tipo(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Estatísticas por Tipo de Acidente ---\n");
    
    // Cria contadores para cada tipo
    ContadorCategoria tipos[MAX_TIPOS];
    int n_tipos = 0;
    
    // Inicializa array
    memset(tipos, 0, sizeof(tipos));
    
    // Conta acidentes por tipo
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se o tipo já está na lista
        int tipo_idx = -1;
        for (int j = 0; j < n_tipos; j++) {
            if (strcmp(tipos[j].nome, acidentes[i].condicoes.classificacao) == 0) {
                tipo_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (tipo_idx == -1) {
            if (n_tipos >= MAX_TIPOS) {
                continue;  // Lista cheia, ignora
            }
            tipo_idx = n_tipos++;
            strncpy(tipos[tipo_idx].nome, acidentes[i].condicoes.classificacao, sizeof(tipos[tipo_idx].nome) - 1);
        }
        
        // Incrementa contadores
        tipos[tipo_idx].acidentes++;
        tipos[tipo_idx].feridos += acidentes[i].condicoes.feridos;
        tipos[tipo_idx].mortos += acidentes[i].condicoes.mortos;
        tipos[tipo_idx].veiculos += acidentes[i].condicoes.veiculos;
    }
    
    // Ordena por número de acidentes (decrescente)
    qsort(tipos, n_tipos, sizeof(ContadorCategoria), comparar_contadores);
    
    // Exibe resultados
    printf("%-25s | %-10s | %-10s | %-10s | %-15s | %-15s\n",
           "Tipo de Acidente", "Acidentes", "Feridos", "Mortos", "Feridos/Acid", "Mortos/Acid");
    printf("---------------------------+------------+------------+------------+-----------------+----------------\n");
    
    for (int i = 0; i < n_tipos; i++) {
        float feridos_acid = tipos[i].acidentes > 0 ? (float)tipos[i].feridos / tipos[i].acidentes : 0;
        float mortos_acid = tipos[i].acidentes > 0 ? (float)tipos[i].mortos / tipos[i].acidentes : 0;
        
        printf("%-25s | %-10d | %-10d | %-10d | %-15.2f | %-15.2f\n",
               tipos[i].nome, tipos[i].acidentes, tipos[i].feridos, tipos[i].mortos, 
               feridos_acid, mortos_acid);
    }
    
    // Calcula o percentual de cada tipo em relação ao total
    printf("\nDistribuição percentual por tipo de acidente:\n");
    for (int i = 0; i < n_tipos && i < 5; i++) {  // Mostra apenas os 5 tipos mais comuns
        float percentual = (float)tipos[i].acidentes / n_acidentes * 100.0;
        printf("%-25s: %.2f%%\n", tipos[i].nome, percentual);
    }
}

void estatisticas_por_fase_dia(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Estatísticas por Fase do Dia ---\n");
    
    // Cria contadores para cada fase do dia
    ContadorCategoria fases[MAX_FASE_DIA];
    int n_fases = 0;
    
    // Inicializa array
    memset(fases, 0, sizeof(fases));
    
    // Conta acidentes por fase do dia
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a fase já está na lista
        int fase_idx = -1;
        for (int j = 0; j < n_fases; j++) {
            if (strcmp(fases[j].nome, acidentes[i].condicoes.fase_dia) == 0) {
                fase_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (fase_idx == -1) {
            if (n_fases >= MAX_FASE_DIA) {
                continue;  // Lista cheia, ignora
            }
            fase_idx = n_fases++;
            strncpy(fases[fase_idx].nome, acidentes[i].condicoes.fase_dia, sizeof(fases[fase_idx].nome) - 1);
        }
        
        // Incrementa contadores
        fases[fase_idx].acidentes++;
        fases[fase_idx].feridos += acidentes[i].condicoes.feridos;
        fases[fase_idx].mortos += acidentes[i].condicoes.mortos;
        fases[fase_idx].veiculos += acidentes[i].condicoes.veiculos;
    }
    
    // Ordena por número de acidentes (decrescente)
    qsort(fases, n_fases, sizeof(ContadorCategoria), comparar_contadores);
    
    // Exibe resultados
    printf("%-15s | %-10s | %-10s | %-10s | %-15s | %-15s\n",
           "Fase do Dia", "Acidentes", "Feridos", "Mortos", "Feridos/Acid", "Mortos/Acid");
    printf("-----------------+------------+------------+------------+-----------------+----------------\n");
    
    for (int i = 0; i < n_fases; i++) {
        float feridos_acid = fases[i].acidentes > 0 ? (float)fases[i].feridos / fases[i].acidentes : 0;
        float mortos_acid = fases[i].acidentes > 0 ? (float)fases[i].mortos / fases[i].acidentes : 0;
        
        printf("%-15s | %-10d | %-10d | %-10d | %-15.2f | %-15.2f\n",
               fases[i].nome, fases[i].acidentes, fases[i].feridos, fases[i].mortos, 
               feridos_acid, mortos_acid);
    }
    
    // Calcula o percentual de cada fase em relação ao total
    printf("\nDistribuição percentual por fase do dia:\n");
    for (int i = 0; i < n_fases; i++) {
        float percentual = (float)fases[i].acidentes / n_acidentes * 100.0;
        printf("%-15s: %.2f%%\n", fases[i].nome, percentual);
    }
}

void estatisticas_por_condicao_meteo(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Estatísticas por Condição Meteorológica ---\n");
    
    // Cria contadores para cada condição meteorológica
    ContadorCategoria condicoes[MAX_COND_METEO];
    int n_condicoes = 0;
    
    // Inicializa array
    memset(condicoes, 0, sizeof(condicoes));
    
    // Conta acidentes por condição meteorológica
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a condição já está na lista
        int cond_idx = -1;
        for (int j = 0; j < n_condicoes; j++) {
            if (strcmp(condicoes[j].nome, acidentes[i].condicoes.condicao_meteo) == 0) {
                cond_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (cond_idx == -1) {
            if (n_condicoes >= MAX_COND_METEO) {
                continue;  // Lista cheia, ignora
            }
            cond_idx = n_condicoes++;
            strncpy(condicoes[cond_idx].nome, acidentes[i].condicoes.condicao_meteo, sizeof(condicoes[cond_idx].nome) - 1);
        }
        
        // Incrementa contadores
        condicoes[cond_idx].acidentes++;
        condicoes[cond_idx].feridos += acidentes[i].condicoes.feridos;
        condicoes[cond_idx].mortos += acidentes[i].condicoes.mortos;
        condicoes[cond_idx].veiculos += acidentes[i].condicoes.veiculos;
    }
    
    // Ordena por número de acidentes (decrescente)
    qsort(condicoes, n_condicoes, sizeof(ContadorCategoria), comparar_contadores);
    
    // Exibe resultados
    printf("%-20s | %-10s | %-10s | %-10s | %-15s\n",
           "Condição Meteo", "Acidentes", "Feridos", "Mortos", "Gravidade");
    printf("----------------------+------------+------------+------------+----------------\n");
    
    for (int i = 0; i < n_condicoes; i++) {
        float gravidade = condicoes[i].acidentes > 0 ? 
                        (float)(condicoes[i].feridos + 5 * condicoes[i].mortos) / condicoes[i].acidentes : 0;
        
        printf("%-20s | %-10d | %-10d | %-10d | %-15.2f\n",
               condicoes[i].nome, condicoes[i].acidentes, condicoes[i].feridos, condicoes[i].mortos, gravidade);
    }
    
    // Calcula o percentual de cada condição em relação ao total
    printf("\nDistribuição percentual por condição meteorológica:\n");
    for (int i = 0; i < n_condicoes; i++) {
        float percentual = (float)condicoes[i].acidentes / n_acidentes * 100.0;
        printf("%-20s: %.2f%%\n", condicoes[i].nome, percentual);
    }
}

void estatisticas_temporais(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Estatísticas Temporais ---\n");
    
    // Contadores por mês
    int acidentes_por_mes[MAX_MESES] = {0};
    int feridos_por_mes[MAX_MESES] = {0};
    int mortos_por_mes[MAX_MESES] = {0};
    
    // Contadores por hora do dia
    int acidentes_por_hora[24] = {0};
    int feridos_por_hora[24] = {0};
    int mortos_por_hora[24] = {0};
    
    // Preenche os contadores
    for (int i = 0; i < n_acidentes; i++) {
        int mes = acidentes[i].data.mes - 1;  // Ajusta para índice 0-11
        if (mes >= 0 && mes < MAX_MESES) {
            acidentes_por_mes[mes]++;
            feridos_por_mes[mes] += acidentes[i].condicoes.feridos;
            mortos_por_mes[mes] += acidentes[i].condicoes.mortos;
        }
        
        int hora = acidentes[i].horario.hora;
        if (hora >= 0 && hora < 24) {
            acidentes_por_hora[hora]++;
            feridos_por_hora[hora] += acidentes[i].condicoes.feridos;
            mortos_por_hora[hora] += acidentes[i].condicoes.mortos;
        }
    }
    
    // Exibe estatísticas por mês
    printf("\n-- Acidentes por Mês --\n");
    printf("%-10s | %-10s | %-10s | %-10s | %-15s\n",
           "Mês", "Acidentes", "Feridos", "Mortos", "Gravidade");
    printf("------------+------------+------------+------------+----------------\n");
    
    const char *nomes_meses[] = {
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    };
    
    for (int i = 0; i < MAX_MESES; i++) {
        float gravidade = acidentes_por_mes[i] > 0 ? 
                        (float)(feridos_por_mes[i] + 5 * mortos_por_mes[i]) / acidentes_por_mes[i] : 0;
        
        printf("%-10s | %-10d | %-10d | %-10d | %-15.2f\n",
               nomes_meses[i], acidentes_por_mes[i], feridos_por_mes[i], mortos_por_mes[i], gravidade);
    }
    
    // Exibe estatísticas por hora do dia
    printf("\n-- Acidentes por Hora do Dia --\n");
    printf("%-10s | %-10s | %-10s | %-10s | %-15s\n",
           "Hora", "Acidentes", "Feridos", "Mortos", "Gravidade");
    printf("------------+------------+------------+------------+----------------\n");
    
    for (int i = 0; i < 24; i++) {
        float gravidade = acidentes_por_hora[i] > 0 ? 
                        (float)(feridos_por_hora[i] + 5 * mortos_por_hora[i]) / acidentes_por_hora[i] : 0;
        
        printf("%-10d | %-10d | %-10d | %-10d | %-15.2f\n",
               i, acidentes_por_hora[i], feridos_por_hora[i], mortos_por_hora[i], gravidade);
    }
    
    // Identifica os horários mais perigosos (com maior índice de gravidade)
    printf("\nHorários mais perigosos (maior índice de gravidade):\n");
    
    typedef struct {
        int hora;
        float gravidade;
    } HoraGravidade;
    
    HoraGravidade horas_gravidade[24];
    
    for (int i = 0; i < 24; i++) {
        horas_gravidade[i].hora = i;
        horas_gravidade[i].gravidade = acidentes_por_hora[i] > 0 ? 
                                    (float)(feridos_por_hora[i] + 5 * mortos_por_hora[i]) / acidentes_por_hora[i] : 0;
    }
    
    // Ordena por gravidade (decrescente)
    for (int i = 0; i < 24; i++) {
        for (int j = i + 1; j < 24; j++) {
            if (horas_gravidade[j].gravidade > horas_gravidade[i].gravidade) {
                HoraGravidade temp = horas_gravidade[i];
                horas_gravidade[i] = horas_gravidade[j];
                horas_gravidade[j] = temp;
            }
        }
    }
    
    // Exibe os 5 horários mais perigosos
    for (int i = 0; i < 5; i++) {
        printf("%dh - Índice de gravidade: %.2f\n", 
               horas_gravidade[i].hora, horas_gravidade[i].gravidade);
    }
}

void indices_gravidade(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Índices de Gravidade dos Acidentes ---\n");
    
    // Calcula índices por UF e BR
    printf("\n-- Índices de Gravidade por UF --\n");
    
    // Cria e inicializa estrutura de dados para cada UF
    typedef struct {
        char uf[3];
        int acidentes;
        int feridos;
        int mortos;
        float indice_gravidade;
        float taxa_mortalidade;
    } IndiceUF;
    
    IndiceUF indices_uf[MAX_UF];
    int n_ufs = 0;
    
    // Inicializa array
    memset(indices_uf, 0, sizeof(indices_uf));
    
    // Preenche os dados por UF
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se a UF já está na lista
        int uf_idx = -1;
        for (int j = 0; j < n_ufs; j++) {
            if (strcmp(indices_uf[j].uf, acidentes[i].local.uf) == 0) {
                uf_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (uf_idx == -1) {
            if (n_ufs >= MAX_UF) {
                continue;  // Lista cheia, ignora
            }
            uf_idx = n_ufs++;
            strncpy(indices_uf[uf_idx].uf, acidentes[i].local.uf, sizeof(indices_uf[uf_idx].uf) - 1);
        }
        
        // Incrementa contadores
        indices_uf[uf_idx].acidentes++;
        indices_uf[uf_idx].feridos += acidentes[i].condicoes.feridos;
        indices_uf[uf_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Calcula índices
    for (int i = 0; i < n_ufs; i++) {
        indices_uf[i].indice_gravidade = (float)(indices_uf[i].feridos + 5 * indices_uf[i].mortos) / indices_uf[i].acidentes;
        indices_uf[i].taxa_mortalidade = (float)indices_uf[i].mortos / indices_uf[i].acidentes * 100.0;
    }
    
    // Ordena por índice de gravidade (decrescente)
    for (int i = 0; i < n_ufs; i++) {
        for (int j = i + 1; j < n_ufs; j++) {
            if (indices_uf[j].indice_gravidade > indices_uf[i].indice_gravidade) {
                IndiceUF temp = indices_uf[i];
                indices_uf[i] = indices_uf[j];
                indices_uf[j] = temp;
            }
        }
    }
    
    // Exibe resultados
    printf("%-5s | %-10s | %-10s | %-10s | %-15s | %-15s\n",
           "UF", "Acidentes", "Feridos", "Mortos", "Índ. Gravidade", "Taxa Mortalidade");
    printf("------+------------+------------+------------+-----------------+------------------\n");
    
    for (int i = 0; i < n_ufs; i++) {
        printf("%-5s | %-10d | %-10d | %-10d | %-15.2f | %-15.2f%%\n",
               indices_uf[i].uf, indices_uf[i].acidentes, indices_uf[i].feridos, 
               indices_uf[i].mortos, indices_uf[i].indice_gravidade, indices_uf[i].taxa_mortalidade);
    }
    
    // Análise por tipo de acidente e gravidade
    printf("\n-- Tipos de Acidentes com Maior Gravidade --\n");
    
    // Cria e inicializa estrutura de dados para cada tipo
    typedef struct {
        char tipo[100];
        int acidentes;
        int feridos;
        int mortos;
        float indice_gravidade;
    } IndiceTipo;
    
    IndiceTipo indices_tipo[MAX_TIPOS];
    int n_tipos = 0;
    
    // Inicializa array
    memset(indices_tipo, 0, sizeof(indices_tipo));
    
    // Preenche os dados por tipo
    for (int i = 0; i < n_acidentes; i++) {
        // Procura se o tipo já está na lista
        int tipo_idx = -1;
        for (int j = 0; j < n_tipos; j++) {
            if (strcmp(indices_tipo[j].tipo, acidentes[i].condicoes.classificacao) == 0) {
                tipo_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (tipo_idx == -1) {
            if (n_tipos >= MAX_TIPOS) {
                continue;  // Lista cheia, ignora
            }
            tipo_idx = n_tipos++;
            strncpy(indices_tipo[tipo_idx].tipo, acidentes[i].condicoes.classificacao, sizeof(indices_tipo[tipo_idx].tipo) - 1);
        }
        
        // Incrementa contadores
        indices_tipo[tipo_idx].acidentes++;
        indices_tipo[tipo_idx].feridos += acidentes[i].condicoes.feridos;
        indices_tipo[tipo_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Calcula índices
    for (int i = 0; i < n_tipos; i++) {
        if (indices_tipo[i].acidentes < 10) {
            // Ignore tipos com poucos acidentes para evitar distorções estatísticas
            indices_tipo[i].indice_gravidade = 0;
            continue;
        }
        indices_tipo[i].indice_gravidade = (float)(indices_tipo[i].feridos + 5 * indices_tipo[i].mortos) / indices_tipo[i].acidentes;
    }
    
    // Ordena por índice de gravidade (decrescente)
    for (int i = 0; i < n_tipos; i++) {
        for (int j = i + 1; j < n_tipos; j++) {
            if (indices_tipo[j].indice_gravidade > indices_tipo[i].indice_gravidade) {
                IndiceTipo temp = indices_tipo[i];
                indices_tipo[i] = indices_tipo[j];
                indices_tipo[j] = temp;
            }
        }
    }
    
    // Exibe resultados
    printf("%-25s | %-10s | %-10s | %-10s | %-15s\n",
           "Tipo de Acidente", "Acidentes", "Feridos", "Mortos", "Índ. Gravidade");
    printf("---------------------------+------------+------------+------------+----------------\n");
    
    for (int i = 0; i < n_tipos && indices_tipo[i].indice_gravidade > 0; i++) {
        printf("%-25s | %-10d | %-10d | %-10d | %-15.2f\n",
               indices_tipo[i].tipo, indices_tipo[i].acidentes, indices_tipo[i].feridos, 
               indices_tipo[i].mortos, indices_tipo[i].indice_gravidade);
    }
}

void identificar_pontos_criticos(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n--- Identificação de Pontos Críticos ---\n");
    
    // Estrutura para armazenar informações sobre um trecho de rodovia
    typedef struct {
        char uf[3];
        char br[10];
        double km_inicio;
        double km_fim;
        int acidentes;
        int feridos;
        int mortos;
    } TrechoRodovia;
    
    // Segmenta as rodovias em trechos de 5km
    const double TAMANHO_TRECHO = 5.0;  // km
    
    // Cria um mapa de trechos (simplificado, em uma aplicação real usaríamos uma hash)
    TrechoRodovia trechos[1000];  // Limita a 1000 trechos diferentes
    int n_trechos = 0;
    
    // Inicializa array
    memset(trechos, 0, sizeof(trechos));
    
    // Analisa cada acidente e agrupa por trecho
    for (int i = 0; i < n_acidentes; i++) {
        // Calcula o início do trecho
        double km_inicio = floor(acidentes[i].local.km / TAMANHO_TRECHO) * TAMANHO_TRECHO;
        double km_fim = km_inicio + TAMANHO_TRECHO;
        
        // Procura se o trecho já está na lista
        int trecho_idx = -1;
        for (int j = 0; j < n_trechos; j++) {
            if (strcmp(trechos[j].uf, acidentes[i].local.uf) == 0 &&
                strcmp(trechos[j].br, acidentes[i].local.br) == 0 &&
                trechos[j].km_inicio == km_inicio) {
                trecho_idx = j;
                break;
            }
        }
        
        // Se não está na lista, adiciona
        if (trecho_idx == -1) {
            if (n_trechos >= 1000) {
                continue;  // Lista cheia, ignora
            }
            trecho_idx = n_trechos++;
            strncpy(trechos[trecho_idx].uf, acidentes[i].local.uf, sizeof(trechos[trecho_idx].uf) - 1);
            strncpy(trechos[trecho_idx].br, acidentes[i].local.br, sizeof(trechos[trecho_idx].br) - 1);
            trechos[trecho_idx].km_inicio = km_inicio;
            trechos[trecho_idx].km_fim = km_fim;
        }
        
        // Incrementa contadores
        trechos[trecho_idx].acidentes++;
        trechos[trecho_idx].feridos += acidentes[i].condicoes.feridos;
        trechos[trecho_idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Filtra apenas os trechos com número significativo de acidentes
    PontoCritico pontos_criticos[100];  // Limita a 100 pontos críticos
    int n_pontos = 0;
    
    for (int i = 0; i < n_trechos; i++) {
        if (trechos[i].acidentes >= LIMITE_PONTO_CRITICO) {
            if (n_pontos >= 100) {
                continue;  // Lista cheia, ignora
            }
            
            // Copia os dados para a estrutura de ponto crítico
            strncpy(pontos_criticos[n_pontos].uf, trechos[i].uf, sizeof(pontos_criticos[n_pontos].uf) - 1);
            strncpy(pontos_criticos[n_pontos].br, trechos[i].br, sizeof(pontos_criticos[n_pontos].br) - 1);
            pontos_criticos[n_pontos].km_inicio = trechos[i].km_inicio;
            pontos_criticos[n_pontos].km_fim = trechos[i].km_fim;
            pontos_criticos[n_pontos].acidentes = trechos[i].acidentes;
            pontos_criticos[n_pontos].feridos = trechos[i].feridos;
            pontos_criticos[n_pontos].mortos = trechos[i].mortos;
            
            // Calcula o índice de gravidade
            pontos_criticos[n_pontos].indice_gravidade = 
                (float)(trechos[i].feridos + 5 * trechos[i].mortos) / trechos[i].acidentes;
            
            n_pontos++;
        }
    }
    
    // Ordena os pontos críticos por índice de gravidade
    qsort(pontos_criticos, n_pontos, sizeof(PontoCritico), comparar_pontos_criticos);
    
    // Exibe os pontos críticos
    printf("Identificados %d pontos críticos (trechos com pelo menos %d acidentes).\n\n", 
           n_pontos, LIMITE_PONTO_CRITICO);
    
    printf("%-5s | %-6s | %-12s | %-10s | %-10s | %-10s | %-15s\n",
           "UF", "BR", "Trecho (km)", "Acidentes", "Feridos", "Mortos", "Índ. Gravidade");
    printf("------+--------+--------------+------------+------------+------------+----------------\n");
    
    for (int i = 0; i < n_pontos; i++) {
        printf("%-5s | %-6s | %.1f - %.1f | %-10d | %-10d | %-10d | %-15.2f\n",
               pontos_criticos[i].uf, pontos_criticos[i].br, 
               pontos_criticos[i].km_inicio, pontos_criticos[i].km_fim,
               pontos_criticos[i].acidentes, pontos_criticos[i].feridos, 
               pontos_criticos[i].mortos, pontos_criticos[i].indice_gravidade);
    }
    
    // Recomendações baseadas na análise
    printf("\nRecomendações para os pontos críticos de maior gravidade:\n");
    
    for (int i = 0; i < 3 && i < n_pontos; i++) {
        printf("\n%d. Ponto crítico: %s-%s, km %.1f - %.1f\n", i+1,
               pontos_criticos[i].uf, pontos_criticos[i].br,
               pontos_criticos[i].km_inicio, pontos_criticos[i].km_fim);
        printf("   Acidentes: %d, Feridos: %d, Mortos: %d, Índice de Gravidade: %.2f\n",
               pontos_criticos[i].acidentes, pontos_criticos[i].feridos,
               pontos_criticos[i].mortos, pontos_criticos[i].indice_gravidade);
        printf("   Recomendações:\n");
        printf("   - Realizar inspeção detalhada da sinalização e geometria da via\n");
        printf("   - Implementar fiscalização eletrônica de velocidade\n");
        printf("   - Melhorar a sinalização vertical e horizontal\n");
        printf("   - Considerar a instalação de dispositivos de segurança adicionais\n");
    }
}
