/**
 * machine_learning.c
 * 
 * Implementação de funções para aplicação de algoritmos de aprendizado de máquina
 * para previsão de acidentes de trânsito.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "machine_learning.h"
#include "previsao.h"
#include "../utils/visualizacao.h"

// Polinômio: a0 + a1*x + a2*x^2 + ... + an*x^n
ModeloPolinomial treinar_modelo_polinomial(const double *x, const double *y, int n, int grau) {
    ModeloPolinomial modelo;
    modelo.grau = grau;
    modelo.coeficientes = (double*)malloc((grau + 1) * sizeof(double));
    
    // Inicializa coeficientes com zeros
    for (int i = 0; i <= grau; i++) {
        modelo.coeficientes[i] = 0.0;
    }
    
    // Para grau 1, usamos regressão linear simples
    if (grau == 1) {
        double b, r2;
        regressao_linear(x, y, n, &modelo.coeficientes[0], &modelo.coeficientes[1], &r2);
    }
    // Para graus maiores, implementamos uma versão simples de regressão polinomial
    else {
        // Implementação básica de regressão polinomial com método dos mínimos quadrados
        // Matrix X (Vandermonde)
        double **X = (double**)malloc(n * sizeof(double*));
        for (int i = 0; i < n; i++) {
            X[i] = (double*)malloc((grau + 1) * sizeof(double));
            for (int j = 0; j <= grau; j++) {
                X[i][j] = pow(x[i], j);
            }
        }
        
        // Calcula X^T * X
        double **XTX = (double**)malloc((grau + 1) * sizeof(double*));
        for (int i = 0; i <= grau; i++) {
            XTX[i] = (double*)malloc((grau + 1) * sizeof(double));
            for (int j = 0; j <= grau; j++) {
                XTX[i][j] = 0.0;
                for (int k = 0; k < n; k++) {
                    XTX[i][j] += X[k][i] * X[k][j];
                }
            }
        }
        
        // Calcula X^T * y
        double *XTy = (double*)malloc((grau + 1) * sizeof(double));
        for (int i = 0; i <= grau; i++) {
            XTy[i] = 0.0;
            for (int j = 0; j < n; j++) {
                XTy[i] += X[j][i] * y[j];
            }
        }
        
        // Resolve o sistema linear (muito simplificado, sem tratamento de singularidades)
        // Para um sistema real, recomendaria usar bibliotecas como GSL
        
        // Eliminação Gaussiana (muito simplificada)
        for (int i = 0; i <= grau; i++) {
            // Pivô
            double pivot = XTX[i][i];
            
            // Divisão da linha pelo pivô
            for (int j = i; j <= grau; j++) {
                XTX[i][j] /= pivot;
            }
            XTy[i] /= pivot;
            
            // Eliminação das outras linhas
            for (int k = 0; k <= grau; k++) {
                if (k != i) {
                    double factor = XTX[k][i];
                    for (int j = i; j <= grau; j++) {
                        XTX[k][j] -= factor * XTX[i][j];
                    }
                    XTy[k] -= factor * XTy[i];
                }
            }
        }
        
        // Extrai os coeficientes
        for (int i = 0; i <= grau; i++) {
            modelo.coeficientes[i] = XTy[i];
        }
        
        // Libera memória
        free(XTy);
        for (int i = 0; i <= grau; i++) {
            free(XTX[i]);
        }
        free(XTX);
        
        for (int i = 0; i < n; i++) {
            free(X[i]);
        }
        free(X);
    }
    
    // Calcula erro médio do modelo
    double soma_erros = 0.0;
    for (int i = 0; i < n; i++) {
        double previsto = prever_polinomial(&modelo, x[i]);
        double erro = fabs(previsto - y[i]);
        soma_erros += erro;
    }
    modelo.erro_medio = soma_erros / n;
    
    return modelo;
}

double prever_polinomial(const ModeloPolinomial *modelo, double x) {
    double resultado = 0.0;
    
    for (int i = 0; i <= modelo->grau; i++) {
        resultado += modelo->coeficientes[i] * pow(x, i);
    }
    
    return resultado > 0 ? resultado : 0; // Evita previsões negativas
}

void liberar_modelo_polinomial(ModeloPolinomial *modelo) {
    if (modelo && modelo->coeficientes) {
        free(modelo->coeficientes);
        modelo->coeficientes = NULL;
        modelo->grau = 0;
    }
}

ModeloEnsemble treinar_modelo_ensemble(const double *x, const double *y, int n, 
                                      int n_modelos, const int *graus) {
    ModeloEnsemble ensemble;
    ensemble.n_modelos = n_modelos;
    ensemble.modelos = (ModeloPolinomial*)malloc(n_modelos * sizeof(ModeloPolinomial));
    ensemble.pesos = (double*)malloc(n_modelos * sizeof(double));
    
    // Treina cada modelo individual
    for (int i = 0; i < n_modelos; i++) {
        ensemble.modelos[i] = treinar_modelo_polinomial(x, y, n, graus[i]);
    }
    
    // Calcula pesos baseados no inverso do erro médio
    double soma_inv_erros = 0.0;
    for (int i = 0; i < n_modelos; i++) {
        // Evita divisão por zero
        double erro = ensemble.modelos[i].erro_medio > 0.0001 ? 
                      ensemble.modelos[i].erro_medio : 0.0001;
        ensemble.pesos[i] = 1.0 / erro;
        soma_inv_erros += ensemble.pesos[i];
    }
    
    // Normaliza pesos para somar 1
    for (int i = 0; i < n_modelos; i++) {
        ensemble.pesos[i] /= soma_inv_erros;
    }
    
    return ensemble;
}

double prever_ensemble(const ModeloEnsemble *modelo, double x) {
    double resultado = 0.0;
    
    for (int i = 0; i < modelo->n_modelos; i++) {
        double previsao = prever_polinomial(&modelo->modelos[i], x);
        resultado += previsao * modelo->pesos[i];
    }
    
    return resultado > 0 ? resultado : 0; // Evita previsões negativas
}

void liberar_modelo_ensemble(ModeloEnsemble *modelo) {
    if (modelo) {
        for (int i = 0; i < modelo->n_modelos; i++) {
            liberar_modelo_polinomial(&modelo->modelos[i]);
        }
        free(modelo->modelos);
        free(modelo->pesos);
        modelo->modelos = NULL;
        modelo->pesos = NULL;
        modelo->n_modelos = 0;
    }
}

int encontrar_melhor_modelo(const double *x, const double *y, int n, int k, int max_grau) {
    if (n < k || k < 2) {
        // Se não temos dados suficientes para validação cruzada, retorna grau 1
        return 1;
    }
    
    // Tamanho de cada fold
    int tamanho_fold = n / k;
    
    // Avalia cada grau de polinômio
    double menor_erro = INFINITY;
    int melhor_grau = 1;
    
    for (int grau = 1; grau <= max_grau; grau++) {
        double erro_total = 0.0;
        
        // Para cada fold como validação
        for (int fold = 0; fold < k; fold++) {
            // Índices de início e fim da validação
            int inicio_val = fold * tamanho_fold;
            int fim_val = (fold == k - 1) ? n : (fold + 1) * tamanho_fold;
            
            // Conta quantos pontos estão no treinamento
            int n_treino = n - (fim_val - inicio_val);
            
            // Separa dados de treino e validação
            double *x_treino = (double*)malloc(n_treino * sizeof(double));
            double *y_treino = (double*)malloc(n_treino * sizeof(double));
            int idx_treino = 0;
            
            for (int i = 0; i < n; i++) {
                if (i < inicio_val || i >= fim_val) {
                    x_treino[idx_treino] = x[i];
                    y_treino[idx_treino] = y[i];
                    idx_treino++;
                }
            }
            
            // Treina o modelo com o conjunto de treino
            ModeloPolinomial modelo = treinar_modelo_polinomial(
                x_treino, y_treino, n_treino, grau);
            
            // Avalia o modelo no conjunto de validação
            double erro_val = 0.0;
            for (int i = inicio_val; i < fim_val; i++) {
                double previsto = prever_polinomial(&modelo, x[i]);
                erro_val += fabs(previsto - y[i]);
            }
            erro_val /= (fim_val - inicio_val);
            
            // Acumula erro
            erro_total += erro_val;
            
            // Libera memória
            liberar_modelo_polinomial(&modelo);
            free(x_treino);
            free(y_treino);
        }
        
        // Erro médio entre todos os folds
        double erro_medio = erro_total / k;
        
        // Se este grau é melhor, atualiza
        if (erro_medio < menor_erro) {
            menor_erro = erro_medio;
            melhor_grau = grau;
        }
    }
    
    return melhor_grau;
}

void agrupar_dados_mensais_ml(Acidente *acidentes, int n_acidentes, 
                           double *x_meses, double *y_acidentes, 
                           double *y_feridos, double *y_mortos, int *n_meses) {
    // Estrutura para armazenar dados por mês-ano
    typedef struct {
        int mes;
        int ano;
        int acidentes;
        int feridos;
        int mortos;
        double valor_x;  // Valor contínuo representando o tempo
    } DadosMes;
    
    // Tamanho máximo de períodos a analisar
    const int MAX_PERIODOS = 100;
    DadosMes dados[MAX_PERIODOS];
    *n_meses = 0;
    
    // Encontrar data mínima para normalização
    int min_ano = 9999, min_mes = 12;
    for (int i = 0; i < n_acidentes; i++) {
        int mes = acidentes[i].data.mes;
        int ano = acidentes[i].data.ano;
        
        if (ano < min_ano || (ano == min_ano && mes < min_mes)) {
            min_ano = ano;
            min_mes = mes;
        }
    }
    
    // Conta acidentes por mês-ano
    for (int i = 0; i < n_acidentes; i++) {
        int mes = acidentes[i].data.mes;
        int ano = acidentes[i].data.ano;
        
        // Procura se o período já existe
        int idx = -1;
        for (int j = 0; j < *n_meses; j++) {
            if (dados[j].mes == mes && dados[j].ano == ano) {
                idx = j;
                break;
            }
        }
        
        // Se não existe, cria novo período
        if (idx == -1) {
            if (*n_meses >= MAX_PERIODOS) continue;
            idx = (*n_meses)++;
            dados[idx].mes = mes;
            dados[idx].ano = ano;
            dados[idx].acidentes = 0;
            dados[idx].feridos = 0;
            dados[idx].mortos = 0;
            
            // Calcula valor X (meses desde a data mínima)
            dados[idx].valor_x = ((ano - min_ano) * 12 + mes - min_mes);
        }
        
        // Incrementa contadores
        dados[idx].acidentes++;
        dados[idx].feridos += acidentes[i].condicoes.feridos;
        dados[idx].mortos += acidentes[i].condicoes.mortos;
    }
    
    // Ordena por data
    for (int i = 0; i < *n_meses - 1; i++) {
        for (int j = i + 1; j < *n_meses; j++) {
            if (dados[j].ano < dados[i].ano || 
                (dados[j].ano == dados[i].ano && dados[j].mes < dados[i].mes)) {
                DadosMes temp = dados[i];
                dados[i] = dados[j];
                dados[j] = temp;
            }
        }
    }
    
    // Copia dados para os arrays de resultado
    for (int i = 0; i < *n_meses; i++) {
        x_meses[i] = dados[i].valor_x;
        y_acidentes[i] = dados[i].acidentes;
        y_feridos[i] = dados[i].feridos;
        y_mortos[i] = dados[i].mortos;
    }
}

void executar_ml(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes) {
    printf("\n=== PREVISÃO AVANÇADA COM MACHINE LEARNING ===\n\n");
    
    if (n_acidentes <= 0) {
        printf("Erro: Não há dados suficientes para análise.\n");
        return;
    }
    
    // Agrupa dados por mês para treinamento
    const int MAX_MESES = 100;
    double x_meses[MAX_MESES];
    double y_acidentes[MAX_MESES];
    double y_feridos[MAX_MESES];
    double y_mortos[MAX_MESES];
    int n_meses;
    
    agrupar_dados_mensais_ml(acidentes, n_acidentes, x_meses, y_acidentes, 
                          y_feridos, y_mortos, &n_meses);
    
    if (n_meses < 5) {
        printf("Erro: Não há dados suficientes para treinamento (mínimo 5 meses).\n");
        return;
    }
    
    printf("Dados agrupados em %d períodos para análise.\n", n_meses);
    
    // Encontrar o melhor grau usando validação cruzada
    printf("Realizando validação cruzada para encontrar o melhor modelo...\n");
    int k_folds = n_meses >= 10 ? 5 : (n_meses >= 6 ? 3 : 2);
    int max_grau = 4;  // Não usar graus muito altos para evitar overfitting
    
    int melhor_grau_acidentes = encontrar_melhor_modelo(x_meses, y_acidentes, n_meses, k_folds, max_grau);
    int melhor_grau_feridos = encontrar_melhor_modelo(x_meses, y_feridos, n_meses, k_folds, max_grau);
    int melhor_grau_mortos = encontrar_melhor_modelo(x_meses, y_mortos, n_meses, k_folds, max_grau);
    
    printf("Melhor grau para modelo de acidentes: %d\n", melhor_grau_acidentes);
    printf("Melhor grau para modelo de feridos: %d\n", melhor_grau_feridos);
    printf("Melhor grau para modelo de mortos: %d\n", melhor_grau_mortos);
    
    // Definir modelos para ensemble
    const int n_modelos = 3;
    int graus_acidentes[3] = {1, melhor_grau_acidentes, melhor_grau_acidentes > 1 ? melhor_grau_acidentes - 1 : 2};
    int graus_feridos[3] = {1, melhor_grau_feridos, melhor_grau_feridos > 1 ? melhor_grau_feridos - 1 : 2};
    int graus_mortos[3] = {1, melhor_grau_mortos, melhor_grau_mortos > 1 ? melhor_grau_mortos - 1 : 2};
    
    // Treinar modelos ensemble
    printf("Treinando modelos ensemble para melhorar precisão...\n");
    ModeloEnsemble modelo_acidentes = treinar_modelo_ensemble(x_meses, y_acidentes, n_meses, n_modelos, graus_acidentes);
    ModeloEnsemble modelo_feridos = treinar_modelo_ensemble(x_meses, y_feridos, n_meses, n_modelos, graus_feridos);
    ModeloEnsemble modelo_mortos = treinar_modelo_ensemble(x_meses, y_mortos, n_meses, n_modelos, graus_mortos);
    
    // Realizar previsões para os próximos 12 meses
    const int n_previsoes = 12;
    double previsoes_acidentes[n_previsoes];
    double previsoes_feridos[n_previsoes];
    double previsoes_mortos[n_previsoes];
    
    printf("Realizando previsões para os próximos %d meses...\n", n_previsoes);
    
    for (int i = 0; i < n_previsoes; i++) {
        double x_pred = x_meses[n_meses - 1] + i + 1;
        previsoes_acidentes[i] = prever_ensemble(&modelo_acidentes, x_pred);
        previsoes_feridos[i] = prever_ensemble(&modelo_feridos, x_pred);
        previsoes_mortos[i] = prever_ensemble(&modelo_mortos, x_pred);
    }
    
    // Exibir resultados
    printf("\nPrevisões para os próximos %d meses:\n", n_previsoes);
    printf("%-5s | %-10s | %-10s | %-10s\n", 
           "Mês", "Acidentes", "Feridos", "Mortos");
    printf("------+------------+------------+------------\n");
    
    const char *nomes_meses[] = {
        "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
        "Jul", "Ago", "Set", "Out", "Nov", "Dez"
    };
    
    // Último mês dos dados
    int ultimo_mes = (int)(x_meses[n_meses - 1]) % 12;
    
    for (int i = 0; i < n_previsoes; i++) {
        int mes_idx = (ultimo_mes + i + 1) % 12;
        printf("%-5s | %-10.1f | %-10.1f | %-10.1f\n", 
               nomes_meses[mes_idx], 
               previsoes_acidentes[i], previsoes_feridos[i], previsoes_mortos[i]);
    }
    
    // Totais previstos
    double total_acidentes = 0.0, total_feridos = 0.0, total_mortos = 0.0;
    for (int i = 0; i < n_previsoes; i++) {
        total_acidentes += previsoes_acidentes[i];
        total_feridos += previsoes_feridos[i];
        total_mortos += previsoes_mortos[i];
    }
    
    printf("\nTotais previstos para o próximo ano:\n");
    printf("Total de Acidentes: %.0f\n", total_acidentes);
    printf("Total de Feridos: %.0f\n", total_feridos);
    printf("Total de Mortos: %.0f\n", total_mortos);
    
    // Indicadores de gravidade
    double indice_feridos = total_feridos / total_acidentes;
    double indice_mortos = total_mortos / total_acidentes;
    
    printf("\nIndicadores de Gravidade:\n");
    printf("Feridos por Acidente: %.2f\n", indice_feridos);
    printf("Mortos por Acidente: %.2f\n", indice_mortos);
    
    // Desenhar gráficos de previsões
    const char *rotulos_previsao[n_previsoes];
    for (int i = 0; i < n_previsoes; i++) {
        int mes_idx = (ultimo_mes + i + 1) % 12;
        rotulos_previsao[i] = nomes_meses[mes_idx];
    }
    
    printf("\n");
    desenhar_grafico_linha("Previsão de Acidentes - Próximos 12 Meses", 
                          rotulos_previsao, previsoes_acidentes, n_previsoes, 15, 80);
    
    printf("\n");
    desenhar_grafico_linha("Previsão de Mortos - Próximos 12 Meses", 
                          rotulos_previsao, previsoes_mortos, n_previsoes, 15, 80);
    
    // Comparação com método simples
    printf("\nComparação com método tradicional de regressão linear:\n");
    
    // Treinar modelo linear simples
    double a, b, r2;
    regressao_linear(x_meses, y_acidentes, n_meses, &a, &b, &r2);
    
    double total_lin = 0.0;
    for (int i = 0; i < n_previsoes; i++) {
        double x_pred = x_meses[n_meses - 1] + i + 1;
        double prev_lin = a + b * x_pred;
        if (prev_lin < 0) prev_lin = 0;
        total_lin += prev_lin;
    }
    
    printf("Total de acidentes (ML Ensemble): %.0f\n", total_acidentes);
    printf("Total de acidentes (Regressão Linear): %.0f\n", total_lin);
    printf("Diferença: %.1f%%\n", 100.0 * fabs(total_acidentes - total_lin) / total_lin);
    
    // Métricas de confiança
    printf("\nMétricas de Confiança dos Modelos:\n");
    printf("Modelo Acidentes - Erro Médio: %.2f\n", modelo_acidentes.modelos[0].erro_medio);
    printf("Modelo Feridos - Erro Médio: %.2f\n", modelo_feridos.modelos[0].erro_medio);
    printf("Modelo Mortos - Erro Médio: %.2f\n", modelo_mortos.modelos[0].erro_medio);
    
    // Liberar memória
    liberar_modelo_ensemble(&modelo_acidentes);
    liberar_modelo_ensemble(&modelo_feridos);
    liberar_modelo_ensemble(&modelo_mortos);
}