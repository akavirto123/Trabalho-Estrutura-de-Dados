/**
 * classificacao.h
 * 
 * Funções para classificação e agrupamento de acidentes de trânsito.
 */

#ifndef CLASSIFICACAO_H
#define CLASSIFICACAO_H

#include "../utils/tipos.h"

/**
 * Classifica acidentes de trânsito usando a estrutura de dados especificada.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void classificar_acidentes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Agrupa acidentes por similaridade de características.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void agrupar_por_similaridade(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Classifica acidentes por nível de gravidade.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void classificar_por_gravidade(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Identifica padrões de acidentes com base em múltiplas características.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void identificar_padroes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

/**
 * Encontra correlações entre diferentes fatores de acidentes.
 * 
 * @param estrutura Tipo de estrutura a ser utilizada
 * @param acidentes Array de acidentes para análise
 * @param n_acidentes Número de acidentes no array
 */
void analisar_correlacoes(EstruturaDados estrutura, Acidente *acidentes, int n_acidentes);

#endif /* CLASSIFICACAO_H */